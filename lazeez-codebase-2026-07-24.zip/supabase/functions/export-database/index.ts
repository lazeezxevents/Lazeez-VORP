import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const TABLES = [
  "break_phase",
  "call_logs",
  "custom_kpis",
  "dashboard_bookmarks",
  "kpi_annotations",
  "kpi_archive_history",
  "sales_cycle_data",
  "user_roles",
  "vendor_responses",
  "visitor_clicks",
  "visitor_logs",
  "visitor_scroll_depth",
  "visitor_session_recordings",
  "visitor_sessions",
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = authHeader.replace("Bearer ", "");
    const authClient = createClient(supabaseUrl, anonKey);
    const { data: claimsData, error: claimsError } =
      await authClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const admin = createClient(supabaseUrl, serviceKey);
    const { data: roleRow } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", claimsData.claims.sub)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const dump: Record<string, unknown> = {
      exported_at: new Date().toISOString(),
      project_ref: supabaseUrl.split("//")[1]?.split(".")[0] ?? null,
      tables: {},
    };
    const tables = dump.tables as Record<string, { row_count: number; rows: unknown[]; error?: string }>;

    for (const t of TABLES) {
      const { data, error } = await admin.from(t).select("*");
      if (error) {
        tables[t] = { row_count: 0, rows: [], error: error.message };
      } else {
        tables[t] = { row_count: data?.length ?? 0, rows: data ?? [] };
      }
    }

    const filename = `lazeez-db-export-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.json`;
    return new Response(JSON.stringify(dump, null, 2), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: (error as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
