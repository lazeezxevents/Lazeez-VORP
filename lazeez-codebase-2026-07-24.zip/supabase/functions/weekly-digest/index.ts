import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Require authenticated admin caller
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = authHeader.replace("Bearer ", "");
    const authClient = createClient(supabaseUrl, anonKey);
    const { data: claimsData, error: claimsError } =
      await authClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, serviceKey);

    // Verify admin role
    const { data: roleRow } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", claimsData.claims.sub)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch all KPIs
    const { data: kpis } = await supabase
      .from("custom_kpis")
      .select("*")
      .order("category", { ascending: true });

    const weekAgo = new Date(
      Date.now() - 7 * 24 * 60 * 60 * 1000
    ).toISOString();
    const { data: recentArchives } = await supabase
      .from("kpi_archive_history")
      .select("*")
      .gte("archived_at", weekAgo)
      .order("archived_at", { ascending: false });

    const weekAgoDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0];
    const { data: callLogs } = await supabase
      .from("call_logs")
      .select("*")
      .gte("date", weekAgoDate);

    const { data: vendorResponses } = await supabase
      .from("vendor_responses")
      .select("*")
      .gte("date", weekAgoDate);

    const totalCalls =
      callLogs?.reduce((s, c) => s + (c.calls_made || 0), 0) || 0;
    const totalAnswered =
      callLogs?.reduce((s, c) => s + (c.calls_answered || 0), 0) || 0;
    const totalQueries =
      vendorResponses?.reduce(
        (s, r) =>
          s +
          (r.inquiries_received || 0) +
          (r.inquiries_received_weekend || 0),
        0
      ) || 0;
    const totalResponded =
      vendorResponses?.reduce(
        (s, r) =>
          s +
          (r.inquiries_responded || 0) +
          (r.inquiries_responded_weekend || 0),
        0
      ) || 0;

    const summary = {
      generated_at: new Date().toISOString(),
      total_kpis: kpis?.length || 0,
      archives_this_week: recentArchives?.length || 0,
      calls_this_week: totalCalls,
      calls_answered: totalAnswered,
      queries_received: totalQueries,
      queries_responded: totalResponded,
      kpi_details: kpis?.map((k) => ({
        name: k.name,
        value: k.value,
        category: k.category,
        target: k.target_value,
        warning: k.warning_threshold,
        critical: k.critical_threshold,
      })),
      alerts:
        kpis
          ?.filter(
            (k) =>
              (k.critical_threshold && (k.value || 0) >= k.critical_threshold) ||
              (k.warning_threshold && (k.value || 0) >= k.warning_threshold)
          )
          .map((k) => ({
            name: k.name,
            value: k.value,
            level:
              k.critical_threshold && (k.value || 0) >= k.critical_threshold
                ? "CRITICAL"
                : "WARNING",
          })) || [],
    };

    return new Response(JSON.stringify(summary), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: (error as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
