import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

interface TrackRequest {
  type: 'session' | 'clicks' | 'scroll' | 'recording';
  session_id: string;
  page_name: string;
  data: any;
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body: TrackRequest = await req.json();
    const { type, session_id, page_name, data } = body;

    if (!type || !session_id) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    switch (type) {
      case 'session': {
        const { error } = await supabase.from('visitor_sessions').upsert({
          session_id,
          started_at: data.started_at || new Date().toISOString(),
          ended_at: data.ended_at,
          duration_seconds: data.duration_seconds || 0,
          screen_width: data.screen_width,
          screen_height: data.screen_height,
          viewport_width: data.viewport_width,
          viewport_height: data.viewport_height,
          referrer: data.referrer,
          language: data.language,
          timezone: data.timezone,
          connection_type: data.connection_type,
          pages_visited: data.pages_visited || [],
          total_clicks: data.total_clicks || 0,
          total_scroll_events: data.total_scroll_events || 0,
          max_scroll_depth_percent: data.max_scroll_depth_percent || 0,
          is_bounce: data.is_bounce ?? false,
        }, { onConflict: 'session_id' });
        
        if (error) {
          // If upsert fails due to no unique constraint, try insert
          const { error: insertError } = await supabase.from('visitor_sessions').insert({
            session_id,
            started_at: data.started_at || new Date().toISOString(),
            ended_at: data.ended_at,
            duration_seconds: data.duration_seconds || 0,
            screen_width: data.screen_width,
            screen_height: data.screen_height,
            viewport_width: data.viewport_width,
            viewport_height: data.viewport_height,
            referrer: data.referrer,
            language: data.language,
            timezone: data.timezone,
            connection_type: data.connection_type,
            pages_visited: data.pages_visited || [],
            total_clicks: data.total_clicks || 0,
            total_scroll_events: data.total_scroll_events || 0,
            max_scroll_depth_percent: data.max_scroll_depth_percent || 0,
            is_bounce: data.is_bounce ?? false,
          });
          if (insertError) throw insertError;
        }
        break;
      }

      case 'clicks': {
        if (!Array.isArray(data.clicks) || data.clicks.length === 0) break;
        
        const clickRows = data.clicks.map((click: any) => ({
          session_id,
          page_name,
          x_position: click.x_position,
          y_position: click.y_position,
          x_percent: click.x_percent,
          y_percent: click.y_percent,
          element_tag: click.element_tag,
          element_text: (click.element_text || '').substring(0, 100),
          element_id: click.element_id,
          element_class: (click.element_class || '').substring(0, 200),
          clicked_at: click.clicked_at || new Date().toISOString(),
        }));

        const { error } = await supabase.from('visitor_clicks').insert(clickRows);
        if (error) throw error;
        break;
      }

      case 'scroll': {
        const { error } = await supabase.from('visitor_scroll_depth').insert({
          session_id,
          page_name,
          max_depth_percent: data.max_depth_percent || 0,
          page_height: data.page_height,
          viewport_height: data.viewport_height,
        });
        if (error) throw error;
        break;
      }

      case 'recording': {
        if (!data.events || !Array.isArray(data.events) || data.events.length === 0) break;
        
        const { error } = await supabase.from('visitor_session_recordings').insert({
          session_id,
          page_name,
          events: data.events,
          chunk_index: data.chunk_index || 0,
          event_count: data.events.length,
        });
        if (error) throw error;
        break;
      }

      default:
        return new Response(
          JSON.stringify({ error: 'Invalid event type' }),
          { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  } catch (error: any) {
    console.error('Error tracking event:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
});
