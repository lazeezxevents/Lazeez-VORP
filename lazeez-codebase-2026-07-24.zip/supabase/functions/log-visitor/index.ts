import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface VisitorLogRequest {
  page_name: string;
  user_agent: string;
  device_name: string;
  browser: string;
  os: string;
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body: VisitorLogRequest = await req.json();
    
    // Get IP from request headers
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
               req.headers.get('x-real-ip') || 
               'unknown';

    console.log('Logging visitor:', { ip, page: body.page_name });

    // Try to get geolocation data from IP
    let region = 'Unknown';
    let country = 'Unknown';
    let city = 'Unknown';

    if (ip && ip !== 'unknown') {
      try {
        // Using ip-api.com (free, no API key needed)
        const geoResponse = await fetch(`http://ip-api.com/json/${ip}?fields=status,country,regionName,city`);
        if (geoResponse.ok) {
          const geoData = await geoResponse.json();
          if (geoData.status === 'success') {
            region = geoData.regionName || 'Unknown';
            country = geoData.country || 'Unknown';
            city = geoData.city || 'Unknown';
          }
        }
      } catch (geoError) {
        console.error('Geolocation lookup failed:', geoError);
      }
    }

    // Insert visitor log
    const { error } = await supabase.from('visitor_logs').insert({
      page_name: body.page_name,
      ip_address: ip,
      region,
      country,
      city,
      device_name: body.device_name,
      browser: body.browser,
      os: body.os,
      user_agent: body.user_agent,
    });

    if (error) {
      console.error('Database insert error:', error);
      throw error;
    }

    console.log('Visitor logged successfully');

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });
  } catch (error: any) {
    console.error('Error logging visitor:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
});
