import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const TABLES = [
  "user_roles",
  "custom_kpis",
  "kpi_annotations",
  "kpi_archive_history",
  "vendor_responses",
  "call_logs",
  "sales_cycle_data",
  "dashboard_bookmarks",
  "break_phase",
  "visitor_sessions",
  "visitor_logs",
  "visitor_clicks",
  "visitor_scroll_depth",
  "visitor_session_recordings",
];

function q(id: string) {
  return `"${id.replace(/"/g, '""')}"`;
}

function literal(v: unknown): string {
  if (v === null || v === undefined) return "NULL";
  if (typeof v === "number") return Number.isFinite(v) ? String(v) : "NULL";
  if (typeof v === "boolean") return v ? "TRUE" : "FALSE";
  if (v instanceof Date) return `'${v.toISOString()}'`;
  if (typeof v === "object") {
    return `'${JSON.stringify(v).replace(/'/g, "''")}'::jsonb`;
  }
  return `'${String(v).replace(/'/g, "''")}'`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = authHeader.replace("Bearer ", "");
    const authClient = createClient(supabaseUrl, anonKey);
    const { data: claimsData, error: claimsError } =
      await authClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const admin = createClient(supabaseUrl, serviceKey);
    const { data: roleRow } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", claimsData.claims.sub)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const parts: string[] = [];
    parts.push(`-- Lazeez Sales KPI database replication script`);
    parts.push(`-- Generated: ${new Date().toISOString()}`);
    parts.push(`-- Target: PostgreSQL 14+ (Supabase compatible)`);
    parts.push(``);
    parts.push(`BEGIN;`);
    parts.push(`CREATE EXTENSION IF NOT EXISTS "pgcrypto";`);
    parts.push(``);

    // Enums - hardcoded below (pg_catalog not accessible via PostgREST)

    // We can't query pg_catalog through PostgREST — hardcode the known enum
    parts.push(`DO $$ BEGIN`);
    parts.push(`  CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');`);
    parts.push(`EXCEPTION WHEN duplicate_object THEN NULL; END $$;`);
    parts.push(``);

    // Get table columns via information_schema (exposed via PostgREST if in exposed schema — usually not).
    // Instead, sample one row per table and derive columns from data + supabase-js schema.
    // Simpler: fetch OpenAPI spec.
    const openapiRes = await fetch(`${supabaseUrl}/rest/v1/`, {
      headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` },
    });
    const openapi = await openapiRes.json();
    const defs = openapi.definitions || {};

    const pgTypeMap: Record<string, string> = {
      integer: "INTEGER",
      bigint: "BIGINT",
      smallint: "SMALLINT",
      numeric: "NUMERIC",
      real: "REAL",
      "double precision": "DOUBLE PRECISION",
      text: "TEXT",
      "character varying": "TEXT",
      uuid: "UUID",
      boolean: "BOOLEAN",
      json: "JSONB",
      jsonb: "JSONB",
      "timestamp with time zone": "TIMESTAMPTZ",
      "timestamp without time zone": "TIMESTAMP",
      date: "DATE",
      "time without time zone": "TIME",
      ARRAY: "TEXT[]",
    };

    for (const t of TABLES) {
      const def = defs[t];
      if (!def) {
        parts.push(`-- WARNING: table ${t} not found in OpenAPI spec, skipping schema`);
        continue;
      }
      const props = def.properties || {};
      const required: string[] = def.required || [];
      const cols: string[] = [];
      for (const [name, meta] of Object.entries<any>(props)) {
        const fmt = meta.format || meta.type;
        let pg = pgTypeMap[fmt] || (meta.enum ? "public.app_role" : "TEXT");
        if (name === "role" && t === "user_roles") pg = "public.app_role";
        let line = `  ${q(name)} ${pg}`;
        const desc: string = meta.description || "";
        if (desc.includes("Primary Key")) line += " PRIMARY KEY";
        if (required.includes(name) && !desc.includes("Primary Key")) line += " NOT NULL";
        // defaults from description like "Default: xxx"
        const dm = desc.match(/Default(?:\s+Value)?:\s*([^\n<]+)/i);
        if (dm) line += ` DEFAULT ${dm[1].trim()}`;
        else if (name === "id" && pg === "UUID") line += " DEFAULT gen_random_uuid()";
        else if (name === "created_at" || name === "updated_at") line += " DEFAULT now()";
        cols.push(line);
      }
      parts.push(`CREATE TABLE IF NOT EXISTS public.${q(t)} (`);
      parts.push(cols.join(",\n"));
      parts.push(`);`);
      parts.push(`GRANT SELECT, INSERT, UPDATE, DELETE ON public.${q(t)} TO authenticated;`);
      parts.push(`GRANT ALL ON public.${q(t)} TO service_role;`);
      parts.push(`GRANT SELECT ON public.${q(t)} TO anon;`);
      parts.push(`ALTER TABLE public.${q(t)} ENABLE ROW LEVEL SECURITY;`);
      parts.push(``);
    }

    // Helper functions
    parts.push(`CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;`);
    parts.push(``);
    parts.push(`CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;`);
    parts.push(``);

    // Basic permissive policies (mirror production intent)
    parts.push(`-- NOTE: RLS policies below are a starting point. Review before production use.`);
    for (const t of TABLES) {
      parts.push(`CREATE POLICY "Public read ${t}" ON public.${q(t)} FOR SELECT USING (true);`);
      parts.push(`CREATE POLICY "Admin write ${t}" ON public.${q(t)} FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));`);
    }
    parts.push(``);

    // Data dump
    parts.push(`-- ============ DATA ============`);
    for (const t of TABLES) {
      const { data, error } = await admin.from(t).select("*");
      if (error || !data || data.length === 0) {
        parts.push(`-- ${t}: ${error ? `error ${error.message}` : "no rows"}`);
        continue;
      }
      const cols = Object.keys(data[0]);
      parts.push(`-- ${t}: ${data.length} rows`);
      for (const row of data) {
        const vals = cols.map((c) => literal((row as any)[c])).join(", ");
        parts.push(
          `INSERT INTO public.${q(t)} (${cols.map(q).join(", ")}) VALUES (${vals}) ON CONFLICT DO NOTHING;`,
        );
      }
      parts.push(``);
    }

    parts.push(`COMMIT;`);

    const sql = parts.join("\n");
    const filename = `lazeez-db-schema-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.sql`;
    return new Response(sql, {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/sql; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: (error as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
