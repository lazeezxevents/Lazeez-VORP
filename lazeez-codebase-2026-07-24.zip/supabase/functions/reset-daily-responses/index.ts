import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0]
    const todayDate = new Date()
    const dayOfWeek = todayDate.getDay()
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6

    console.log(`Checking for existing entry for date: ${today}, isWeekend: ${isWeekend}`)

    // Check if today's entry exists
    const { data: existingEntry } = await supabase
      .from('vendor_responses')
      .select('*')
      .eq('date', today)
      .maybeSingle()

    if (!existingEntry) {
      // Archive yesterday's entry if exists
      const yesterday = new Date()
      yesterday.setDate(yesterday.getDate() - 1)
      const yesterdayStr = yesterday.toISOString().split('T')[0]

      console.log(`Archiving entry for: ${yesterdayStr}`)

      await supabase
        .from('vendor_responses')
        .update({ is_archived: true })
        .eq('date', yesterdayStr)

      // Create new entry for today
      console.log(`Creating new entry for: ${today}`)
      
      const { error: insertError } = await supabase
        .from('vendor_responses')
        .insert({
          date: today,
          inquiries_received: 0,
          inquiries_responded: 0,
          inquiries_received_weekend: 0,
          inquiries_responded_weekend: 0,
          is_weekend: isWeekend,
          is_archived: false
        })

      if (insertError) {
        console.error('Error creating entry:', insertError)
        throw insertError
      }
    }

    return new Response(
      JSON.stringify({ success: true, date: today, isWeekend }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Error in reset-daily-responses:', error)
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
