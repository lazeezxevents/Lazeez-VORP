-- Add weekend tracking columns to vendor_responses table
ALTER TABLE public.vendor_responses
ADD COLUMN IF NOT EXISTS inquiries_received_weekend integer NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS inquiries_responded_weekend integer NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS is_weekend boolean NOT NULL DEFAULT false;