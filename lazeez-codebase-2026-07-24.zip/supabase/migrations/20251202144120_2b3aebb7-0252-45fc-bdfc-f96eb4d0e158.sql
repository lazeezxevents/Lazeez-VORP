-- Add archive columns to custom_kpis table
ALTER TABLE public.custom_kpis 
ADD COLUMN is_archived BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN archived_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN value_before_archive NUMERIC;

-- Create index for faster archive queries
CREATE INDEX idx_custom_kpis_archived ON public.custom_kpis(is_archived);