UPDATE auth.users
SET encrypted_password = crypt('admn123', gen_salt('bf')),
    updated_at = now()
WHERE id = (SELECT user_id FROM public.user_roles WHERE role = 'admin' LIMIT 1);