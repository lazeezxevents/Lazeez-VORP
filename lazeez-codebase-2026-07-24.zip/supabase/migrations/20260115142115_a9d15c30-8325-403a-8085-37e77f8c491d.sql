-- Add period tracking columns to custom_kpis
ALTER TABLE public.custom_kpis
ADD COLUMN IF NOT EXISTS period_label TEXT,
ADD COLUMN IF NOT EXISTS period_start_date DATE,
ADD COLUMN IF NOT EXISTS period_end_date DATE,
ADD COLUMN IF NOT EXISTS previous_total NUMERIC DEFAULT 0;

-- Add period tracking columns to kpi_archive_history  
ALTER TABLE public.kpi_archive_history
ADD COLUMN IF NOT EXISTS period_label TEXT,
ADD COLUMN IF NOT EXISTS period_start_date DATE,
ADD COLUMN IF NOT EXISTS period_end_date DATE;

-- Update existing "Last 2 Weeks" KPI with period info (DEC 30 - JAN 13)
UPDATE public.custom_kpis 
SET period_label = 'DEC 30 - JAN 13',
    period_start_date = '2024-12-30',
    period_end_date = '2025-01-13'
WHERE name = 'Last 2 Weeks';

-- Update existing "Last 2 Months" KPI with period info (DEC-JAN)
UPDATE public.custom_kpis 
SET period_label = 'DEC - JAN',
    period_start_date = '2024-12-01',
    period_end_date = '2025-01-31'
WHERE name = 'Last 2 Months';

-- Update existing "Last Quarter" KPI with period info (DEC-FEB)
UPDATE public.custom_kpis 
SET period_label = 'DEC - FEB',
    period_start_date = '2024-12-01',
    period_end_date = '2025-02-28'
WHERE name = 'Last Quarter';