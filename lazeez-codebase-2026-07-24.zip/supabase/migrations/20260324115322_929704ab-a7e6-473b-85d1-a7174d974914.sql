
CREATE TABLE public.break_phase (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  is_active boolean NOT NULL DEFAULT false,
  reason text,
  activated_by uuid,
  activated_at timestamp with time zone DEFAULT now(),
  deactivated_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.break_phase ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view break phase" ON public.break_phase FOR SELECT TO public USING (true);
CREATE POLICY "Admins can insert break phase" ON public.break_phase FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can update break phase" ON public.break_phase FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can delete break phase" ON public.break_phase FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));

-- Insert a single row to track break status
INSERT INTO public.break_phase (is_active, reason) VALUES (false, null);
