
-- Add sort_order to custom_kpis for drag-and-drop reordering
ALTER TABLE public.custom_kpis ADD COLUMN sort_order integer DEFAULT 0;

-- Create kpi_annotations table for team annotations
CREATE TABLE public.kpi_annotations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kpi_id uuid NOT NULL REFERENCES public.custom_kpis(id) ON DELETE CASCADE,
  note text NOT NULL,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  is_pinned boolean NOT NULL DEFAULT true
);

-- Enable RLS
ALTER TABLE public.kpi_annotations ENABLE ROW LEVEL SECURITY;

-- Anyone can view annotations
CREATE POLICY "Anyone can view annotations"
  ON public.kpi_annotations FOR SELECT
  USING (true);

-- Only admins can insert annotations
CREATE POLICY "Admins can insert annotations"
  ON public.kpi_annotations FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can update annotations
CREATE POLICY "Admins can update annotations"
  ON public.kpi_annotations FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can delete annotations
CREATE POLICY "Admins can delete annotations"
  ON public.kpi_annotations FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
