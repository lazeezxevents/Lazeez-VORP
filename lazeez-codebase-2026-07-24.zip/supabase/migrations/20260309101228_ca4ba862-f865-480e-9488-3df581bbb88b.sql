
-- Add threshold columns to custom_kpis
ALTER TABLE public.custom_kpis 
  ADD COLUMN IF NOT EXISTS warning_threshold numeric DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS critical_threshold numeric DEFAULT NULL;

-- Create dashboard_bookmarks table
CREATE TABLE public.dashboard_bookmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL,
  filters jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.dashboard_bookmarks ENABLE ROW LEVEL SECURITY;

-- Users can only see their own bookmarks
CREATE POLICY "Users can view own bookmarks" ON public.dashboard_bookmarks
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own bookmarks" ON public.dashboard_bookmarks
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own bookmarks" ON public.dashboard_bookmarks
  FOR DELETE TO authenticated USING (auth.uid() = user_id);
