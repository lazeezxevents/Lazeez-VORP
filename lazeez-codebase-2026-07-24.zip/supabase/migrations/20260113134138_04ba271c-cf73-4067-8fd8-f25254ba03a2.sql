-- Create kpi_archive_history table for stacked archive records
CREATE TABLE public.kpi_archive_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  kpi_id UUID NOT NULL,
  kpi_name TEXT NOT NULL,
  category TEXT,
  description TEXT,
  value_at_archive NUMERIC NOT NULL,
  archived_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  archived_by UUID
);

-- Enable RLS
ALTER TABLE public.kpi_archive_history ENABLE ROW LEVEL SECURITY;

-- Anyone can view archive history
CREATE POLICY "Anyone can view archive history"
ON public.kpi_archive_history
FOR SELECT
USING (true);

-- Only admins can insert archive history
CREATE POLICY "Admins can insert archive history"
ON public.kpi_archive_history
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Only admins can delete archive history
CREATE POLICY "Admins can delete archive history"
ON public.kpi_archive_history
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create index for faster lookups by kpi_id
CREATE INDEX idx_kpi_archive_history_kpi_id ON public.kpi_archive_history(kpi_id);
CREATE INDEX idx_kpi_archive_history_archived_at ON public.kpi_archive_history(archived_at DESC);