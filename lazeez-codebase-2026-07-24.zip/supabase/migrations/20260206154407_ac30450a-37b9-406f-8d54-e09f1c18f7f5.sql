
-- Visitor sessions table - tracks each visit session with detailed metadata
CREATE TABLE public.visitor_sessions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  visitor_log_id uuid REFERENCES public.visitor_logs(id) ON DELETE SET NULL,
  session_id text NOT NULL,
  started_at timestamp with time zone NOT NULL DEFAULT now(),
  ended_at timestamp with time zone,
  duration_seconds integer DEFAULT 0,
  screen_width integer,
  screen_height integer,
  viewport_width integer,
  viewport_height integer,
  referrer text,
  language text,
  timezone text,
  connection_type text,
  pages_visited text[] DEFAULT '{}',
  total_clicks integer DEFAULT 0,
  total_scroll_events integer DEFAULT 0,
  max_scroll_depth_percent integer DEFAULT 0,
  is_bounce boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Click tracking for heatmaps
CREATE TABLE public.visitor_clicks (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id text NOT NULL,
  page_name text NOT NULL,
  x_position integer NOT NULL,
  y_position integer NOT NULL,
  x_percent numeric(5,2) NOT NULL,
  y_percent numeric(5,2) NOT NULL,
  element_tag text,
  element_text text,
  element_id text,
  element_class text,
  clicked_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Scroll depth tracking
CREATE TABLE public.visitor_scroll_depth (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id text NOT NULL,
  page_name text NOT NULL,
  max_depth_percent integer NOT NULL DEFAULT 0,
  page_height integer,
  viewport_height integer,
  recorded_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Session recording events (rrweb events stored as JSONB)
CREATE TABLE public.visitor_session_recordings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id text NOT NULL,
  page_name text NOT NULL,
  events jsonb NOT NULL DEFAULT '[]',
  chunk_index integer NOT NULL DEFAULT 0,
  event_count integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Indexes for performance
CREATE INDEX idx_visitor_sessions_session_id ON public.visitor_sessions(session_id);
CREATE INDEX idx_visitor_sessions_started_at ON public.visitor_sessions(started_at DESC);
CREATE INDEX idx_visitor_clicks_session_id ON public.visitor_clicks(session_id);
CREATE INDEX idx_visitor_clicks_page ON public.visitor_clicks(page_name);
CREATE INDEX idx_visitor_clicks_time ON public.visitor_clicks(clicked_at DESC);
CREATE INDEX idx_visitor_scroll_session ON public.visitor_scroll_depth(session_id);
CREATE INDEX idx_visitor_scroll_page ON public.visitor_scroll_depth(page_name);
CREATE INDEX idx_session_recordings_session ON public.visitor_session_recordings(session_id);
CREATE INDEX idx_session_recordings_time ON public.visitor_session_recordings(created_at DESC);

-- Enable RLS
ALTER TABLE public.visitor_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_clicks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_scroll_depth ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitor_session_recordings ENABLE ROW LEVEL SECURITY;

-- Insert policies (anyone can insert - tracking data)
CREATE POLICY "Anyone can insert visitor sessions" ON public.visitor_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can insert visitor clicks" ON public.visitor_clicks FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can insert scroll depth" ON public.visitor_scroll_depth FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can insert session recordings" ON public.visitor_session_recordings FOR INSERT WITH CHECK (true);

-- Only admins can view tracking data
CREATE POLICY "Only admins can view visitor sessions" ON public.visitor_sessions FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Only admins can view visitor clicks" ON public.visitor_clicks FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Only admins can view scroll depth" ON public.visitor_scroll_depth FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Only admins can view session recordings" ON public.visitor_session_recordings FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

-- Only admins can delete
CREATE POLICY "Only admins can delete visitor sessions" ON public.visitor_sessions FOR DELETE USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Only admins can delete visitor clicks" ON public.visitor_clicks FOR DELETE USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Only admins can delete scroll depth" ON public.visitor_scroll_depth FOR DELETE USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Only admins can delete session recordings" ON public.visitor_session_recordings FOR DELETE USING (has_role(auth.uid(), 'admin'::app_role));
