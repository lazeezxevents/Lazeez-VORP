
-- Drop admin UUID leak from public archive history
ALTER TABLE public.kpi_archive_history DROP COLUMN IF EXISTS archived_by;

-- Add owner-scoped UPDATE policy for dashboard_bookmarks
CREATE POLICY "Users can update own bookmarks"
ON public.dashboard_bookmarks
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Lock down UPDATE on visitor tracking tables to admins only
CREATE POLICY "Only admins can update visitor clicks"
ON public.visitor_clicks
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can update visitor scroll depth"
ON public.visitor_scroll_depth
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can update visitor session recordings"
ON public.visitor_session_recordings
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can update visitor sessions"
ON public.visitor_sessions
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
