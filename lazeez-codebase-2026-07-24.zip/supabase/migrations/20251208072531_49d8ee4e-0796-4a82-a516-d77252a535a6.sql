-- Drop the existing SELECT policy
DROP POLICY IF EXISTS "Users can view their own roles" ON public.user_roles;

-- Create a proper PERMISSIVE policy that strictly limits users to viewing only their own role
CREATE POLICY "Users can view only their own role"
ON public.user_roles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);