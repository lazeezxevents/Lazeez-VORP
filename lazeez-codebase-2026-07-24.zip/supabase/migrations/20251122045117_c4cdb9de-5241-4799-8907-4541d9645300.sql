-- Update RLS policy to allow public access to KPIs
DROP POLICY IF EXISTS "Authenticated users can view KPIs" ON public.custom_kpis;

CREATE POLICY "Anyone can view KPIs"
ON public.custom_kpis
FOR SELECT
USING (true);