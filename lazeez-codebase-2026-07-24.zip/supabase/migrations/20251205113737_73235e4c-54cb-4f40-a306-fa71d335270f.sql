-- Table for daily vendor response entries
CREATE TABLE public.vendor_responses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  date DATE NOT NULL,
  inquiries_received INTEGER NOT NULL DEFAULT 0,
  inquiries_responded INTEGER NOT NULL DEFAULT 0,
  is_archived BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(date)
);

-- Enable RLS
ALTER TABLE public.vendor_responses ENABLE ROW LEVEL SECURITY;

-- Anyone can view
CREATE POLICY "Anyone can view vendor responses" 
ON public.vendor_responses 
FOR SELECT 
USING (true);

-- Admin policies
CREATE POLICY "Admins can insert vendor responses" 
ON public.vendor_responses 
FOR INSERT 
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update vendor responses" 
ON public.vendor_responses 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete vendor responses" 
ON public.vendor_responses 
FOR DELETE 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_vendor_responses_updated_at
BEFORE UPDATE ON public.vendor_responses
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Table for sales cycle data (editable quarters)
CREATE TABLE public.sales_cycle_data (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  quarter TEXT NOT NULL,
  weeks NUMERIC NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.sales_cycle_data ENABLE ROW LEVEL SECURITY;

-- Anyone can view
CREATE POLICY "Anyone can view sales cycle data" 
ON public.sales_cycle_data 
FOR SELECT 
USING (true);

-- Admin policies
CREATE POLICY "Admins can insert sales cycle data" 
ON public.sales_cycle_data 
FOR INSERT 
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update sales cycle data" 
ON public.sales_cycle_data 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete sales cycle data" 
ON public.sales_cycle_data 
FOR DELETE 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_sales_cycle_data_updated_at
BEFORE UPDATE ON public.sales_cycle_data
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default sales cycle data
INSERT INTO public.sales_cycle_data (quarter, weeks, sort_order) VALUES
('Q1', 2.0, 1),
('Q2', 1.7, 2),
('Q3', 1.5, 3);