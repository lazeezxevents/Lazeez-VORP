UPDATE auth.users
SET email = 'admin@system.local',
    encrypted_password = crypt('admin', gen_salt('bf')),
    email_confirmed_at = COALESCE(email_confirmed_at, now()),
    updated_at = now()
WHERE id = (SELECT user_id FROM public.user_roles WHERE role = 'admin' LIMIT 1);