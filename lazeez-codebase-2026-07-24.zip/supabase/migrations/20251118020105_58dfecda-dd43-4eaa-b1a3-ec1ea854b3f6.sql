-- Fix security issues

-- 1. Update custom_kpis RLS policy to require authentication instead of public access
DROP POLICY IF EXISTS "Anyone can view KPIs" ON public.custom_kpis;

CREATE POLICY "Authenticated users can view KPIs" 
ON public.custom_kpis 
FOR SELECT 
TO authenticated
USING (true);

-- 2. Add complete RLS policies for user_roles table (admin-only access)
CREATE POLICY "Only admins can insert roles" 
ON public.user_roles 
FOR INSERT 
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Only admins can update roles" 
ON public.user_roles 
FOR UPDATE 
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Only admins can delete roles" 
ON public.user_roles 
FOR DELETE 
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));