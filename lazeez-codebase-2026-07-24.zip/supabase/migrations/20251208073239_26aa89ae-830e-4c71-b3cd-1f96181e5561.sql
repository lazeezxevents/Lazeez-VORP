-- Create visitor_logs table for tracking page visits
CREATE TABLE public.visitor_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    page_name TEXT NOT NULL,
    ip_address TEXT,
    region TEXT,
    country TEXT,
    city TEXT,
    device_name TEXT,
    browser TEXT,
    os TEXT,
    visited_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    user_agent TEXT
);

-- Enable RLS
ALTER TABLE public.visitor_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can view visitor logs
CREATE POLICY "Only admins can view visitor logs"
ON public.visitor_logs
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Anyone can insert visitor logs (for tracking)
CREATE POLICY "Anyone can insert visitor logs"
ON public.visitor_logs
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Only admins can delete visitor logs
CREATE POLICY "Only admins can delete visitor logs"
ON public.visitor_logs
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));