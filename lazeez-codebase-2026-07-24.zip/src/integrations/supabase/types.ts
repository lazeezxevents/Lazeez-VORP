export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      break_phase: {
        Row: {
          activated_at: string | null
          activated_by: string | null
          created_at: string
          deactivated_at: string | null
          id: string
          is_active: boolean
          reason: string | null
          updated_at: string
        }
        Insert: {
          activated_at?: string | null
          activated_by?: string | null
          created_at?: string
          deactivated_at?: string | null
          id?: string
          is_active?: boolean
          reason?: string | null
          updated_at?: string
        }
        Update: {
          activated_at?: string | null
          activated_by?: string | null
          created_at?: string
          deactivated_at?: string | null
          id?: string
          is_active?: boolean
          reason?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      call_logs: {
        Row: {
          calls_answered: number
          calls_made: number
          created_at: string
          date: string
          id: string
          is_weekend: boolean
          total_duration_minutes: number
          updated_at: string
        }
        Insert: {
          calls_answered?: number
          calls_made?: number
          created_at?: string
          date: string
          id?: string
          is_weekend?: boolean
          total_duration_minutes?: number
          updated_at?: string
        }
        Update: {
          calls_answered?: number
          calls_made?: number
          created_at?: string
          date?: string
          id?: string
          is_weekend?: boolean
          total_duration_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      custom_kpis: {
        Row: {
          archived_at: string | null
          category: string | null
          created_at: string | null
          created_by: string | null
          critical_threshold: number | null
          description: string | null
          id: string
          is_archived: boolean
          name: string
          period_end_date: string | null
          period_label: string | null
          period_start_date: string | null
          previous_total: number | null
          sort_order: number | null
          target_value: number | null
          type: string
          updated_at: string | null
          value: number | null
          value_before_archive: number | null
          warning_threshold: number | null
        }
        Insert: {
          archived_at?: string | null
          category?: string | null
          created_at?: string | null
          created_by?: string | null
          critical_threshold?: number | null
          description?: string | null
          id?: string
          is_archived?: boolean
          name: string
          period_end_date?: string | null
          period_label?: string | null
          period_start_date?: string | null
          previous_total?: number | null
          sort_order?: number | null
          target_value?: number | null
          type: string
          updated_at?: string | null
          value?: number | null
          value_before_archive?: number | null
          warning_threshold?: number | null
        }
        Update: {
          archived_at?: string | null
          category?: string | null
          created_at?: string | null
          created_by?: string | null
          critical_threshold?: number | null
          description?: string | null
          id?: string
          is_archived?: boolean
          name?: string
          period_end_date?: string | null
          period_label?: string | null
          period_start_date?: string | null
          previous_total?: number | null
          sort_order?: number | null
          target_value?: number | null
          type?: string
          updated_at?: string | null
          value?: number | null
          value_before_archive?: number | null
          warning_threshold?: number | null
        }
        Relationships: []
      }
      dashboard_bookmarks: {
        Row: {
          created_at: string
          filters: Json
          id: string
          name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          filters?: Json
          id?: string
          name: string
          user_id: string
        }
        Update: {
          created_at?: string
          filters?: Json
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      kpi_annotations: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          is_pinned: boolean
          kpi_id: string
          note: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_pinned?: boolean
          kpi_id: string
          note: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          is_pinned?: boolean
          kpi_id?: string
          note?: string
        }
        Relationships: [
          {
            foreignKeyName: "kpi_annotations_kpi_id_fkey"
            columns: ["kpi_id"]
            isOneToOne: false
            referencedRelation: "custom_kpis"
            referencedColumns: ["id"]
          },
        ]
      }
      kpi_archive_history: {
        Row: {
          archived_at: string
          category: string | null
          description: string | null
          id: string
          kpi_id: string
          kpi_name: string
          period_end_date: string | null
          period_label: string | null
          period_start_date: string | null
          value_at_archive: number
        }
        Insert: {
          archived_at?: string
          category?: string | null
          description?: string | null
          id?: string
          kpi_id: string
          kpi_name: string
          period_end_date?: string | null
          period_label?: string | null
          period_start_date?: string | null
          value_at_archive: number
        }
        Update: {
          archived_at?: string
          category?: string | null
          description?: string | null
          id?: string
          kpi_id?: string
          kpi_name?: string
          period_end_date?: string | null
          period_label?: string | null
          period_start_date?: string | null
          value_at_archive?: number
        }
        Relationships: []
      }
      sales_cycle_data: {
        Row: {
          created_at: string
          id: string
          quarter: string
          sort_order: number
          updated_at: string
          weeks: number
        }
        Insert: {
          created_at?: string
          id?: string
          quarter: string
          sort_order?: number
          updated_at?: string
          weeks?: number
        }
        Update: {
          created_at?: string
          id?: string
          quarter?: string
          sort_order?: number
          updated_at?: string
          weeks?: number
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vendor_responses: {
        Row: {
          created_at: string
          date: string
          id: string
          inquiries_received: number
          inquiries_received_weekend: number
          inquiries_responded: number
          inquiries_responded_weekend: number
          is_archived: boolean
          is_weekend: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          date: string
          id?: string
          inquiries_received?: number
          inquiries_received_weekend?: number
          inquiries_responded?: number
          inquiries_responded_weekend?: number
          is_archived?: boolean
          is_weekend?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          date?: string
          id?: string
          inquiries_received?: number
          inquiries_received_weekend?: number
          inquiries_responded?: number
          inquiries_responded_weekend?: number
          is_archived?: boolean
          is_weekend?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      visitor_clicks: {
        Row: {
          clicked_at: string
          element_class: string | null
          element_id: string | null
          element_tag: string | null
          element_text: string | null
          id: string
          page_name: string
          session_id: string
          x_percent: number
          x_position: number
          y_percent: number
          y_position: number
        }
        Insert: {
          clicked_at?: string
          element_class?: string | null
          element_id?: string | null
          element_tag?: string | null
          element_text?: string | null
          id?: string
          page_name: string
          session_id: string
          x_percent: number
          x_position: number
          y_percent: number
          y_position: number
        }
        Update: {
          clicked_at?: string
          element_class?: string | null
          element_id?: string | null
          element_tag?: string | null
          element_text?: string | null
          id?: string
          page_name?: string
          session_id?: string
          x_percent?: number
          x_position?: number
          y_percent?: number
          y_position?: number
        }
        Relationships: []
      }
      visitor_logs: {
        Row: {
          browser: string | null
          city: string | null
          country: string | null
          device_name: string | null
          id: string
          ip_address: string | null
          os: string | null
          page_name: string
          region: string | null
          user_agent: string | null
          visited_at: string
        }
        Insert: {
          browser?: string | null
          city?: string | null
          country?: string | null
          device_name?: string | null
          id?: string
          ip_address?: string | null
          os?: string | null
          page_name: string
          region?: string | null
          user_agent?: string | null
          visited_at?: string
        }
        Update: {
          browser?: string | null
          city?: string | null
          country?: string | null
          device_name?: string | null
          id?: string
          ip_address?: string | null
          os?: string | null
          page_name?: string
          region?: string | null
          user_agent?: string | null
          visited_at?: string
        }
        Relationships: []
      }
      visitor_scroll_depth: {
        Row: {
          id: string
          max_depth_percent: number
          page_height: number | null
          page_name: string
          recorded_at: string
          session_id: string
          viewport_height: number | null
        }
        Insert: {
          id?: string
          max_depth_percent?: number
          page_height?: number | null
          page_name: string
          recorded_at?: string
          session_id: string
          viewport_height?: number | null
        }
        Update: {
          id?: string
          max_depth_percent?: number
          page_height?: number | null
          page_name?: string
          recorded_at?: string
          session_id?: string
          viewport_height?: number | null
        }
        Relationships: []
      }
      visitor_session_recordings: {
        Row: {
          chunk_index: number
          created_at: string
          event_count: number
          events: Json
          id: string
          page_name: string
          session_id: string
        }
        Insert: {
          chunk_index?: number
          created_at?: string
          event_count?: number
          events?: Json
          id?: string
          page_name: string
          session_id: string
        }
        Update: {
          chunk_index?: number
          created_at?: string
          event_count?: number
          events?: Json
          id?: string
          page_name?: string
          session_id?: string
        }
        Relationships: []
      }
      visitor_sessions: {
        Row: {
          connection_type: string | null
          created_at: string
          duration_seconds: number | null
          ended_at: string | null
          id: string
          is_bounce: boolean | null
          language: string | null
          max_scroll_depth_percent: number | null
          pages_visited: string[] | null
          referrer: string | null
          screen_height: number | null
          screen_width: number | null
          session_id: string
          started_at: string
          timezone: string | null
          total_clicks: number | null
          total_scroll_events: number | null
          viewport_height: number | null
          viewport_width: number | null
          visitor_log_id: string | null
        }
        Insert: {
          connection_type?: string | null
          created_at?: string
          duration_seconds?: number | null
          ended_at?: string | null
          id?: string
          is_bounce?: boolean | null
          language?: string | null
          max_scroll_depth_percent?: number | null
          pages_visited?: string[] | null
          referrer?: string | null
          screen_height?: number | null
          screen_width?: number | null
          session_id: string
          started_at?: string
          timezone?: string | null
          total_clicks?: number | null
          total_scroll_events?: number | null
          viewport_height?: number | null
          viewport_width?: number | null
          visitor_log_id?: string | null
        }
        Update: {
          connection_type?: string | null
          created_at?: string
          duration_seconds?: number | null
          ended_at?: string | null
          id?: string
          is_bounce?: boolean | null
          language?: string | null
          max_scroll_depth_percent?: number | null
          pages_visited?: string[] | null
          referrer?: string | null
          screen_height?: number | null
          screen_width?: number | null
          session_id?: string
          started_at?: string
          timezone?: string | null
          total_clicks?: number | null
          total_scroll_events?: number | null
          viewport_height?: number | null
          viewport_width?: number | null
          visitor_log_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "visitor_sessions_visitor_log_id_fkey"
            columns: ["visitor_log_id"]
            isOneToOne: false
            referencedRelation: "visitor_logs"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
