import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface DeviceInfo {
  browser: string;
  browserVersion: string;
  os: string;
  osVersion: string;
  device: string;
  deviceType: string;
  architecture: string;
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
}

const parseUserAgent = (ua: string): DeviceInfo => {
  let browser = 'Unknown';
  let browserVersion = '';
  let os = 'Unknown';
  let osVersion = '';
  let device = 'Desktop';
  let deviceType = 'Desktop';
  let architecture = 'Unknown';
  let isMobile = false;
  let isTablet = false;
  let isDesktop = true;

  // ===== BROWSER DETECTION =====
  // Order matters - check more specific browsers first
  
  // Samsung Internet
  if (ua.includes('SamsungBrowser')) {
    browser = 'Samsung Internet';
    const match = ua.match(/SamsungBrowser\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // UC Browser
  else if (ua.includes('UCBrowser') || ua.includes('UCWEB')) {
    browser = 'UC Browser';
    const match = ua.match(/UCBrowser\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Brave
  else if (ua.includes('Brave')) {
    browser = 'Brave';
  }
  // Vivaldi
  else if (ua.includes('Vivaldi')) {
    browser = 'Vivaldi';
    const match = ua.match(/Vivaldi\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Opera GX
  else if (ua.includes('OPR') && ua.includes('GX')) {
    browser = 'Opera GX';
    const match = ua.match(/OPR\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Opera
  else if (ua.includes('OPR') || ua.includes('Opera')) {
    browser = 'Opera';
    const match = ua.match(/OPR\/([\d.]+)/) || ua.match(/Opera\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Edge (Chromium-based)
  else if (ua.includes('Edg/')) {
    browser = 'Edge';
    const match = ua.match(/Edg\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Edge (Legacy)
  else if (ua.includes('Edge/')) {
    browser = 'Edge Legacy';
    const match = ua.match(/Edge\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Firefox
  else if (ua.includes('Firefox') || ua.includes('FxiOS')) {
    browser = 'Firefox';
    const match = ua.match(/Firefox\/([\d.]+)/) || ua.match(/FxiOS\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Chrome iOS
  else if (ua.includes('CriOS')) {
    browser = 'Chrome iOS';
    const match = ua.match(/CriOS\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Chrome
  else if (ua.includes('Chrome') && !ua.includes('Chromium')) {
    browser = 'Chrome';
    const match = ua.match(/Chrome\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Chromium
  else if (ua.includes('Chromium')) {
    browser = 'Chromium';
    const match = ua.match(/Chromium\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Safari (must be after Chrome check)
  else if (ua.includes('Safari') && !ua.includes('Chrome')) {
    browser = 'Safari';
    const match = ua.match(/Version\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // IE
  else if (ua.includes('MSIE') || ua.includes('Trident/')) {
    browser = 'Internet Explorer';
    const match = ua.match(/MSIE ([\d.]+)/) || ua.match(/rv:([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // Yandex Browser
  else if (ua.includes('YaBrowser')) {
    browser = 'Yandex Browser';
    const match = ua.match(/YaBrowser\/([\d.]+)/);
    if (match) browserVersion = match[1];
  }
  // DuckDuckGo
  else if (ua.includes('DuckDuckGo')) {
    browser = 'DuckDuckGo';
  }
  // Tor Browser
  else if (ua.includes('Tor')) {
    browser = 'Tor Browser';
  }

  // ===== OS DETECTION =====
  
  // iOS (iPhone/iPad/iPod)
  if (ua.includes('iPhone')) {
    os = 'iOS';
    device = 'iPhone';
    deviceType = 'Mobile';
    isMobile = true;
    isDesktop = false;
    const match = ua.match(/iPhone OS ([\d_]+)/);
    if (match) osVersion = match[1].replace(/_/g, '.');
  } else if (ua.includes('iPad')) {
    os = 'iPadOS';
    device = 'iPad';
    deviceType = 'Tablet';
    isTablet = true;
    isDesktop = false;
    const match = ua.match(/CPU OS ([\d_]+)/);
    if (match) osVersion = match[1].replace(/_/g, '.');
  } else if (ua.includes('iPod')) {
    os = 'iOS';
    device = 'iPod';
    deviceType = 'Mobile';
    isMobile = true;
    isDesktop = false;
    const match = ua.match(/iPhone OS ([\d_]+)/);
    if (match) osVersion = match[1].replace(/_/g, '.');
  }
  // Android
  else if (ua.includes('Android')) {
    os = 'Android';
    const match = ua.match(/Android ([\d.]+)/);
    if (match) osVersion = match[1];
    
    // Detect Android device type
    if (ua.includes('Mobile')) {
      device = 'Android Phone';
      deviceType = 'Mobile';
      isMobile = true;
      isDesktop = false;
    } else if (ua.includes('Tablet') || !ua.includes('Mobile')) {
      device = 'Android Tablet';
      deviceType = 'Tablet';
      isTablet = true;
      isDesktop = false;
    }
    
    // Try to detect specific Android devices
    if (ua.includes('SM-')) {
      device = 'Samsung Galaxy';
    } else if (ua.includes('Pixel')) {
      device = 'Google Pixel';
    } else if (ua.includes('HUAWEI') || ua.includes('Huawei')) {
      device = 'Huawei';
    } else if (ua.includes('Xiaomi') || ua.includes('Redmi') || ua.includes('POCO')) {
      device = 'Xiaomi';
    } else if (ua.includes('OPPO') || ua.includes('Oppo')) {
      device = 'Oppo';
    } else if (ua.includes('vivo') || ua.includes('Vivo')) {
      device = 'Vivo';
    } else if (ua.includes('OnePlus')) {
      device = 'OnePlus';
    } else if (ua.includes('Motorola') || ua.includes('moto')) {
      device = 'Motorola';
    } else if (ua.includes('LG')) {
      device = 'LG';
    } else if (ua.includes('Sony') || ua.includes('Xperia')) {
      device = 'Sony Xperia';
    } else if (ua.includes('Nokia')) {
      device = 'Nokia';
    } else if (ua.includes('Realme')) {
      device = 'Realme';
    }
  }
  // Windows
  else if (ua.includes('Windows')) {
    os = 'Windows';
    device = 'Windows PC';
    deviceType = 'Desktop';
    
    if (ua.includes('Windows NT 10.0')) {
      // Could be Windows 10 or 11, check for Windows 11 hints
      if (ua.includes('Windows NT 10.0; Win64; x64') && parseInt(browserVersion) >= 100) {
        osVersion = '10/11';
      } else {
        osVersion = '10';
      }
    } else if (ua.includes('Windows NT 6.3')) {
      osVersion = '8.1';
    } else if (ua.includes('Windows NT 6.2')) {
      osVersion = '8';
    } else if (ua.includes('Windows NT 6.1')) {
      osVersion = '7';
    } else if (ua.includes('Windows NT 6.0')) {
      osVersion = 'Vista';
    } else if (ua.includes('Windows NT 5.1') || ua.includes('Windows XP')) {
      osVersion = 'XP';
    }
    
    // Windows tablets
    if (ua.includes('Touch') || ua.includes('Tablet PC')) {
      device = 'Windows Tablet';
      deviceType = 'Tablet';
      isTablet = true;
      isDesktop = false;
    }
    // Windows phones
    if (ua.includes('Windows Phone') || ua.includes('IEMobile')) {
      os = 'Windows Phone';
      device = 'Windows Phone';
      deviceType = 'Mobile';
      isMobile = true;
      isDesktop = false;
    }
  }
  // macOS
  else if (ua.includes('Mac OS X') || ua.includes('Macintosh')) {
    os = 'macOS';
    device = 'Mac';
    deviceType = 'Desktop';
    
    const match = ua.match(/Mac OS X ([\d_]+)/);
    if (match) osVersion = match[1].replace(/_/g, '.');
    
    // macOS version names
    const majorVersion = parseInt(osVersion.split('.')[0]);
    const minorVersion = parseInt(osVersion.split('.')[1]) || 0;
    
    if (majorVersion === 10) {
      if (minorVersion === 15) osVersion += ' (Catalina)';
      else if (minorVersion === 14) osVersion += ' (Mojave)';
      else if (minorVersion === 13) osVersion += ' (High Sierra)';
    } else if (majorVersion >= 11) {
      // macOS 11+ (Big Sur onwards)
      if (majorVersion === 11) osVersion += ' (Big Sur)';
      else if (majorVersion === 12) osVersion += ' (Monterey)';
      else if (majorVersion === 13) osVersion += ' (Ventura)';
      else if (majorVersion === 14) osVersion += ' (Sonoma)';
      else if (majorVersion === 15) osVersion += ' (Sequoia)';
    }
  }
  // Linux variants
  else if (ua.includes('Linux')) {
    // ChromeOS
    if (ua.includes('CrOS')) {
      os = 'ChromeOS';
      device = 'Chromebook';
      deviceType = 'Desktop';
    }
    // Ubuntu
    else if (ua.includes('Ubuntu')) {
      os = 'Ubuntu Linux';
      device = 'Linux PC';
    }
    // Fedora
    else if (ua.includes('Fedora')) {
      os = 'Fedora Linux';
      device = 'Linux PC';
    }
    // Debian
    else if (ua.includes('Debian')) {
      os = 'Debian Linux';
      device = 'Linux PC';
    }
    // Arch
    else if (ua.includes('Arch')) {
      os = 'Arch Linux';
      device = 'Linux PC';
    }
    // Generic Linux
    else {
      os = 'Linux';
      device = 'Linux PC';
    }
    deviceType = 'Desktop';
  }
  // FreeBSD
  else if (ua.includes('FreeBSD')) {
    os = 'FreeBSD';
    device = 'BSD System';
    deviceType = 'Desktop';
  }
  // Kindle Fire
  else if (ua.includes('Kindle') || ua.includes('Silk')) {
    os = 'Fire OS';
    device = 'Kindle Fire';
    deviceType = 'Tablet';
    isTablet = true;
    isDesktop = false;
  }
  // PlayStation
  else if (ua.includes('PlayStation')) {
    os = 'PlayStation OS';
    deviceType = 'Console';
    isDesktop = false;
    if (ua.includes('PlayStation 5')) {
      device = 'PlayStation 5';
    } else if (ua.includes('PlayStation 4')) {
      device = 'PlayStation 4';
    } else if (ua.includes('PlayStation Vita')) {
      device = 'PlayStation Vita';
    } else {
      device = 'PlayStation';
    }
  }
  // Xbox
  else if (ua.includes('Xbox')) {
    os = 'Xbox OS';
    device = ua.includes('Xbox One') ? 'Xbox One' : 'Xbox';
    deviceType = 'Console';
    isDesktop = false;
  }
  // Nintendo
  else if (ua.includes('Nintendo')) {
    os = 'Nintendo OS';
    deviceType = 'Console';
    isDesktop = false;
    if (ua.includes('Switch')) {
      device = 'Nintendo Switch';
    } else if (ua.includes('Wii U')) {
      device = 'Wii U';
    } else if (ua.includes('3DS')) {
      device = 'Nintendo 3DS';
    } else {
      device = 'Nintendo Device';
    }
  }

  // ===== ARCHITECTURE DETECTION =====
  if (ua.includes('arm64') || ua.includes('aarch64')) {
    architecture = 'ARM64';
  } else if (ua.includes('armv7') || ua.includes('arm')) {
    architecture = 'ARM32';
  } else if (ua.includes('Win64') || ua.includes('x64') || ua.includes('x86_64') || ua.includes('amd64')) {
    architecture = 'x64';
  } else if (ua.includes('WOW64') || ua.includes('i686') || ua.includes('i386') || ua.includes('x86')) {
    architecture = 'x86';
  }
  
  // Apple Silicon detection for Mac
  if (os === 'macOS' && (ua.includes('Apple') || (browser === 'Safari' && parseInt(browserVersion) >= 14))) {
    // Modern Safari on macOS might be Apple Silicon
    if (architecture === 'Unknown') {
      architecture = 'Apple Silicon / Intel';
    }
  }

  // Format the full browser string
  const browserFull = browserVersion ? `${browser} ${browserVersion.split('.')[0]}` : browser;
  const osFull = osVersion ? `${os} ${osVersion}` : os;

  return {
    browser: browserFull,
    browserVersion,
    os: osFull,
    osVersion,
    device,
    deviceType,
    architecture,
    isMobile,
    isTablet,
    isDesktop,
  };
};

export const useVisitorTracking = (pageName: string) => {
  useEffect(() => {
    const logVisitor = async () => {
      try {
        const userAgent = navigator.userAgent;
        const deviceInfo = parseUserAgent(userAgent);

        // Create comprehensive device name
        const deviceName = `${deviceInfo.device} (${deviceInfo.deviceType})`;
        
        // Create detailed browser string
        const browserDetails = `${deviceInfo.browser}`;
        
        // Create detailed OS string with architecture
        const osDetails = deviceInfo.architecture !== 'Unknown' 
          ? `${deviceInfo.os} [${deviceInfo.architecture}]`
          : deviceInfo.os;

        await supabase.functions.invoke('log-visitor', {
          body: {
            page_name: pageName,
            user_agent: userAgent,
            device_name: deviceName,
            browser: browserDetails,
            os: osDetails,
          },
        });
      } catch (error) {
        // Silently fail - don't disrupt user experience
        console.error('Visitor tracking failed:', error);
      }
    };

    logVisitor();
  }, [pageName]);
};
