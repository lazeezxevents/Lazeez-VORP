import { useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { record } from 'rrweb';

const generateSessionId = () => {
  const stored = sessionStorage.getItem('visitor_session_id');
  if (stored) return stored;
  const id = `${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
  sessionStorage.setItem('visitor_session_id', id);
  return id;
};

const sendTrackingData = async (type: string, sessionId: string, pageName: string, data: any) => {
  try {
    await supabase.functions.invoke('track-visitor-events', {
      body: { type, session_id: sessionId, page_name: pageName, data },
    });
  } catch (e) {
    // Silently fail
  }
};

export const useAdvancedTracking = (pageName: string) => {
  const sessionId = useRef(generateSessionId());
  const clickBuffer = useRef<any[]>([]);
  const clickFlushTimer = useRef<ReturnType<typeof setTimeout>>();
  const maxScrollDepth = useRef(0);
  const scrollTimer = useRef<ReturnType<typeof setTimeout>>();
  const sessionStartTime = useRef(Date.now());
  const pagesVisited = useRef<string[]>([]);
  const totalClicks = useRef(0);
  const recordingChunkIndex = useRef(0);
  const rrwebEvents = useRef<any[]>([]);
  const rrwebFlushTimer = useRef<ReturnType<typeof setTimeout>>();
  const stopRecording = useRef<(() => void) | null>(null);

  // Track page visit
  useEffect(() => {
    if (!pagesVisited.current.includes(pageName)) {
      pagesVisited.current.push(pageName);
    }
  }, [pageName]);

  // Flush click buffer
  const flushClicks = useCallback(() => {
    if (clickBuffer.current.length === 0) return;
    const clicks = [...clickBuffer.current];
    clickBuffer.current = [];
    sendTrackingData('clicks', sessionId.current, pageName, { clicks });
  }, [pageName]);

  // Flush recording events
  const flushRecording = useCallback(() => {
    if (rrwebEvents.current.length === 0) return;
    const events = [...rrwebEvents.current];
    rrwebEvents.current = [];
    sendTrackingData('recording', sessionId.current, pageName, {
      events,
      chunk_index: recordingChunkIndex.current++,
    });
  }, [pageName]);

  // Click tracking
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      totalClicks.current++;

      clickBuffer.current.push({
        x_position: e.clientX,
        y_position: e.clientY,
        x_percent: parseFloat(((e.clientX / window.innerWidth) * 100).toFixed(2)),
        y_percent: parseFloat(((e.clientY / window.innerHeight) * 100).toFixed(2)),
        element_tag: target.tagName.toLowerCase(),
        element_text: target.textContent?.trim().substring(0, 100) || '',
        element_id: target.id || null,
        element_class: target.className?.toString().substring(0, 200) || null,
        clicked_at: new Date().toISOString(),
      });

      // Batch flush every 5 seconds or 20 clicks
      if (clickBuffer.current.length >= 20) {
        flushClicks();
      } else {
        clearTimeout(clickFlushTimer.current);
        clickFlushTimer.current = setTimeout(flushClicks, 5000);
      }
    };

    document.addEventListener('click', handleClick, { passive: true });
    return () => {
      document.removeEventListener('click', handleClick);
      flushClicks();
    };
  }, [flushClicks]);

  // Scroll depth tracking
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      const depth = scrollHeight > 0 ? Math.round((scrollTop / scrollHeight) * 100) : 0;

      if (depth > maxScrollDepth.current) {
        maxScrollDepth.current = depth;
      }

      clearTimeout(scrollTimer.current);
      scrollTimer.current = setTimeout(() => {
        sendTrackingData('scroll', sessionId.current, pageName, {
          max_depth_percent: maxScrollDepth.current,
          page_height: document.documentElement.scrollHeight,
          viewport_height: window.innerHeight,
        });
      }, 2000);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [pageName]);

  // Session recording with rrweb
  useEffect(() => {
    try {
      stopRecording.current = record({
        emit(event) {
          rrwebEvents.current.push(event);

          // Flush every 50 events or every 10 seconds
          if (rrwebEvents.current.length >= 50) {
            flushRecording();
          } else {
            clearTimeout(rrwebFlushTimer.current);
            rrwebFlushTimer.current = setTimeout(flushRecording, 10000);
          }
        },
        sampling: {
          mousemove: 50,
          mouseInteraction: true,
          scroll: 150,
          media: 800,
          input: 'last',
        },
        blockClass: 'rr-block',
        maskInputOptions: {
          password: true,
        },
      });
    } catch (e) {
      console.error('rrweb recording failed to start:', e);
    }

    return () => {
      if (stopRecording.current) {
        stopRecording.current();
      }
      flushRecording();
    };
  }, [pageName, flushRecording]);

  // Session metadata - send on mount and before unload
  useEffect(() => {
    const getConnectionType = () => {
      const nav = navigator as any;
      return nav.connection?.effectiveType || nav.connection?.type || 'unknown';
    };

    const sessionData = {
      started_at: new Date(sessionStartTime.current).toISOString(),
      screen_width: window.screen.width,
      screen_height: window.screen.height,
      viewport_width: window.innerWidth,
      viewport_height: window.innerHeight,
      referrer: document.referrer || null,
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      connection_type: getConnectionType(),
      pages_visited: pagesVisited.current,
      total_clicks: totalClicks.current,
      max_scroll_depth_percent: maxScrollDepth.current,
      is_bounce: pagesVisited.current.length <= 1,
    };

    sendTrackingData('session', sessionId.current, pageName, sessionData);

    const handleBeforeUnload = () => {
      const duration = Math.round((Date.now() - sessionStartTime.current) / 1000);
      const finalData = {
        ...sessionData,
        ended_at: new Date().toISOString(),
        duration_seconds: duration,
        pages_visited: pagesVisited.current,
        total_clicks: totalClicks.current,
        max_scroll_depth_percent: maxScrollDepth.current,
        is_bounce: pagesVisited.current.length <= 1,
      };

      // Use sendBeacon for reliability
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/track-visitor-events`;
      const body = JSON.stringify({
        type: 'session',
        session_id: sessionId.current,
        page_name: pageName,
        data: finalData,
      });

      navigator.sendBeacon(url, body);
      
      // Also flush remaining clicks and recordings
      flushClicks();
      flushRecording();
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [pageName, flushClicks, flushRecording]);
};
