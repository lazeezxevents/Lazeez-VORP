import { useMemo } from 'react';
import { format, subDays, startOfDay, eachDayOfInterval, parseISO } from 'date-fns';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Calendar } from 'lucide-react';

interface VisitorLog {
  id: string;
  page_name: string;
  visited_at: string;
}

interface VisitorTrendChartProps {
  logs: VisitorLog[];
}

export const VisitorTrendChart = ({ logs }: VisitorTrendChartProps) => {
  const dailyData = useMemo(() => {
    const last14Days = eachDayOfInterval({
      start: subDays(new Date(), 13),
      end: new Date(),
    });

    return last14Days.map(day => {
      const dayStart = startOfDay(day);
      const dayEnd = new Date(dayStart);
      dayEnd.setHours(23, 59, 59, 999);

      const mainCount = logs.filter(log => {
        const visitDate = parseISO(log.visited_at);
        return visitDate >= dayStart && visitDate <= dayEnd && log.page_name === 'Main Dashboard';
      }).length;

      const vendorCount = logs.filter(log => {
        const visitDate = parseISO(log.visited_at);
        return visitDate >= dayStart && visitDate <= dayEnd && log.page_name === 'Vendor Responses';
      }).length;

      return {
        date: format(day, 'MMM dd'),
        fullDate: format(day, 'EEEE, MMM dd, yyyy'),
        Main: mainCount,
        Vendor: vendorCount,
        total: mainCount + vendorCount,
      };
    });
  }, [logs]);

  const weeklyData = useMemo(() => {
    const weeks: { [key: string]: { main: number; vendor: number } } = {};
    
    logs.forEach(log => {
      const visitDate = parseISO(log.visited_at);
      const weekStart = startOfDay(subDays(visitDate, visitDate.getDay()));
      const weekKey = format(weekStart, 'MMM dd');
      
      if (!weeks[weekKey]) {
        weeks[weekKey] = { main: 0, vendor: 0 };
      }
      
      if (log.page_name === 'Main Dashboard') {
        weeks[weekKey].main++;
      } else {
        weeks[weekKey].vendor++;
      }
    });

    return Object.entries(weeks)
      .map(([week, counts]) => ({
        week,
        Main: counts.main,
        Vendor: counts.vendor,
        total: counts.main + counts.vendor,
      }))
      .slice(-8); // Last 8 weeks
  }, [logs]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-card p-3 border border-border/50 rounded-lg shadow-lg">
          <p className="text-sm font-medium text-foreground mb-2">{payload[0]?.payload?.fullDate || label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-xs" style={{ color: entry.color }}>
              {entry.name}: <span className="font-bold">{entry.value}</span>
            </p>
          ))}
          <p className="text-xs text-muted-foreground mt-1 pt-1 border-t border-border/50">
            Total: <span className="font-bold">{payload[0]?.payload?.total}</span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="glass-card p-4 rounded-lg">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="h-5 w-5 text-primary" />
        <h3 className="text-lg font-semibold">Visitor Trends</h3>
      </div>
      
      <Tabs defaultValue="daily" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="daily" className="gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            Daily (14 days)
          </TabsTrigger>
          <TabsTrigger value="weekly" className="gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            Weekly
          </TabsTrigger>
        </TabsList>

        <TabsContent value="daily">
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyData}>
                <defs>
                  <linearGradient id="colorMain" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorVendor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 10 }} 
                  className="text-muted-foreground"
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 10 }} 
                  className="text-muted-foreground"
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="Main"
                  stackId="1"
                  stroke="hsl(var(--primary))"
                  fill="url(#colorMain)"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="Vendor"
                  stackId="1"
                  stroke="hsl(var(--chart-2))"
                  fill="url(#colorVendor)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </TabsContent>

        <TabsContent value="weekly">
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                <XAxis 
                  dataKey="week" 
                  tick={{ fontSize: 10 }} 
                  className="text-muted-foreground"
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 10 }} 
                  className="text-muted-foreground"
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar 
                  dataKey="Main" 
                  stackId="a" 
                  fill="hsl(var(--primary))" 
                  radius={[0, 0, 0, 0]}
                />
                <Bar 
                  dataKey="Vendor" 
                  stackId="a" 
                  fill="hsl(var(--chart-2))" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </TabsContent>
      </Tabs>

      <div className="flex items-center justify-center gap-6 mt-4 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-primary" />
          <span className="text-muted-foreground">Main Dashboard</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'hsl(var(--chart-2))' }} />
          <span className="text-muted-foreground">Vendor Responses</span>
        </div>
      </div>
    </div>
  );
};
