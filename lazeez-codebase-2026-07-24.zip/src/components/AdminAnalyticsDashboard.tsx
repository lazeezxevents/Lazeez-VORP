import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { format, isWithinInterval, startOfDay, endOfDay } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Monitor, 
  Smartphone, 
  Tablet, 
  Globe, 
  Clock, 
  MapPin, 
  Trash2,
  RefreshCw,
  LayoutDashboard,
  Users,
  Download,
  Activity,
  Laptop,
  Gamepad2,
  Cpu,
  Chrome,
  Apple,
  SquareTerminal,
  MousePointerClick,
  ArrowDown,
  Play,
  Eye,
} from 'lucide-react';
import { toast } from 'sonner';
import { VisitorTrendChart } from './VisitorTrendChart';
import { VisitorGeographicChart } from './VisitorGeographicChart';
import { VisitorDeviceChart } from './VisitorDeviceChart';
import { VisitorPeakHoursChart } from './VisitorPeakHoursChart';
import { DateRangeFilter } from './DateRangeFilter';
import { HeatmapOverlay } from './HeatmapOverlay';
import { ScrollDepthChart } from './ScrollDepthChart';
import { SessionReplayViewer } from './SessionReplayViewer';

interface VisitorLog {
  id: string;
  page_name: string;
  ip_address: string | null;
  region: string | null;
  country: string | null;
  city: string | null;
  device_name: string | null;
  browser: string | null;
  os: string | null;
  visited_at: string;
  user_agent: string | null;
}

interface DateRange {
  from: Date | undefined;
  to: Date | undefined;
}

interface AdminAnalyticsDashboardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  fullPage?: boolean;
}

export const AdminAnalyticsDashboard = ({ open, onOpenChange, fullPage = false }: AdminAnalyticsDashboardProps) => {
  const [logs, setLogs] = useState<VisitorLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState('overview');
  const [dateRange, setDateRange] = useState<DateRange>({ from: undefined, to: undefined });
  const [clickData, setClickData] = useState<any[]>([]);
  const [scrollData, setScrollData] = useState<any[]>([]);
  const [heatmapPage, setHeatmapPage] = useState('Main Dashboard');

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('visitor_logs')
        .select('*')
        .order('visited_at', { ascending: false })
        .limit(1000);

      if (error) throw error;
      setLogs(data || []);
    } catch (error) {
      console.error('Error fetching logs:', error);
      toast.error('Failed to fetch visitor logs');
    } finally {
      setLoading(false);
    }
  };

  const fetchClickData = async () => {
    try {
      const { data, error } = await supabase
        .from('visitor_clicks')
        .select('*')
        .order('clicked_at', { ascending: false })
        .limit(5000);
      if (error) throw error;
      setClickData((data as any[]) || []);
    } catch (e) {
      console.error('Error fetching click data:', e);
    }
  };

  const fetchScrollData = async () => {
    try {
      const { data, error } = await supabase
        .from('visitor_scroll_depth')
        .select('*')
        .order('recorded_at', { ascending: false })
        .limit(1000);
      if (error) throw error;
      setScrollData((data as any[]) || []);
    } catch (e) {
      console.error('Error fetching scroll data:', e);
    }
  };

  useEffect(() => {
    if (open) {
      fetchLogs();
      fetchClickData();
      fetchScrollData();
    }
  }, [open]);

  // Filter logs by date range
  const filteredLogs = useMemo(() => {
    if (!dateRange.from && !dateRange.to) return logs;
    
    return logs.filter(log => {
      const logDate = new Date(log.visited_at);
      
      if (dateRange.from && dateRange.to) {
        return isWithinInterval(logDate, {
          start: startOfDay(dateRange.from),
          end: endOfDay(dateRange.to)
        });
      }
      
      if (dateRange.from) {
        return logDate >= startOfDay(dateRange.from);
      }
      
      return true;
    });
  }, [logs, dateRange]);

  const clearLogs = async () => {
    if (!confirm('Are you sure you want to clear all visitor logs?')) return;
    
    try {
      const { error } = await supabase
        .from('visitor_logs')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');

      if (error) throw error;
      toast.success('All logs cleared');
      fetchLogs();
    } catch (error) {
      console.error('Error clearing logs:', error);
      toast.error('Failed to clear logs');
    }
  };

  const exportToCSV = () => {
    if (filteredLogs.length === 0) {
      toast.error('No logs to export');
      return;
    }

    const headers = ['Page', 'Device', 'Device Type', 'Browser', 'OS', 'Architecture', 'City', 'Region', 'Country', 'IP Address', 'User Agent', 'Visited At'];
    const csvData = filteredLogs.map(log => {
      // Extract architecture from OS if present
      const osMatch = log.os?.match(/\[([^\]]+)\]/);
      const architecture = osMatch ? osMatch[1] : 'Unknown';
      const osClean = log.os?.replace(/\s*\[[^\]]+\]/, '') || 'Unknown';
      
      // Extract device type from device name
      const deviceMatch = log.device_name?.match(/\(([^)]+)\)/);
      const deviceType = deviceMatch ? deviceMatch[1] : 'Desktop';
      const deviceClean = log.device_name?.replace(/\s*\([^)]+\)/, '') || 'Unknown';
      
      return [
        log.page_name,
        deviceClean,
        deviceType,
        log.browser || 'Unknown',
        osClean,
        architecture,
        log.city || 'Unknown',
        log.region || 'Unknown',
        log.country || 'Unknown',
        log.ip_address || 'Unknown',
        log.user_agent || '',
        format(new Date(log.visited_at), 'yyyy-MM-dd hh:mm:ss a'),
      ];
    });

    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `visitor-logs-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Visitor logs exported successfully');
  };

  const getDeviceIcon = (device: string | null) => {
    const deviceLower = device?.toLowerCase() || '';
    if (deviceLower.includes('mobile') || deviceLower.includes('phone')) {
      return <Smartphone className="h-4 w-4" />;
    } else if (deviceLower.includes('tablet') || deviceLower.includes('ipad')) {
      return <Tablet className="h-4 w-4" />;
    } else if (deviceLower.includes('console') || deviceLower.includes('playstation') || deviceLower.includes('xbox') || deviceLower.includes('nintendo')) {
      return <Gamepad2 className="h-4 w-4" />;
    } else if (deviceLower.includes('mac') || deviceLower.includes('chromebook')) {
      return <Laptop className="h-4 w-4" />;
    }
    return <Monitor className="h-4 w-4" />;
  };

  const getOSIcon = (os: string | null) => {
    const osLower = os?.toLowerCase() || '';
    if (osLower.includes('ios') || osLower.includes('macos') || osLower.includes('ipados')) {
      return <Apple className="h-3 w-3" />;
    } else if (osLower.includes('chrome')) {
      return <Chrome className="h-3 w-3" />;
    } else if (osLower.includes('linux') || osLower.includes('ubuntu') || osLower.includes('debian')) {
      return <SquareTerminal className="h-3 w-3" />;
    }
    return <Cpu className="h-3 w-3" />;
  };

  // Calculate stats
  const mainPageCount = filteredLogs.filter(l => l.page_name === 'Main Dashboard').length;
  const vendorPageCount = filteredLogs.filter(l => l.page_name === 'Vendor Responses').length;
  const callsPageCount = filteredLogs.filter(l => l.page_name === 'Vendor Calls').length;
  const analyticsPageCount = filteredLogs.filter(l => l.page_name === 'Analytics Dashboard').length;
  const uniqueIPs = new Set(filteredLogs.map(l => l.ip_address)).size;
  const todayCount = filteredLogs.filter(l => {
    const today = new Date().toDateString();
    return new Date(l.visited_at).toDateString() === today;
  }).length;

  // Device type breakdown
  const deviceBreakdown = useMemo(() => {
    const breakdown: Record<string, number> = { Mobile: 0, Tablet: 0, Desktop: 0, Console: 0, Other: 0 };
    filteredLogs.forEach(log => {
      const device = log.device_name?.toLowerCase() || '';
      if (device.includes('mobile') || device.includes('phone')) breakdown.Mobile++;
      else if (device.includes('tablet') || device.includes('ipad')) breakdown.Tablet++;
      else if (device.includes('console') || device.includes('playstation') || device.includes('xbox') || device.includes('nintendo')) breakdown.Console++;
      else if (device.includes('desktop') || device.includes('pc') || device.includes('mac') || device.includes('linux')) breakdown.Desktop++;
      else breakdown.Other++;
    });
    return breakdown;
  }, [filteredLogs]);

  // OS breakdown
  const osBreakdown = useMemo(() => {
    const breakdown: Record<string, number> = {};
    filteredLogs.forEach(log => {
      const os = log.os?.split(' ')[0] || 'Unknown';
      breakdown[os] = (breakdown[os] || 0) + 1;
    });
    return Object.entries(breakdown)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 8);
  }, [filteredLogs]);

  // Browser breakdown
  const browserBreakdown = useMemo(() => {
    const breakdown: Record<string, number> = {};
    filteredLogs.forEach(log => {
      const browser = log.browser?.split(' ')[0] || 'Unknown';
      breakdown[browser] = (breakdown[browser] || 0) + 1;
    });
    return Object.entries(breakdown)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 8);
  }, [filteredLogs]);

  // Architecture breakdown
  const archBreakdown = useMemo(() => {
    const breakdown: Record<string, number> = {};
    filteredLogs.forEach(log => {
      const match = log.os?.match(/\[([^\]]+)\]/);
      const arch = match ? match[1] : 'Unknown';
      breakdown[arch] = (breakdown[arch] || 0) + 1;
    });
    return Object.entries(breakdown)
      .sort(([, a], [, b]) => b - a);
  }, [filteredLogs]);

  const tabFilteredLogs = filteredLogs.filter(log => {
    if (selectedTab === 'overview' || selectedTab === 'geographic' || selectedTab === 'devices' || selectedTab === 'timing' || selectedTab === 'heatmap' || selectedTab === 'scroll' || selectedTab === 'recordings') return true;
    if (selectedTab === 'main') return log.page_name === 'Main Dashboard';
    if (selectedTab === 'vendor') return log.page_name === 'Vendor Responses';
    if (selectedTab === 'calls') return log.page_name === 'Vendor Calls';
    return true;
  });

  const content = (
    <>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <LayoutDashboard className="h-6 w-6 text-primary" />
          <h2 className="text-xl font-bold">Visitor Analytics Dashboard</h2>
        </div>
      </div>
      <p className="text-muted-foreground text-sm mb-4">
        Comprehensive visitor tracking with device, browser, OS, and architecture detection
      </p>

      {/* Date Range Filter */}
      <div className="mb-4">
        <DateRangeFilter 
          dateRange={dateRange} 
          onDateRangeChange={setDateRange} 
        />
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-4">
        <Card className="glass-card">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <Users className="h-3.5 w-3.5" />
              Total Visits
            </div>
            <div className="text-2xl font-bold">{filteredLogs.length}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <Clock className="h-3.5 w-3.5" />
              Today
            </div>
            <div className="text-2xl font-bold">{todayCount}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <Globe className="h-3.5 w-3.5" />
              Unique IPs
            </div>
            <div className="text-2xl font-bold">{uniqueIPs}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <Smartphone className="h-3.5 w-3.5" />
              Mobile
            </div>
            <div className="text-2xl font-bold">{deviceBreakdown.Mobile}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <Monitor className="h-3.5 w-3.5" />
              Desktop
            </div>
            <div className="text-2xl font-bold">{deviceBreakdown.Desktop}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
              <Tablet className="h-3.5 w-3.5" />
              Tablet
            </div>
            <div className="text-2xl font-bold">{deviceBreakdown.Tablet}</div>
          </CardContent>
        </Card>
      </div>

      {/* Device/OS/Browser Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        {/* Top Browsers */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Chrome className="h-4 w-4" />
              Top Browsers
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {browserBreakdown.slice(0, 5).map(([browser, count]) => (
              <div key={browser} className="flex justify-between items-center text-sm">
                <span>{browser}</span>
                <Badge variant="secondary">{count}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Top OS */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Cpu className="h-4 w-4" />
              Operating Systems
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {osBreakdown.slice(0, 5).map(([os, count]) => (
              <div key={os} className="flex justify-between items-center text-sm">
                <span className="flex items-center gap-1">
                  {getOSIcon(os)} {os}
                </span>
                <Badge variant="secondary">{count}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Architecture */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Cpu className="h-4 w-4" />
              Architecture
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {archBreakdown.map(([arch, count]) => (
              <div key={arch} className="flex justify-between items-center text-sm">
                <span>{arch}</span>
                <Badge variant="secondary">{count}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Visitor Trend Chart */}
      <div className="mb-4">
        <VisitorTrendChart logs={filteredLogs} />
      </div>

      {/* Actions */}
      <div className="flex gap-2 mb-4 flex-wrap">
        <Button variant="outline" size="sm" onClick={() => { fetchLogs(); fetchClickData(); fetchScrollData(); }} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-1 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
        <Button variant="outline" size="sm" onClick={exportToCSV} disabled={filteredLogs.length === 0}>
          <Download className="h-4 w-4 mr-1" />
          Export CSV ({filteredLogs.length})
        </Button>
        <Button variant="destructive" size="sm" onClick={clearLogs}>
          <Trash2 className="h-4 w-4 mr-1" />
          Clear All
        </Button>
      </div>

      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="mb-4 flex-wrap h-auto gap-1">
          <TabsTrigger value="overview" className="gap-1">
            <Activity className="h-3 w-3" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="geographic" className="gap-1">
            <Globe className="h-3 w-3" />
            Geographic
          </TabsTrigger>
          <TabsTrigger value="devices" className="gap-1">
            <Monitor className="h-3 w-3" />
            Devices
          </TabsTrigger>
          <TabsTrigger value="timing" className="gap-1">
            <Clock className="h-3 w-3" />
            Peak Hours
          </TabsTrigger>
          <TabsTrigger value="heatmap" className="gap-1">
            <MousePointerClick className="h-3 w-3" />
            Heatmap
          </TabsTrigger>
          <TabsTrigger value="scroll" className="gap-1">
            <ArrowDown className="h-3 w-3" />
            Scroll
          </TabsTrigger>
          <TabsTrigger value="recordings" className="gap-1">
            <Play className="h-3 w-3" />
            Recordings
          </TabsTrigger>
          <TabsTrigger value="main">Main ({mainPageCount})</TabsTrigger>
          <TabsTrigger value="vendor">Responses ({vendorPageCount})</TabsTrigger>
          <TabsTrigger value="calls">Calls ({callsPageCount})</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="space-y-4">
            <ScrollArea className="h-[400px] rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Page</TableHead>
                    <TableHead>Device</TableHead>
                    <TableHead>Browser / OS</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>Date & Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        Loading...
                      </TableCell>
                    </TableRow>
                  ) : filteredLogs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        No visitor logs found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredLogs.slice(0, 50).map((log) => (
                      <TableRow key={log.id}>
                        <TableCell>
                          <Badge variant="outline" className="font-normal">
                            {log.page_name}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getDeviceIcon(log.device_name)}
                            <div className="text-xs">
                              {log.device_name?.replace(/\s*\([^)]+\)/, '')}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-xs">
                            <div className="flex items-center gap-1">
                              {log.browser}
                            </div>
                            <div className="text-muted-foreground flex items-center gap-1">
                              {getOSIcon(log.os)}
                              {log.os?.replace(/\s*\[[^\]]+\]/, '')}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-xs">
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {log.city}, {log.region}
                            </div>
                            <div className="text-muted-foreground">{log.country}</div>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {log.ip_address}
                        </TableCell>
                        <TableCell className="text-xs">
                          <div>{format(new Date(log.visited_at), 'MMM dd, yyyy')}</div>
                          <div className="text-muted-foreground">
                            {format(new Date(log.visited_at), 'hh:mm:ss a')}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </ScrollArea>
          </div>
        </TabsContent>

        <TabsContent value="geographic">
          <VisitorGeographicChart logs={filteredLogs} />
        </TabsContent>

        <TabsContent value="devices">
          <VisitorDeviceChart logs={filteredLogs} />
        </TabsContent>

        <TabsContent value="timing">
          <VisitorPeakHoursChart logs={filteredLogs} />
        </TabsContent>

        <TabsContent value="heatmap">
          <HeatmapOverlay
            clicks={clickData.filter((c: any) => c.page_name === heatmapPage)}
            selectedPage={heatmapPage}
            onPageChange={setHeatmapPage}
            availablePages={['Main Dashboard', 'Vendor Responses', 'Vendor Calls', 'Analytics Dashboard']}
          />
        </TabsContent>

        <TabsContent value="scroll">
          <ScrollDepthChart scrollData={scrollData} />
        </TabsContent>

        <TabsContent value="recordings">
          <SessionReplayViewer dateFrom={dateRange.from} dateTo={dateRange.to} />
        </TabsContent>

        {['main', 'vendor', 'calls'].map(tab => (
          <TabsContent key={tab} value={tab}>
            <ScrollArea className="h-[400px] rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Page</TableHead>
                    <TableHead>Device</TableHead>
                    <TableHead>Browser / OS</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>Date & Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tabFilteredLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell>
                        <Badge variant="outline" className="font-normal">
                          {log.page_name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getDeviceIcon(log.device_name)}
                          <div className="text-xs">
                            {log.device_name?.replace(/\s*\([^)]+\)/, '')}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-xs">
                          <div>{log.browser}</div>
                          <div className="text-muted-foreground flex items-center gap-1">
                            {getOSIcon(log.os)}
                            {log.os?.replace(/\s*\[[^\]]+\]/, '')}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-xs">
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {log.city}, {log.region}
                          </div>
                          <div className="text-muted-foreground">{log.country}</div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {log.ip_address}
                      </TableCell>
                      <TableCell className="text-xs">
                        <div>{format(new Date(log.visited_at), 'MMM dd, yyyy')}</div>
                        <div className="text-muted-foreground">
                          {format(new Date(log.visited_at), 'hh:mm:ss a')}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          </TabsContent>
        ))}
      </Tabs>
    </>
  );

  if (fullPage) {
    return <div className="glass-card p-6 rounded-xl">{content}</div>;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card border-border/50 max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LayoutDashboard className="h-5 w-5 text-primary" />
            Admin Analytics
          </DialogTitle>
          <DialogDescription>
            Visitor tracking and analytics dashboard
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="max-h-[80vh]">
          {content}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
