import { useState, useEffect, useRef, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { Play, Clock, Monitor, Smartphone, Eye, ChevronDown, ChevronUp } from 'lucide-react';
import { toast } from 'sonner';

interface SessionSummary {
  id: string;
  session_id: string;
  started_at: string;
  ended_at: string | null;
  duration_seconds: number;
  screen_width: number | null;
  screen_height: number | null;
  viewport_width: number | null;
  viewport_height: number | null;
  referrer: string | null;
  language: string | null;
  timezone: string | null;
  connection_type: string | null;
  pages_visited: string[];
  total_clicks: number;
  total_scroll_events: number;
  max_scroll_depth_percent: number;
  is_bounce: boolean;
}

interface SessionReplayViewerProps {
  dateFrom?: Date;
  dateTo?: Date;
}

export const SessionReplayViewer = ({ dateFrom, dateTo }: SessionReplayViewerProps) => {
  const [sessions, setSessions] = useState<SessionSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const [replayEvents, setReplayEvents] = useState<any[]>([]);
  const [replayLoading, setReplayLoading] = useState(false);
  const [expandedSession, setExpandedSession] = useState<string | null>(null);
  const replayContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchSessions();
  }, [dateFrom, dateTo]);

  const fetchSessions = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('visitor_sessions')
        .select('*')
        .order('started_at', { ascending: false })
        .limit(50);

      if (dateFrom) {
        query = query.gte('started_at', dateFrom.toISOString());
      }
      if (dateTo) {
        query = query.lte('started_at', dateTo.toISOString());
      }

      const { data, error } = await query;
      if (error) throw error;
      setSessions((data as any[]) || []);
    } catch (error) {
      console.error('Error fetching sessions:', error);
      toast.error('Failed to fetch sessions');
    } finally {
      setLoading(false);
    }
  };

  const loadReplay = async (sessionId: string) => {
    setReplayLoading(true);
    setSelectedSession(sessionId);
    try {
      const { data, error } = await supabase
        .from('visitor_session_recordings')
        .select('events, chunk_index')
        .eq('session_id', sessionId)
        .order('chunk_index', { ascending: true });

      if (error) throw error;

      if (!data || data.length === 0) {
        toast.error('No recording data found for this session');
        setReplayEvents([]);
        return;
      }

      // Combine all chunks
      const allEvents = (data as any[]).flatMap((chunk: any) => chunk.events || []);
      setReplayEvents(allEvents);
      
      toast.success(`Loaded ${allEvents.length} events for replay`);
    } catch (error) {
      console.error('Error loading replay:', error);
      toast.error('Failed to load replay');
    } finally {
      setReplayLoading(false);
    }
  };

  const startReplay = async () => {
    if (replayEvents.length === 0 || !replayContainerRef.current) return;

    try {
      // Dynamic import for rrweb-player
      const { default: rrwebPlayer } = await import('rrweb-player');
      
      // Clear previous player
      replayContainerRef.current.innerHTML = '';

      new rrwebPlayer({
        target: replayContainerRef.current,
        props: {
          events: replayEvents,
          width: 800,
          height: 450,
          autoPlay: true,
          showController: true,
          speedOption: [1, 2, 4, 8],
        },
      });
    } catch (error) {
      console.error('Error starting replay:', error);
      toast.error('Failed to start replay. Try refreshing the page.');
    }
  };

  useEffect(() => {
    if (replayEvents.length > 0) {
      startReplay();
    }
  }, [replayEvents]);

  const formatDuration = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="space-y-4">
      {/* Replay player */}
      {selectedSession && (
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Play className="h-4 w-4 text-primary" />
              Session Replay
            </CardTitle>
            <CardDescription className="text-xs">
              Session: {selectedSession.substring(0, 20)}... | {replayEvents.length} events
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div 
              ref={replayContainerRef} 
              className="rounded-lg overflow-hidden border border-border/50 bg-muted/30"
              style={{ minHeight: '300px' }}
            >
              {replayLoading && (
                <div className="flex items-center justify-center h-[300px]">
                  <div className="text-muted-foreground animate-pulse">Loading replay...</div>
                </div>
              )}
              {!replayLoading && replayEvents.length === 0 && (
                <div className="flex items-center justify-center h-[300px] text-muted-foreground text-sm">
                  No recording available for this session
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Sessions list */}
      <Card className="glass-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Eye className="h-4 w-4 text-primary" />
            Recorded Sessions ({sessions.length})
          </CardTitle>
          <CardDescription className="text-xs">Click a session to view its replay</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            {loading ? (
              <div className="text-center py-8 text-muted-foreground animate-pulse">Loading sessions...</div>
            ) : sessions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No sessions recorded yet</div>
            ) : (
              <div className="space-y-2">
                {sessions.map(session => (
                  <div
                    key={session.id}
                    className={`p-3 rounded-lg border transition-all cursor-pointer ${
                      selectedSession === session.session_id
                        ? 'border-primary bg-primary/5'
                        : 'border-border/50 hover:border-primary/30'
                    }`}
                  >
                    <div
                      className="flex items-center justify-between"
                      onClick={() => setExpandedSession(
                        expandedSession === session.session_id ? null : session.session_id
                      )}
                    >
                      <div className="flex items-center gap-3">
                        {(session.viewport_width || 0) < 768 ? (
                          <Smartphone className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Monitor className="h-4 w-4 text-muted-foreground" />
                        )}
                        <div>
                          <div className="text-sm font-medium">
                            {format(new Date(session.started_at), 'MMM dd, hh:mm a')}
                          </div>
                          <div className="text-xs text-muted-foreground flex gap-2 flex-wrap">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {formatDuration(session.duration_seconds)}
                            </span>
                            <span>{session.total_clicks} clicks</span>
                            <span>{session.max_scroll_depth_percent}% scroll</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {session.is_bounce && (
                          <Badge variant="outline" className="text-[10px]">Bounce</Badge>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            loadReplay(session.session_id);
                          }}
                          disabled={replayLoading}
                        >
                          <Play className="h-3 w-3 mr-1" />
                          Replay
                        </Button>
                        {expandedSession === session.session_id ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </div>
                    </div>

                    {expandedSession === session.session_id && (
                      <div className="mt-3 pt-3 border-t border-border/30 grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-muted-foreground">Screen:</span>{' '}
                          {session.screen_width}×{session.screen_height}
                        </div>
                        <div>
                          <span className="text-muted-foreground">Viewport:</span>{' '}
                          {session.viewport_width}×{session.viewport_height}
                        </div>
                        <div>
                          <span className="text-muted-foreground">Language:</span>{' '}
                          {session.language || 'Unknown'}
                        </div>
                        <div>
                          <span className="text-muted-foreground">Timezone:</span>{' '}
                          {session.timezone || 'Unknown'}
                        </div>
                        <div>
                          <span className="text-muted-foreground">Connection:</span>{' '}
                          {session.connection_type || 'Unknown'}
                        </div>
                        <div>
                          <span className="text-muted-foreground">Referrer:</span>{' '}
                          {session.referrer || 'Direct'}
                        </div>
                        <div className="col-span-2">
                          <span className="text-muted-foreground">Pages:</span>{' '}
                          {session.pages_visited?.join(' → ') || 'N/A'}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};
