import { useState } from "react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { GripVertical } from "lucide-react";

interface SortableItemProps {
  id: string;
  isAdmin?: boolean;
  children: React.ReactNode;
}

const SortableItem = ({ id, isAdmin, children }: SortableItemProps) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id, disabled: !isAdmin });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 50 : "auto" as any,
  };

  return (
    <div ref={setNodeRef} style={style} className="relative group/sortable">
      {isAdmin && (
        <button
          {...attributes}
          {...listeners}
          className="absolute top-2 right-2 z-20 p-1 rounded-md bg-muted/80 opacity-0 group-hover/sortable:opacity-100 transition-opacity cursor-grab active:cursor-grabbing hover:bg-primary/10"
          title="Drag to reorder"
        >
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </button>
      )}
      {children}
    </div>
  );
};

interface SortableKPIGridProps {
  kpis: any[];
  isAdmin?: boolean;
  onReorder: (reorderedKpis: any[]) => void;
  columns?: string;
  children: (kpi: any) => React.ReactNode;
}

export const SortableKPIGrid = ({
  kpis,
  isAdmin,
  onReorder,
  columns = "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4",
  children,
}: SortableKPIGridProps) => {
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = kpis.findIndex((k) => k.id === active.id);
    const newIndex = kpis.findIndex((k) => k.id === over.id);
    const reordered = arrayMove(kpis, oldIndex, newIndex);

    // Optimistic update
    onReorder(reordered);

    // Persist sort_order to DB
    try {
      for (let i = 0; i < reordered.length; i++) {
        await supabase
          .from("custom_kpis")
          .update({ sort_order: i })
          .eq("id", reordered[i].id);
      }
    } catch {
      toast.error("Failed to save order");
    }
  };

  if (!isAdmin) {
    return (
      <div className={`grid ${columns} gap-4 sm:gap-6`}>
        {kpis.map((kpi) => children(kpi))}
      </div>
    );
  }

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={kpis.map((k) => k.id)} strategy={rectSortingStrategy}>
        <div className={`grid ${columns} gap-4 sm:gap-6`}>
          {kpis.map((kpi) => (
            <SortableItem key={kpi.id} id={kpi.id} isAdmin={isAdmin}>
              {children(kpi)}
            </SortableItem>
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
};
