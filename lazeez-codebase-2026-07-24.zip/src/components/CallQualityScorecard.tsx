import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, PhoneCall, PhoneOff, Clock, TrendingUp, TrendingDown, Minus, Target } from "lucide-react";
import { useMemo } from "react";

interface CallLog {
  id: string;
  date: string;
  calls_made: number;
  calls_answered: number;
  total_duration_minutes: number;
  is_weekend: boolean;
}

interface CallQualityScorecardProps {
  callLogs: CallLog[];
}

export const CallQualityScorecard = ({ callLogs }: CallQualityScorecardProps) => {
  const metrics = useMemo(() => {
    if (callLogs.length === 0) {
      return {
        totalCalls: 0, totalAnswered: 0, totalMissed: 0, answerRate: 0,
        avgCallsPerDay: 0, avgDurationPerCall: 0, totalDuration: 0,
        weekdayCalls: 0, weekendCalls: 0, bestDay: "N/A", worstDay: "N/A",
        trend: "neutral" as const, trendValue: 0, overallScore: 0,
      };
    }

    const totalCalls = callLogs.reduce((s, c) => s + c.calls_made, 0);
    const totalAnswered = callLogs.reduce((s, c) => s + c.calls_answered, 0);
    const totalMissed = totalCalls - totalAnswered;
    const totalDuration = callLogs.reduce((s, c) => s + c.total_duration_minutes, 0);
    const answerRate = totalCalls > 0 ? Math.round((totalAnswered / totalCalls) * 100) : 0;
    const activeDays = callLogs.filter(c => c.calls_made > 0).length;
    const avgCallsPerDay = activeDays > 0 ? Math.round(totalCalls / activeDays) : 0;
    const avgDurationPerCall = totalAnswered > 0 ? Math.round(totalDuration / totalAnswered) : 0;
    const weekdayCalls = callLogs.filter(c => !c.is_weekend).reduce((s, c) => s + c.calls_made, 0);
    const weekendCalls = callLogs.filter(c => c.is_weekend).reduce((s, c) => s + c.calls_made, 0);

    // Best/worst day
    const sorted = [...callLogs].filter(c => c.calls_made > 0).sort((a, b) => {
      const rateA = a.calls_made > 0 ? a.calls_answered / a.calls_made : 0;
      const rateB = b.calls_made > 0 ? b.calls_answered / b.calls_made : 0;
      return rateB - rateA;
    });
    const bestDay = sorted.length > 0 ? new Date(sorted[0].date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "N/A";
    const worstDay = sorted.length > 1 ? new Date(sorted[sorted.length - 1].date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "N/A";

    // Trend: compare last 7 entries vs prior 7
    const recent = callLogs.slice(-7);
    const prior = callLogs.slice(-14, -7);
    const recentRate = recent.reduce((s, c) => s + c.calls_answered, 0) / Math.max(1, recent.reduce((s, c) => s + c.calls_made, 0)) * 100;
    const priorRate = prior.length > 0 ? prior.reduce((s, c) => s + c.calls_answered, 0) / Math.max(1, prior.reduce((s, c) => s + c.calls_made, 0)) * 100 : recentRate;
    const trendValue = Math.round(recentRate - priorRate);
    const trend = trendValue > 2 ? "up" as const : trendValue < -2 ? "down" as const : "neutral" as const;

    // Overall score (0-100): weighted combo of answer rate, consistency, volume
    const volumeScore = Math.min(100, (avgCallsPerDay / 20) * 100);
    const durationScore = Math.min(100, (avgDurationPerCall / 5) * 100);
    const overallScore = Math.round(answerRate * 0.5 + volumeScore * 0.25 + durationScore * 0.25);

    return {
      totalCalls, totalAnswered, totalMissed, answerRate,
      avgCallsPerDay, avgDurationPerCall, totalDuration,
      weekdayCalls, weekendCalls, bestDay, worstDay,
      trend, trendValue, overallScore,
    };
  }, [callLogs]);

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-emerald-600 dark:text-emerald-400";
    if (score >= 60) return "text-amber-600 dark:text-amber-400";
    return "text-red-600 dark:text-red-400";
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return "Excellent";
    if (score >= 60) return "Good";
    if (score >= 40) return "Fair";
    return "Needs Improvement";
  };

  const matrixItems = [
    { label: "Total Calls", value: metrics.totalCalls.toLocaleString(), icon: Phone, color: "text-primary" },
    { label: "Answered", value: metrics.totalAnswered.toLocaleString(), icon: PhoneCall, color: "text-emerald-600 dark:text-emerald-400" },
    { label: "Missed", value: metrics.totalMissed.toLocaleString(), icon: PhoneOff, color: "text-red-600 dark:text-red-400" },
    { label: "Answer Rate", value: `${metrics.answerRate}%`, icon: Target, color: "text-primary" },
    { label: "Avg/Day", value: `${metrics.avgCallsPerDay}`, icon: TrendingUp, color: "text-primary" },
    { label: "Avg Duration", value: `${metrics.avgDurationPerCall}m`, icon: Clock, color: "text-amber-600 dark:text-amber-400" },
    { label: "Total Duration", value: `${Math.floor(metrics.totalDuration / 60)}h ${metrics.totalDuration % 60}m`, icon: Clock, color: "text-primary" },
    { label: "Weekday Calls", value: metrics.weekdayCalls.toLocaleString(), icon: Phone, color: "text-primary" },
    { label: "Weekend Calls", value: metrics.weekendCalls.toLocaleString(), icon: Phone, color: "text-muted-foreground" },
  ];

  return (
    <Card className="glass-card glass-hover border-border/50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5 text-primary" />
            Call Quality Scorecard
          </CardTitle>
          <div className="flex items-center gap-2">
            <div className={`text-2xl font-bold ${getScoreColor(metrics.overallScore)}`}>
              {metrics.overallScore}
            </div>
            <div className="text-right">
              <Badge variant="secondary" className={`text-xs ${getScoreColor(metrics.overallScore)}`}>
                {getScoreLabel(metrics.overallScore)}
              </Badge>
              {metrics.trend !== "neutral" && (
                <div className={`flex items-center gap-0.5 text-xs mt-0.5 ${
                  metrics.trend === "up" ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"
                }`}>
                  {metrics.trend === "up" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {metrics.trendValue > 0 ? "+" : ""}{metrics.trendValue}% vs prior
                </div>
              )}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Score bar */}
        <div className="mb-4">
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${
                metrics.overallScore >= 80 ? "bg-emerald-500" :
                metrics.overallScore >= 60 ? "bg-amber-500" : "bg-red-500"
              }`}
              style={{ width: `${metrics.overallScore}%` }}
            />
          </div>
        </div>

        {/* Metrics matrix */}
        <div className="grid grid-cols-3 gap-3">
          {matrixItems.map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.label} className="text-center p-2 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                <Icon className={`h-4 w-4 mx-auto mb-1 ${item.color}`} />
                <div className={`text-sm font-bold ${item.color}`}>{item.value}</div>
                <div className="text-[10px] text-muted-foreground">{item.label}</div>
              </div>
            );
          })}
        </div>

        {/* Best/Worst day */}
        <div className="flex justify-between mt-3 pt-3 border-t border-border/50 text-xs text-muted-foreground">
          <span>Best day: <span className="font-semibold text-emerald-600 dark:text-emerald-400">{metrics.bestDay}</span></span>
          <span>Weakest day: <span className="font-semibold text-red-600 dark:text-red-400">{metrics.worstDay}</span></span>
        </div>
      </CardContent>
    </Card>
  );
};
