import { LineChart, Line, ResponsiveContainer, Tooltip } from "recharts";

interface KPISparklineProps {
  data: { value: number; label: string }[];
}

export const KPISparkline = ({ data }: KPISparklineProps) => {
  if (data.length < 2) return null;

  return (
    <div className="mt-3 h-10 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <Tooltip
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const item = payload[0].payload as { value: number; label: string };
              return (
                <div className="rounded-md border border-border/50 bg-background px-2 py-1 text-xs shadow-md">
                  <p className="font-medium text-foreground">{item.value}</p>
                  <p className="text-muted-foreground">{item.label}</p>
                </div>
              );
            }}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke="hsl(var(--primary))"
            strokeWidth={1.5}
            dot={false}
            activeDot={{ r: 3, fill: "hsl(var(--primary))" }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
