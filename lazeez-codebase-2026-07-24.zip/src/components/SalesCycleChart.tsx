import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AddSalesCycleDialog } from "./AddSalesCycleDialog";

interface SalesCycleData {
  id: string;
  quarter: string;
  weeks: number;
  sort_order: number;
}

export const SalesCycleChart = () => {
  const { isAdmin } = useAuth();
  const [data, setData] = useState<SalesCycleData[]>([]);
  const [addDialogOpen, setAddDialogOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const { data: cycleData } = await supabase
      .from('sales_cycle_data')
      .select('*')
      .order('sort_order', { ascending: true });
    
    if (cycleData) {
      setData(cycleData);
    }
  };

  const nextSortOrder = data.length > 0 ? Math.max(...data.map(d => d.sort_order)) + 1 : 1;

  return (
    <>
      <Card className="glass-card glass-hover border-border/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Sales Cycle Duration</CardTitle>
            <CardDescription>Average weeks to close deals per quarter</CardDescription>
          </div>
          {isAdmin && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full hover:bg-primary/10"
              onClick={() => setAddDialogOpen(true)}
            >
              <Plus className="h-4 w-4 text-primary" />
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="quarter" 
                stroke="hsl(var(--muted-foreground))"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                style={{ fontSize: '12px' }}
                domain={[0, 3]}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
                formatter={(value: number) => [`${value} weeks`, 'Duration']}
              />
              <Line 
                type="monotone" 
                dataKey="weeks" 
                stroke="hsl(var(--primary))" 
                strokeWidth={3}
                dot={{ fill: 'hsl(var(--primary))', r: 6 }}
                activeDot={{ r: 8 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <AddSalesCycleDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onSuccess={fetchData}
        nextSortOrder={nextSortOrder}
      />
    </>
  );
};