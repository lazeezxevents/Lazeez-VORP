import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface AddSalesCycleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  nextSortOrder: number;
}

export const AddSalesCycleDialog = ({ open, onOpenChange, onSuccess, nextSortOrder }: AddSalesCycleDialogProps) => {
  const [quarter, setQuarter] = useState("");
  const [weeks, setWeeks] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!quarter.trim() || !weeks) {
      toast.error("Please fill all fields");
      return;
    }

    setLoading(true);
    const { error } = await supabase
      .from('sales_cycle_data')
      .insert({
        quarter: quarter.trim(),
        weeks: parseFloat(weeks),
        sort_order: nextSortOrder
      });

    if (error) {
      toast.error("Failed to add quarter");
    } else {
      toast.success("Quarter added successfully");
      setQuarter("");
      setWeeks("");
      onSuccess();
      onOpenChange(false);
    }
    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card border-border/50">
        <DialogHeader>
          <DialogTitle>Add New Quarter</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Quarter Name</Label>
            <Input
              placeholder="e.g., Q4, Q1 2025"
              value={quarter}
              onChange={(e) => setQuarter(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label>Duration (weeks)</Label>
            <Input
              type="number"
              step="0.1"
              placeholder="e.g., 1.5"
              value={weeks}
              onChange={(e) => setWeeks(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? "Adding..." : "Add Quarter"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};