import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { z } from "zod";

const kpiSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name must be less than 100 characters"),
  type: z.enum(["number", "percentage", "formula"]),
  description: z.string().trim().max(500, "Description must be less than 500 characters").optional(),
  category: z.string().trim().max(50, "Category must be less than 50 characters").optional(),
  value: z.number().optional(),
});

interface CreateKPIDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  initialCategory?: string | null;
}

export const CreateKPIDialog = ({ open, onOpenChange, onSuccess, initialCategory }: CreateKPIDialogProps) => {
  const [name, setName] = useState("");
  const [type, setType] = useState<"number" | "percentage" | "formula">("number");
  const [value, setValue] = useState("");
  const [targetValue, setTargetValue] = useState("");
  const [warningThreshold, setWarningThreshold] = useState("");
  const [criticalThreshold, setCriticalThreshold] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [loading, setLoading] = useState(false);

  // Update category when initialCategory changes
  useEffect(() => {
    if (initialCategory) {
      setCategory(initialCategory);
    }
  }, [initialCategory]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validate input
      const validatedData = kpiSchema.parse({
        name,
        type,
        description: description || undefined,
        category: category || undefined,
        value: value ? parseFloat(value) : undefined,
      });

      const { error } = await supabase.from("custom_kpis").insert({
        name: validatedData.name,
        type: validatedData.type,
        value: validatedData.value ?? null,
        description: validatedData.description ?? null,
        category: validatedData.category ?? null,
        target_value: targetValue ? parseFloat(targetValue) : null,
        warning_threshold: warningThreshold ? parseFloat(warningThreshold) : null,
        critical_threshold: criticalThreshold ? parseFloat(criticalThreshold) : null,
      });

      if (error) throw error;

      toast.success("KPI created successfully!");
      onSuccess();
      onOpenChange(false);
      
      // Reset form
      setName("");
      setType("number");
      setValue("");
      setTargetValue("");
      setWarningThreshold("");
      setCriticalThreshold("");
      setDescription("");
      setCategory("");
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        toast.error((error.issues?.[0]?.message ?? error.message));
      } else {
        toast.error(error.message || "Failed to create KPI");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card border-border/50 max-w-md animate-scale-in">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold bg-gradient-to-r from-primary to-primary-accent bg-clip-text text-transparent">
            Create Custom KPI
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Add a new custom KPI to track your metrics
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">KPI Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="bg-background/50"
              placeholder="e.g., Monthly Revenue"
            />
          </div>
          <div>
            <Label htmlFor="type">Type *</Label>
            <Select value={type} onValueChange={(v) => setType(v as any)}>
              <SelectTrigger className="bg-background/50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="number">Number</SelectItem>
                <SelectItem value="percentage">Percentage</SelectItem>
                <SelectItem value="formula">Formula</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="value">Initial Value</Label>
            <Input
              id="value"
              type="number"
              step="0.01"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="bg-background/50"
              placeholder="0"
            />
          </div>
          <div>
            <Label htmlFor="target">Goal Target (optional)</Label>
            <Input
              id="target"
              type="number"
              step="0.01"
              value={targetValue}
              onChange={(e) => setTargetValue(e.target.value)}
              className="bg-background/50"
              placeholder="e.g., 100"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="warning">Warning Threshold</Label>
              <Input
                id="warning"
                type="number"
                step="0.01"
                value={warningThreshold}
                onChange={(e) => setWarningThreshold(e.target.value)}
                className="bg-background/50"
                placeholder="e.g., 80"
              />
            </div>
            <div>
              <Label htmlFor="critical">Critical Threshold</Label>
              <Input
                id="critical"
                type="number"
                step="0.01"
                value={criticalThreshold}
                onChange={(e) => setCriticalThreshold(e.target.value)}
                className="bg-background/50"
                placeholder="e.g., 95"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="bg-background/50"
              placeholder="e.g., Sales, Vendors"
            />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-background/50"
              placeholder="Optional description..."
            />
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="submit" disabled={loading} className="flex-1 bg-gradient-to-r from-primary to-primary-accent hover:opacity-90 transition-opacity">
              {loading ? "Creating..." : "Create KPI"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 hover:bg-muted"
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
