import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bookmark, Plus, X, Save } from "lucide-react";
import { toast } from "sonner";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface BookmarkData {
  id: string;
  name: string;
  filters: {
    category?: string;
    dateFrom?: string;
    dateTo?: string;
  };
  created_at: string;
}

interface DashboardBookmarksProps {
  currentFilters: {
    category?: string;
    dateFrom?: string;
    dateTo?: string;
  };
  onApplyBookmark: (filters: BookmarkData["filters"]) => void;
  userId?: string;
}

export const DashboardBookmarks = ({
  currentFilters,
  onApplyBookmark,
  userId,
}: DashboardBookmarksProps) => {
  const [bookmarks, setBookmarks] = useState<BookmarkData[]>([]);
  const [newName, setNewName] = useState("");
  const [saving, setSaving] = useState(false);

  const fetchBookmarks = async () => {
    if (!userId) return;
    const { data } = await supabase
      .from("dashboard_bookmarks")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (data) setBookmarks(data as unknown as BookmarkData[]);
  };

  useEffect(() => {
    fetchBookmarks();
  }, [userId]);

  const handleSave = async () => {
    if (!newName.trim() || !userId) return;
    setSaving(true);
    try {
      const { error } = await supabase.from("dashboard_bookmarks").insert({
        user_id: userId,
        name: newName.trim(),
        filters: currentFilters as any,
      });
      if (error) throw error;
      setNewName("");
      fetchBookmarks();
      toast.success("Bookmark saved");
    } catch (e: any) {
      toast.error(e.message || "Failed to save bookmark");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await supabase.from("dashboard_bookmarks").delete().eq("id", id);
      fetchBookmarks();
    } catch {
      toast.error("Failed to delete");
    }
  };

  if (!userId) return null;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Bookmark className="h-4 w-4" />
          <span className="hidden sm:inline">Bookmarks</span>
          {bookmarks.length > 0 && (
            <span className="ml-1 px-1.5 py-0.5 text-xs bg-primary/20 text-primary rounded-full">
              {bookmarks.length}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-3 space-y-3" align="end">
        <div className="flex items-center gap-2">
          <Bookmark className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold">Saved Views</span>
        </div>

        {bookmarks.length === 0 && (
          <p className="text-xs text-muted-foreground">No bookmarks yet.</p>
        )}

        <div className="space-y-1.5 max-h-40 overflow-y-auto">
          {bookmarks.map((b) => (
            <div
              key={b.id}
              className="flex items-center gap-2 text-xs bg-muted/50 rounded-md p-2 hover:bg-primary/10 cursor-pointer transition-colors"
              onClick={() => onApplyBookmark(b.filters)}
            >
              <span className="flex-1 font-medium truncate">{b.name}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete(b.id);
                }}
                className="text-muted-foreground hover:text-destructive"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>

        <div className="flex gap-1.5 pt-1 border-t border-border">
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Name this view..."
            className="h-8 text-xs"
            onKeyDown={(e) => e.key === "Enter" && handleSave()}
          />
          <Button
            size="icon"
            className="h-8 w-8 shrink-0"
            onClick={handleSave}
            disabled={saving}
          >
            <Save className="h-3 w-3" />
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
};
