import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ExternalLink, Phone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const VendorCallsCard = () => {
  const navigate = useNavigate();
  const [todayData, setTodayData] = useState({ 
    made: 0, 
    answered: 0,
    duration: 0
  });

  useEffect(() => {
    fetchTodayData();

    // Subscribe to realtime changes
    const channel = supabase
      .channel('call-logs-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'call_logs'
        },
        () => {
          fetchTodayData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchTodayData = async () => {
    const todayDate = new Date().toISOString().split('T')[0];
    const { data } = await supabase
      .from('call_logs')
      .select('*')
      .eq('date', todayDate)
      .maybeSingle();

    if (data) {
      setTodayData({
        made: data.calls_made,
        answered: data.calls_answered,
        duration: data.total_duration_minutes
      });
    }
  };

  const answerRate = todayData.made > 0 
    ? (todayData.answered / todayData.made) * 100 
    : 0;

  return (
    <Card 
      className="glass-card glass-hover border-border/50 cursor-pointer transition-all hover:scale-[1.02]"
      onClick={() => navigate('/vendor-calls')}
    >
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Phone className="h-5 w-5 text-primary" />
              Call Tracking
            </CardTitle>
            <CardDescription>
              Today's call response tracking
            </CardDescription>
          </div>
          <ExternalLink className="h-4 w-4 text-muted-foreground" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-center">
            <div className="text-5xl font-bold bg-gradient-to-r from-primary to-primary-accent bg-clip-text text-transparent mb-2">
              {answerRate.toFixed(0)}%
            </div>
            <Progress value={answerRate} className="h-3" />
          </div>
          
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{todayData.made}</div>
              <div className="text-xs text-muted-foreground mt-1">Calls Made</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{todayData.answered}</div>
              <div className="text-xs text-muted-foreground mt-1">Answered</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{todayData.duration}m</div>
              <div className="text-xs text-muted-foreground mt-1">Duration</div>
            </div>
          </div>

          <div className="bg-muted p-3 rounded-lg mt-4">
            <p className="text-xs text-muted-foreground text-center">
              Click to view analytics & update daily data
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
