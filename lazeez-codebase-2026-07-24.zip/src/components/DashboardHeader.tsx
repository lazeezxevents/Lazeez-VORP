import { useState, useEffect } from "react";
import logo from "@/assets/lazeez-logo.png";
import { Clock, LogIn, LogOut, Plus, Eye, BarChart3, Archive, GitCompare, Database, Loader2, FileCode2, Package } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { NavLink } from "@/components/NavLink";
import { ThemeToggle } from "@/components/ThemeToggle";
import { toast } from "sonner";
import { exportCodebaseZip, downloadBlob } from "@/lib/exportCodebase";

interface DashboardHeaderProps {
  lastUpdated?: Date;
  user?: any;
  isAdmin?: boolean;
  onSignOut?: () => void;
  onSignIn?: () => void;
  onCreateKPI?: () => void;
  onArchiveOpen?: () => void;
  onComparisonOpen?: () => void;
  archivedCount?: number;
}

export const DashboardHeader = ({
  lastUpdated,
  user,
  isAdmin,
  onSignOut,
  onSignIn,
  onCreateKPI,
  onArchiveOpen,
  onComparisonOpen,
  archivedCount = 0,
}: DashboardHeaderProps) => {
  const [latestUpdate, setLatestUpdate] = useState<Date | null>(lastUpdated || null);
  const [exporting, setExporting] = useState(false);
  const [exportingSchema, setExportingSchema] = useState(false);
  const [exportingCode, setExportingCode] = useState(false);

  const callExport = async (path: string, fallbackName: string) => {
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    if (!token) throw new Error("Not authenticated");
    const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${path}`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) {
      const msg = await res.text().catch(() => res.statusText);
      throw new Error(msg || `HTTP ${res.status}`);
    }
    const blob = await res.blob();
    const dispo = res.headers.get("Content-Disposition") || "";
    const match = dispo.match(/filename="([^"]+)"/);
    downloadBlob(blob, match?.[1] || fallbackName);
  };

  const handleExportDatabase = async () => {
    setExporting(true);
    try {
      await callExport("export-database", `lazeez-db-export-${new Date().toISOString().slice(0, 10)}.json`);
      toast.success("Database exported");
    } catch (e: any) {
      toast.error(e?.message || "Export failed");
    } finally {
      setExporting(false);
    }
  };

  const handleExportSchema = async () => {
    setExportingSchema(true);
    try {
      await callExport("export-schema", `lazeez-db-schema-${new Date().toISOString().slice(0, 10)}.sql`);
      toast.success("Schema + data SQL exported");
    } catch (e: any) {
      toast.error(e?.message || "Schema export failed");
    } finally {
      setExportingSchema(false);
    }
  };

  const handleExportCode = async () => {
    setExportingCode(true);
    try {
      const blob = await exportCodebaseZip();
      downloadBlob(blob, `lazeez-codebase-${new Date().toISOString().slice(0, 10)}.zip`);
      toast.success("Codebase zip exported");
    } catch (e: any) {
      toast.error(e?.message || "Codebase export failed");
    } finally {
      setExportingCode(false);
    }
  };

  useEffect(() => {
    if (lastUpdated) {
      setLatestUpdate(lastUpdated);
    }
  }, [lastUpdated]);

  useEffect(() => {
    const fetchLatestUpdate = async () => {
      const { data } = await supabase
        .from('custom_kpis')
        .select('updated_at')
        .order('updated_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (data?.updated_at) {
        setLatestUpdate(new Date(data.updated_at));
      }
    };

    fetchLatestUpdate();
  }, []);

  const formattedDateTime = latestUpdate
    ? latestUpdate.toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      }) + " " + latestUpdate.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
    : "No updates yet";

  return (
    <header className="border-b border-border bg-card sticky top-0 z-40">
      <div className="container mx-auto px-4 sm:px-6 py-3">
        {/* Top row: Logo + Auth */}
        <div className="flex items-center justify-between gap-3">
          {/* Left: Logo */}
          <div className="flex items-center gap-3">
            <img src={logo} alt="Lazeez Events" className="h-10 w-10 sm:h-12 sm:w-12 object-contain" />
            <div>
              <h1 className="text-base sm:text-lg lg:text-xl font-bold text-foreground leading-tight">Lazeez Events Sales KPIs</h1>
              <div className="flex items-center gap-1.5 text-[10px] sm:text-xs text-muted-foreground">
                <Clock className="h-3 w-3 flex-shrink-0" />
                <span className="whitespace-nowrap">{formattedDateTime}</span>
              </div>
            </div>
          </div>

          {/* Right: Nav actions + Auth */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Navigation buttons */}
            <NavLink to="/analytics">
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-xs">
                <BarChart3 className="h-3.5 w-3.5" />
                <span className="hidden md:inline">Analytics</span>
              </Button>
            </NavLink>

            {onArchiveOpen && (
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-xs" onClick={onArchiveOpen}>
                <Archive className="h-3.5 w-3.5" />
                <span className="hidden md:inline">Archive</span>
                {archivedCount > 0 && (
                  <span className="px-1 py-0.5 text-[10px] bg-primary/20 text-primary rounded-full leading-none">
                    {archivedCount}
                  </span>
                )}
              </Button>
            )}

            {onComparisonOpen && (
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-xs" onClick={onComparisonOpen}>
                <GitCompare className="h-3.5 w-3.5" />
                <span className="hidden md:inline">Compare</span>
              </Button>
            )}

            {user && isAdmin && (
              <>
                <NavLink to="/admin-analytics">
                  <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-xs">
                    <Eye className="h-3.5 w-3.5" />
                    <span className="hidden lg:inline">Visitor Logs</span>
                  </Button>
                </NavLink>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1.5 text-xs"
                  onClick={handleExportDatabase}
                  disabled={exporting}
                  title="Export entire database as JSON"
                >
                  {exporting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Database className="h-3.5 w-3.5" />}
                  <span className="hidden lg:inline">Export DB</span>
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1.5 text-xs"
                  onClick={handleExportSchema}
                  disabled={exportingSchema}
                  title="Export schema + data as replicable SQL"
                >
                  {exportingSchema ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileCode2 className="h-3.5 w-3.5" />}
                  <span className="hidden lg:inline">Export SQL</span>
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1.5 text-xs"
                  onClick={handleExportCode}
                  disabled={exportingCode}
                  title="Download entire codebase as ZIP"
                >
                  {exportingCode ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Package className="h-3.5 w-3.5" />}
                  <span className="hidden lg:inline">Export Code</span>
                </Button>
                {onCreateKPI && (
                  <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={onCreateKPI}>
                    <Plus className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">Create KPI</span>
                  </Button>
                )}
              </>
            )}

            <div className="w-px h-6 bg-border mx-0.5 hidden sm:block" />

            <ThemeToggle />

            {/* Auth button */}
            {user ? (
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-xs" onClick={onSignOut}>
                <LogOut className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </Button>
            ) : (
              <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={onSignIn}>
                <LogIn className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Sign In</span>
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
