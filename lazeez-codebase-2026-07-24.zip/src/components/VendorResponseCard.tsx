import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const VendorResponseCard = () => {
  const navigate = useNavigate();
  const [todayData, setTodayData] = useState({ 
    received: 0, 
    responded: 0,
    weekendReceived: 0,
    weekendResponded: 0 
  });

  // Detect if today is a weekend
  const today = new Date();
  const dayOfWeek = today.getDay();
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

  useEffect(() => {
    fetchTodayData();

    // Subscribe to realtime changes
    const channel = supabase
      .channel('vendor-responses-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'vendor_responses'
        },
        () => {
          fetchTodayData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchTodayData = async () => {
    const todayDate = new Date().toISOString().split('T')[0];
    const { data } = await supabase
      .from('vendor_responses')
      .select('*')
      .eq('date', todayDate)
      .maybeSingle();

    if (data) {
      setTodayData({
        received: data.inquiries_received,
        responded: data.inquiries_responded,
        weekendReceived: data.inquiries_received_weekend,
        weekendResponded: data.inquiries_responded_weekend
      });
    }
  };

  // Use weekend or weekday data based on current day
  const displayReceived = isWeekend ? todayData.weekendReceived : todayData.received;
  const displayResponded = isWeekend ? todayData.weekendResponded : todayData.responded;
  
  const responseRate = displayReceived > 0 
    ? (displayResponded / displayReceived) * 100 
    : 0;

  return (
    <Card 
      className="glass-card glass-hover border-border/50 cursor-pointer transition-all hover:scale-[1.02]"
      onClick={() => navigate('/vendor-responses')}
    >
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Vendor Response Rate</CardTitle>
            <CardDescription className="flex items-center gap-2">
              Today's inquiries response tracking
              {isWeekend && (
                <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-primary/20 text-primary">
                  Weekend
                </span>
              )}
            </CardDescription>
          </div>
          <ExternalLink className="h-4 w-4 text-muted-foreground" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-center">
            <div className="text-5xl font-bold bg-gradient-to-r from-primary to-primary-accent bg-clip-text text-transparent mb-2">
              {responseRate.toFixed(0)}%
            </div>
            <Progress value={responseRate} className="h-3" />
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{displayReceived}</div>
              <div className="text-xs text-muted-foreground mt-1">Inquiries Received</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{displayResponded}</div>
              <div className="text-xs text-muted-foreground mt-1">Inquiries Responded</div>
            </div>
          </div>

          <div className="bg-muted p-3 rounded-lg mt-4">
            <p className="text-xs text-muted-foreground text-center">
              Click to view analytics & update daily data
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};