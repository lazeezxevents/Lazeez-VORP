import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Phone, PhoneCall, Clock, Percent, Save, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface CallLog {
  id: string;
  date: string;
  calls_made: number;
  calls_answered: number;
  total_duration_minutes: number;
  is_weekend: boolean;
}

interface EditCallLogDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entry: CallLog | null;
  onSave: () => void;
}

export function EditCallLogDialog({ open, onOpenChange, entry, onSave }: EditCallLogDialogProps) {
  const [callsMade, setCallsMade] = useState(0);
  const [callsAnswered, setCallsAnswered] = useState(0);
  const [durationMinutes, setDurationMinutes] = useState(0);
  const [saving, setSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (entry) {
      setCallsMade(entry.calls_made);
      setCallsAnswered(entry.calls_answered);
      setDurationMinutes(entry.total_duration_minutes);
    }
  }, [entry]);

  const answerRate = callsMade > 0 
    ? ((callsAnswered / callsMade) * 100).toFixed(1) 
    : '0';

  const handleSave = async () => {
    if (!entry) return;
    setSaving(true);

    const { error } = await supabase
      .from('call_logs')
      .update({
        calls_made: callsMade,
        calls_answered: callsAnswered,
        total_duration_minutes: durationMinutes
      })
      .eq('id', entry.id);

    setSaving(false);

    if (error) {
      toast.error("Failed to update call log");
    } else {
      toast.success("Call log updated successfully");
      onSave();
      onOpenChange(false);
    }
  };

  const handleDelete = async () => {
    if (!entry) return;
    setSaving(true);

    const { error } = await supabase
      .from('call_logs')
      .delete()
      .eq('id', entry.id);

    setSaving(false);
    setShowDeleteConfirm(false);

    if (error) {
      toast.error("Failed to delete call log");
    } else {
      toast.success("Call log deleted successfully");
      onSave();
      onOpenChange(false);
    }
  };

  if (!entry) return null;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Call Log</DialogTitle>
            <DialogDescription>
              {format(new Date(entry.date), 'EEEE, MMMM d, yyyy')}
              {entry.is_weekend && (
                <span className="ml-2 px-2 py-0.5 text-xs font-medium rounded-full bg-primary/20 text-primary">
                  Weekend
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                Calls Made
              </Label>
              <Input
                type="number"
                value={callsMade}
                onChange={(e) => setCallsMade(parseInt(e.target.value) || 0)}
                min="0"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <PhoneCall className="h-4 w-4" />
                Calls Answered
              </Label>
              <Input
                type="number"
                value={callsAnswered}
                onChange={(e) => setCallsAnswered(parseInt(e.target.value) || 0)}
                min="0"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Duration (minutes)
              </Label>
              <Input
                type="number"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(parseInt(e.target.value) || 0)}
                min="0"
              />
            </div>
            
            <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
              <Percent className="h-4 w-4 text-primary" />
              <span className="text-sm text-muted-foreground">Answer Rate:</span>
              <span className="font-bold text-primary">{answerRate}%</span>
            </div>
          </div>
          
          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="destructive"
              onClick={() => setShowDeleteConfirm(true)}
              disabled={saving}
              className="w-full sm:w-auto"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
            <Button onClick={handleSave} disabled={saving} className="w-full sm:w-auto">
              <Save className="h-4 w-4 mr-2" />
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Call Log</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the call log for {format(new Date(entry.date), 'MMMM d, yyyy')}? 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
