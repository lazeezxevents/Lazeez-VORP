import { Button } from "@/components/ui/button";
import { FileDown } from "lucide-react";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { format } from "date-fns";

interface PDFExportButtonProps {
  allKPIs: any[];
  archivedKPIs: any[];
  callKPIs: { totalMade: number; totalAnswered: number; totalDuration: number; answerRate: number };
  queryKPIs: { totalReceived: number; totalResponded: number; responseRate: number };
  getKpiDelta: (kpi: any) => { delta: number; deltaLabel: string } | undefined;
}

export const PDFExportButton = ({ allKPIs, archivedKPIs, callKPIs, queryKPIs, getKpiDelta }: PDFExportButtonProps) => {
  const generatePDF = () => {
    try {
      const doc = new jsPDF();
      const now = format(new Date(), "MMMM dd, yyyy HH:mm");

      // Header
      doc.setFontSize(20);
      doc.setTextColor(30, 30, 30);
      doc.text("Lazeez Events — KPI Report", 14, 22);
      doc.setFontSize(10);
      doc.setTextColor(120, 120, 120);
      doc.text(`Generated: ${now}`, 14, 30);

      let y = 40;

      // Today's snapshot
      doc.setFontSize(14);
      doc.setTextColor(30, 30, 30);
      doc.text("Today's Snapshot", 14, y);
      y += 4;

      autoTable(doc, {
        startY: y,
        head: [["Metric", "Value"]],
        body: [
          ["Queries Received", String(queryKPIs.totalReceived)],
          ["Queries Responded", String(queryKPIs.totalResponded)],
          ["Response Rate", `${queryKPIs.responseRate}%`],
          ["Calls Made", String(callKPIs.totalMade)],
          ["Calls Answered", String(callKPIs.totalAnswered)],
          ["Call Duration", `${Math.floor(callKPIs.totalDuration / 60)}h ${callKPIs.totalDuration % 60}m`],
          ["Answer Rate", `${callKPIs.answerRate}%`],
        ],
        theme: "grid",
        headStyles: { fillColor: [79, 70, 229] },
        margin: { left: 14 },
      });

      y = (doc as any).lastAutoTable.finalY + 12;

      // KPI table grouped by category
      const categories = ["Vendor Onboarding", "Vendor Status", "Performance Insights", "Custom"];
      for (const cat of categories) {
        const kpis = allKPIs.filter(k => (k.category || "Custom") === cat);
        if (kpis.length === 0) continue;

        if (y > 260) { doc.addPage(); y = 20; }
        doc.setFontSize(14);
        doc.setTextColor(30, 30, 30);
        doc.text(cat, 14, y);
        y += 4;

        const rows = kpis.map(kpi => {
          const d = getKpiDelta(kpi);
          return [
            kpi.name,
            String(kpi.value ?? 0),
            kpi.period_label || "—",
            d ? `${d.delta > 0 ? "+" : ""}${d.delta}` : "—",
          ];
        });

        autoTable(doc, {
          startY: y,
          head: [["KPI", "Value", "Period", "Delta"]],
          body: rows,
          theme: "grid",
          headStyles: { fillColor: [79, 70, 229] },
          margin: { left: 14 },
        });

        y = (doc as any).lastAutoTable.finalY + 12;
      }

      doc.save(`Lazeez_KPI_Report_${format(new Date(), "yyyy-MM-dd")}.pdf`);
      toast.success("PDF report downloaded");
    } catch (err) {
      console.error(err);
      toast.error("Failed to generate PDF");
    }
  };

  return (
    <Button variant="outline" size="sm" className="gap-2" onClick={generatePDF}>
      <FileDown className="h-4 w-4" />
      <span className="hidden sm:inline">Export PDF</span>
    </Button>
  );
};
