import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MousePointerClick, Layers } from 'lucide-react';

interface ClickData {
  x_percent: number;
  y_percent: number;
  element_tag: string | null;
  element_text: string | null;
  clicked_at: string;
}

interface HeatmapOverlayProps {
  clicks: ClickData[];
  selectedPage: string;
  onPageChange: (page: string) => void;
  availablePages: string[];
}

export const HeatmapOverlay = ({ clicks, selectedPage, onPageChange, availablePages }: HeatmapOverlayProps) => {
  // Generate heatmap grid data
  const heatmapGrid = useMemo(() => {
    const gridSize = 20; // 20x20 grid
    const grid: number[][] = Array.from({ length: gridSize }, () => Array(gridSize).fill(0));
    
    clicks.forEach(click => {
      const col = Math.min(Math.floor((click.x_percent / 100) * gridSize), gridSize - 1);
      const row = Math.min(Math.floor((click.y_percent / 100) * gridSize), gridSize - 1);
      if (row >= 0 && col >= 0) {
        grid[row][col]++;
      }
    });

    return grid;
  }, [clicks]);

  const maxValue = useMemo(() => {
    return Math.max(1, ...heatmapGrid.flat());
  }, [heatmapGrid]);

  // Top clicked elements
  const topElements = useMemo(() => {
    const elements: Record<string, { count: number; tag: string; text: string }> = {};
    clicks.forEach(click => {
      const key = `${click.element_tag}:${click.element_text?.substring(0, 30)}`;
      if (!elements[key]) {
        elements[key] = { count: 0, tag: click.element_tag || 'unknown', text: click.element_text || '' };
      }
      elements[key].count++;
    });
    return Object.values(elements)
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [clicks]);

  const getHeatColor = (value: number) => {
    if (value === 0) return 'transparent';
    const intensity = value / maxValue;
    if (intensity < 0.2) return 'hsla(200, 80%, 60%, 0.2)';
    if (intensity < 0.4) return 'hsla(120, 70%, 50%, 0.35)';
    if (intensity < 0.6) return 'hsla(60, 80%, 50%, 0.5)';
    if (intensity < 0.8) return 'hsla(30, 90%, 50%, 0.65)';
    return 'hsla(0, 90%, 50%, 0.8)';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4 flex-wrap">
        <Select value={selectedPage} onValueChange={onPageChange}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Select page" />
          </SelectTrigger>
          <SelectContent>
            {availablePages.map(page => (
              <SelectItem key={page} value={page}>{page}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span className="text-sm text-muted-foreground">{clicks.length} clicks recorded</span>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {/* Heatmap visualization */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Layers className="h-4 w-4 text-primary" />
              Click Heatmap
            </CardTitle>
            <CardDescription className="text-xs">Click density across the page</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative border border-border/50 rounded-lg overflow-hidden" style={{ aspectRatio: '16/9' }}>
              <div className="absolute inset-0 bg-muted/20 grid" 
                style={{ 
                  gridTemplateColumns: `repeat(20, 1fr)`,
                  gridTemplateRows: `repeat(20, 1fr)`,
                }}>
                {heatmapGrid.flat().map((value, i) => (
                  <div
                    key={i}
                    style={{ backgroundColor: getHeatColor(value) }}
                    className="transition-colors duration-200"
                    title={`${value} clicks`}
                  />
                ))}
              </div>
              {/* Legend */}
              <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-background/80 backdrop-blur-sm px-2 py-1 rounded text-[10px]">
                <span>Low</span>
                <div className="flex gap-0.5">
                  {['hsla(200,80%,60%,0.3)', 'hsla(120,70%,50%,0.4)', 'hsla(60,80%,50%,0.5)', 'hsla(30,90%,50%,0.6)', 'hsla(0,90%,50%,0.8)'].map((c, i) => (
                    <div key={i} className="w-3 h-3 rounded-sm" style={{ backgroundColor: c }} />
                  ))}
                </div>
                <span>High</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Top clicked elements */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <MousePointerClick className="h-4 w-4 text-primary" />
              Most Clicked Elements
            </CardTitle>
            <CardDescription className="text-xs">Top interactive elements</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-[250px] overflow-y-auto">
              {topElements.length === 0 ? (
                <p className="text-sm text-muted-foreground">No click data yet</p>
              ) : (
                topElements.map((el, i) => (
                  <div key={i} className="flex items-center justify-between text-sm gap-2">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <span className="text-xs font-mono text-primary bg-primary/10 px-1.5 py-0.5 rounded">
                        {el.tag}
                      </span>
                      <span className="truncate text-muted-foreground text-xs">
                        {el.text || '(no text)'}
                      </span>
                    </div>
                    <span className="font-bold text-xs whitespace-nowrap">{el.count}×</span>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
