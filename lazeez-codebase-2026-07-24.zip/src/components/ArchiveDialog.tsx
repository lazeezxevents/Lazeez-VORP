import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Archive, RotateCcw, CalendarRange, TrendingUp, Trash2, Clock } from "lucide-react";
import { format } from "date-fns";
import { ArchiveTimeline } from "./ArchiveTimeline";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ArchivedKPIRecord {
  id: string;
  kpi_id: string;
  kpi_name: string;
  category: string | null;
  description: string | null;
  value_at_archive: number;
  archived_at: string;
  archived_by: string | null;
  period_label?: string | null;
  period_start_date?: string | null;
  period_end_date?: string | null;
}

interface ArchiveDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  archivedKPIs: ArchivedKPIRecord[];
  onRestore: (record: ArchivedKPIRecord) => void;
  onDelete?: (id: string) => void;
  isAdmin: boolean;
}

export const ArchiveDialog = ({ 
  open, 
  onOpenChange, 
  archivedKPIs, 
  onRestore,
  onDelete,
  isAdmin 
}: ArchiveDialogProps) => {
  const formatDate = (dateString?: string | null) => {
    if (!dateString) return "N/A";
    try {
      return format(new Date(dateString), "MMM dd, yyyy hh:mm a");
    } catch {
      return "N/A";
    }
  };

  // Group by KPI name to show stacked archives
  const groupedByKPI = archivedKPIs.reduce((acc, record) => {
    const key = record.kpi_name;
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(record);
    return acc;
  }, {} as Record<string, ArchivedKPIRecord[]>);

  // Group by category for display
  const groupedByCategory = archivedKPIs.reduce((acc, record) => {
    const category = record.category || "Uncategorized";
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(record);
    return acc;
  }, {} as Record<string, ArchivedKPIRecord[]>);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card border-border max-w-4xl max-h-[80vh] overflow-y-auto animate-scale-in">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Archive className="h-5 w-5 text-primary" />
            KPI Archive History
          </DialogTitle>
          <p className="text-sm text-muted-foreground">
            Historical records of archived KPIs - all previous archives are preserved
          </p>
        </DialogHeader>

        {archivedKPIs.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Archive className="h-16 w-16 text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground">No archived KPIs yet</p>
            <p className="text-sm text-muted-foreground/70">
              Archive KPIs to keep track of historical benchmarks
            </p>
          </div>
        ) : (
          <Tabs defaultValue="cards" className="mt-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="cards" className="gap-2">
                <Archive className="h-4 w-4" />
                Cards View
              </TabsTrigger>
              <TabsTrigger value="timeline" className="gap-2">
                <Clock className="h-4 w-4" />
                Timeline View
              </TabsTrigger>
            </TabsList>

            {/* Cards View */}
            <TabsContent value="cards" className="space-y-6 mt-4">
              {Object.entries(groupedByCategory).map(([category, records]) => (
                <div key={category} className="space-y-3">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    {category}
                  </h3>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {records.map((record) => {
                      const totalArchives = groupedByKPI[record.kpi_name]?.length || 0;
                      const archiveIndex = groupedByKPI[record.kpi_name]?.findIndex(r => r.id === record.id) || 0;
                      
                      return (
                        <Card 
                          key={record.id} 
                          className="glass-card border-border/50 overflow-hidden group animate-fade-in hover:border-primary/30 transition-colors"
                        >
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-foreground">{record.kpi_name}</span>
                                {totalArchives > 1 && (
                                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/20 text-primary">
                                    #{archiveIndex + 1} of {totalArchives}
                                  </span>
                                )}
                              </div>
                              {isAdmin && (
                                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => onRestore(record)}
                                    className="h-8 hover:bg-primary/10"
                                    title="Restore this value to the KPI"
                                  >
                                    <RotateCcw className="h-4 w-4 mr-1" />
                                    Restore
                                  </Button>
                                  {onDelete && (
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => onDelete(record.id)}
                                      className="h-8 hover:bg-destructive/10 text-destructive"
                                      title="Delete this archive record"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              )}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div className="flex items-baseline gap-2">
                              <span className="text-2xl font-bold bg-gradient-to-r from-primary via-primary-accent to-primary bg-clip-text text-transparent">
                                {record.value_at_archive}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                (archived value)
                              </span>
                            </div>
                            {record.period_label && (
                              <div className="inline-flex items-center gap-1.5 text-xs px-2 py-1 rounded-full bg-primary/10 text-primary font-medium">
                                <CalendarRange className="h-3 w-3" />
                                {record.period_label}
                              </div>
                            )}
                            {record.description && (
                              <p className="text-xs text-muted-foreground line-clamp-2">
                                {record.description}
                              </p>
                            )}
                            <div className="flex items-center gap-1.5 text-xs text-muted-foreground/70 pt-2 border-t border-border/50">
                              <CalendarRange className="h-3 w-3" />
                              <span>Archived: {formatDate(record.archived_at)}</span>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              ))}
            </TabsContent>

            {/* Timeline View */}
            <TabsContent value="timeline" className="mt-4">
              <div className="space-y-6">
                {Object.entries(groupedByKPI).map(([kpiName, records]) => (
                  <ArchiveTimeline key={kpiName} records={records} kpiName={kpiName} />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
};