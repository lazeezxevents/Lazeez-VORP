import { TrendingUp, Target } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface TrendForecastProps {
  currentValue: number;
  targetValue: number;
  sparklineData: { value: number; label: string }[];
}

/**
 * Uses linear regression on archive history to project when a KPI will hit its target.
 */
export const TrendForecast = ({ currentValue, targetValue, sparklineData }: TrendForecastProps) => {
  if (!targetValue || targetValue <= 0 || sparklineData.length < 2) return null;
  if (currentValue >= targetValue) {
    return (
      <div className="inline-flex items-center gap-1 text-xs mt-2 px-2 py-1 rounded-full bg-green-500/10 text-green-600 dark:text-green-400">
        <Target className="h-3 w-3" />
        <span className="font-semibold">Goal reached! 🎉</span>
      </div>
    );
  }

  // Simple linear regression: y = mx + b
  const n = sparklineData.length;
  const xs = sparklineData.map((_, i) => i);
  const ys = sparklineData.map((d) => d.value);
  const sumX = xs.reduce((a, b) => a + b, 0);
  const sumY = ys.reduce((a, b) => a + b, 0);
  const sumXY = xs.reduce((a, x, i) => a + x * ys[i], 0);
  const sumX2 = xs.reduce((a, x) => a + x * x, 0);

  const denom = n * sumX2 - sumX * sumX;
  if (denom === 0) return null;

  const m = (n * sumXY - sumX * sumY) / denom;

  if (m <= 0) {
    return (
      <TooltipProvider delayDuration={200}>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="inline-flex items-center gap-1 text-xs mt-2 px-2 py-1 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400 cursor-default">
              <TrendingUp className="h-3 w-3" />
              <span className="font-semibold">Trend: not on track</span>
            </div>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="text-xs">
            Current trend is flat or declining — goal may not be reached at this pace
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // How many more periods to reach target
  const periodsToGoal = Math.ceil((targetValue - currentValue) / m);

  return (
    <TooltipProvider delayDuration={200}>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="inline-flex items-center gap-1 text-xs mt-2 px-2 py-1 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 cursor-default">
            <TrendingUp className="h-3 w-3" />
            <span className="font-semibold">
              ~{periodsToGoal} period{periodsToGoal !== 1 ? "s" : ""} to goal
            </span>
          </div>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          At current pace (+{m.toFixed(1)}/period), target of {targetValue} reached in ~{periodsToGoal} periods
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};
