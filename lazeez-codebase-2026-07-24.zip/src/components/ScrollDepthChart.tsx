import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from 'recharts';
import { ArrowDown } from 'lucide-react';

interface ScrollData {
  page_name: string;
  max_depth_percent: number;
}

interface ScrollDepthChartProps {
  scrollData: ScrollData[];
}

export const ScrollDepthChart = ({ scrollData }: ScrollDepthChartProps) => {
  const chartData = useMemo(() => {
    const buckets = [
      { range: '0-10%', min: 0, max: 10, count: 0 },
      { range: '10-25%', min: 10, max: 25, count: 0 },
      { range: '25-50%', min: 25, max: 50, count: 0 },
      { range: '50-75%', min: 50, max: 75, count: 0 },
      { range: '75-90%', min: 75, max: 90, count: 0 },
      { range: '90-100%', min: 90, max: 100, count: 0 },
    ];

    scrollData.forEach(d => {
      const bucket = buckets.find(b => d.max_depth_percent >= b.min && d.max_depth_percent < b.max);
      if (bucket) bucket.count++;
      else if (d.max_depth_percent === 100) buckets[buckets.length - 1].count++;
    });

    return buckets;
  }, [scrollData]);

  const avgDepth = useMemo(() => {
    if (scrollData.length === 0) return 0;
    return Math.round(scrollData.reduce((sum, d) => sum + d.max_depth_percent, 0) / scrollData.length);
  }, [scrollData]);

  const pageDepths = useMemo(() => {
    const pages: Record<string, { total: number; count: number }> = {};
    scrollData.forEach(d => {
      if (!pages[d.page_name]) pages[d.page_name] = { total: 0, count: 0 };
      pages[d.page_name].total += d.max_depth_percent;
      pages[d.page_name].count++;
    });
    return Object.entries(pages)
      .map(([name, { total, count }]) => ({ name, avg: Math.round(total / count) }))
      .sort((a, b) => b.avg - a.avg);
  }, [scrollData]);

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <Card className="glass-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <ArrowDown className="h-4 w-4 text-primary" />
            Scroll Depth Distribution
          </CardTitle>
          <CardDescription className="text-xs">
            Average: {avgDepth}% | {scrollData.length} sessions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                <XAxis dataKey="range" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload?.length) {
                      return (
                        <div className="glass-card p-2 border border-border/50 rounded-lg text-xs">
                          <p className="font-medium">{payload[0].payload.range}</p>
                          <p className="text-primary font-bold">{payload[0].value} sessions</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <ArrowDown className="h-4 w-4 text-primary" />
            Scroll by Page
          </CardTitle>
          <CardDescription className="text-xs">Average scroll depth per page</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {pageDepths.length === 0 ? (
              <p className="text-sm text-muted-foreground">No scroll data yet</p>
            ) : (
              pageDepths.map(page => (
                <div key={page.name} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>{page.name}</span>
                    <span className="font-bold">{page.avg}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${page.avg}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
