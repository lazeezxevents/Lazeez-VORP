import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarRange, RotateCcw, CalendarIcon } from "lucide-react";
import { format, addDays, addMonths } from "date-fns";
import { cn } from "@/lib/utils";

const kpiSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name must be less than 100 characters"),
  type: z.enum(["number", "percentage", "formula"]),
  description: z.string().trim().max(500, "Description must be less than 500 characters").optional(),
  category: z.string().trim().max(50, "Category must be less than 50 characters").optional(),
  value: z.number().optional(),
});

interface EditKPIDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  kpi: any;
  allKPIs?: any[];
  onArchiveAndReset?: (kpi: any, newPeriodLabel: string) => Promise<void>;
}

export const EditKPIDialog = ({ open, onOpenChange, onSuccess, kpi, allKPIs = [], onArchiveAndReset }: EditKPIDialogProps) => {
  const [name, setName] = useState("");
  const [type, setType] = useState("number");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [value, setValue] = useState("");
  const [targetValue, setTargetValue] = useState("");
  const [warningThreshold, setWarningThreshold] = useState("");
  const [criticalThreshold, setCriticalThreshold] = useState("");
  const [periodLabel, setPeriodLabel] = useState("");
  const [periodStartDate, setPeriodStartDate] = useState<Date | undefined>(undefined);
  const [periodEndDate, setPeriodEndDate] = useState<Date | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  const [autoUpdateRelated, setAutoUpdateRelated] = useState(true);

  const isTotalVendors = kpi?.name === "Total Vendors Onboarded";
  const isTimeBased = ['Last 2 Weeks', 'Last 2 Months', 'Last Quarter'].includes(kpi?.name);

  // Helper to get period duration in days based on KPI name
  const getPeriodDuration = (name: string): { days?: number; months?: number } => {
    if (name === 'Last 2 Weeks') return { days: 14 };
    if (name === 'Last 2 Months') return { months: 2 };
    if (name === 'Last Quarter') return { months: 3 };
    return {};
  };

  // Auto-generate period label from dates
  const generatePeriodLabel = (start: Date | undefined, end: Date | undefined) => {
    if (!start || !end) return "";
    const startStr = format(start, "MMM dd").toUpperCase();
    const endStr = format(end, "MMM dd").toUpperCase();
    return `${startStr} - ${endStr}`;
  };

  // When start date changes, auto-calculate end date based on KPI type
  const handleStartDateChange = (date: Date | undefined) => {
    setPeriodStartDate(date);
    if (date && isTimeBased && kpi) {
      const duration = getPeriodDuration(kpi.name);
      let end: Date;
      if (duration.months) {
        end = addMonths(date, duration.months);
        end = addDays(end, -1); // inclusive end
      } else if (duration.days) {
        end = addDays(date, duration.days - 1); // inclusive end
      } else {
        return;
      }
      setPeriodEndDate(end);
      setPeriodLabel(generatePeriodLabel(date, end));
    }
  };

  const handleEndDateChange = (date: Date | undefined) => {
    setPeriodEndDate(date);
    if (periodStartDate && date) {
      setPeriodLabel(generatePeriodLabel(periodStartDate, date));
    }
  };

  useEffect(() => {
    if (kpi) {
      setName(kpi.name || "");
      setType(kpi.type || "number");
      setDescription(kpi.description || "");
      setCategory(kpi.category || "");
      setValue(kpi.value?.toString() || "");
      setTargetValue(kpi.target_value?.toString() || "");
      setWarningThreshold(kpi.warning_threshold?.toString() || "");
      setCriticalThreshold(kpi.critical_threshold?.toString() || "");
      setPeriodLabel(kpi.period_label || "");
      setPeriodStartDate(kpi.period_start_date ? new Date(kpi.period_start_date) : undefined);
      setPeriodEndDate(kpi.period_end_date ? new Date(kpi.period_end_date) : undefined);
    }
  }, [kpi]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const validatedData = kpiSchema.parse({
        name,
        type,
        description: description || undefined,
        category: category || undefined,
        value: value ? parseFloat(value) : undefined,
      });

      const newValue = validatedData.value ?? 0;
      const oldValue = kpi.value || 0;
      const difference = newValue - oldValue;

      // Update the main KPI including period label
      const { error } = await supabase
        .from('custom_kpis')
        .update({
          name: validatedData.name,
          type: validatedData.type,
          description: validatedData.description,
          category: validatedData.category,
          value: validatedData.value ?? null,
          target_value: targetValue ? parseFloat(targetValue) : null,
          warning_threshold: warningThreshold ? parseFloat(warningThreshold) : null,
          critical_threshold: criticalThreshold ? parseFloat(criticalThreshold) : null,
          period_label: periodLabel || null,
          period_start_date: periodStartDate ? format(periodStartDate, 'yyyy-MM-dd') : null,
          period_end_date: periodEndDate ? format(periodEndDate, 'yyyy-MM-dd') : null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', kpi.id);

      if (error) throw error;

      // Auto-update related KPIs for Total Vendors
      if (isTotalVendors && autoUpdateRelated && difference !== 0) {
        const relatedKPIs = allKPIs.filter(k => 
          ['Last 2 Weeks', 'Last 2 Months', 'Last Quarter'].includes(k.name) && 
          k.id !== kpi.id
        );

        for (const relatedKPI of relatedKPIs) {
          const currentValue = relatedKPI.value || 0;
          const updatedValue = Math.max(0, currentValue + difference);
          
          await supabase
            .from('custom_kpis')
            .update({
              value: updatedValue,
              updated_at: new Date().toISOString(),
            })
            .eq('id', relatedKPI.id);
        }

        const activeVendorsKPI = allKPIs.find(k => k.name === 'Active Vendors');
        if (activeVendorsKPI) {
          const currentActive = activeVendorsKPI.value || 0;
          await supabase
            .from('custom_kpis')
            .update({
              value: Math.max(0, currentActive + difference),
              updated_at: new Date().toISOString(),
            })
            .eq('id', activeVendorsKPI.id);
        }

        toast.success(`KPI updated! Related KPIs automatically adjusted by ${difference > 0 ? '+' : ''}${difference}`);
      } else {
        toast.success("KPI updated successfully");
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        toast.error((error.issues?.[0]?.message ?? error.message));
      } else {
        toast.error(error.message || "Failed to update KPI");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleArchiveAndReset = async () => {
    if (!onArchiveAndReset) return;
    
    const newPeriod = prompt(`Enter the new period label (e.g., "JAN 14 - JAN 28" for 2 weeks, "FEB - MAR" for 2 months, "MAR - MAY" for quarter):`);
    if (!newPeriod) return;

    setResetLoading(true);
    try {
      await onArchiveAndReset(kpi, newPeriod);
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || "Failed to reset period");
    } finally {
      setResetLoading(false);
    }
  };

  const getAutoUpdatePreview = () => {
    if (!isTotalVendors || !autoUpdateRelated) return null;
    
    const newValue = value ? parseFloat(value) : 0;
    const oldValue = kpi?.value || 0;
    const difference = newValue - oldValue;
    
    if (difference === 0) return null;

    const relatedKPIs = allKPIs.filter(k => 
      ['Last 2 Weeks', 'Last 2 Months', 'Last Quarter', 'Active Vendors'].includes(k.name) && 
      k.id !== kpi.id
    );

    return relatedKPIs.map(k => ({
      name: k.name,
      oldValue: k.value || 0,
      newValue: Math.max(0, (k.value || 0) + difference)
    }));
  };

  const preview = getAutoUpdatePreview();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card border-border/50 sm:max-w-[500px] animate-scale-in max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold bg-gradient-to-r from-primary to-primary-accent bg-clip-text text-transparent">
            Edit KPI
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="type">Type</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="number">Number</SelectItem>
                <SelectItem value="percentage">Percentage</SelectItem>
                <SelectItem value="formula">Formula</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="value">Value</Label>
            <Input
              id="value"
              type="number"
              step="any"
              value={value}
              onChange={(e) => setValue(e.target.value)}
            />
          </div>

          <div>
            <Label htmlFor="target">Goal Target</Label>
            <Input
              id="target"
              type="number"
              step="any"
              value={targetValue}
              onChange={(e) => setTargetValue(e.target.value)}
              placeholder="Optional target value"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="warning">Warning Threshold</Label>
              <Input
                id="warning"
                type="number"
                step="any"
                value={warningThreshold}
                onChange={(e) => setWarningThreshold(e.target.value)}
                placeholder="e.g., 80"
              />
            </div>
            <div>
              <Label htmlFor="critical">Critical Threshold</Label>
              <Input
                id="critical"
                type="number"
                step="any"
                value={criticalThreshold}
                onChange={(e) => setCriticalThreshold(e.target.value)}
                placeholder="e.g., 95"
              />
            </div>
          </div>
          {isTimeBased && (
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <CalendarRange className="h-4 w-4 text-primary" />
                Period Dates & Label
              </Label>
              
              <div className="grid grid-cols-2 gap-3">
                {/* Start Date */}
                <div>
                  <Label className="text-xs text-muted-foreground">Start Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal text-xs",
                          !periodStartDate && "text-muted-foreground"
                        )}
                        size="sm"
                      >
                        <CalendarIcon className="mr-1 h-3 w-3" />
                        {periodStartDate ? format(periodStartDate, "MMM dd, yyyy") : "Pick start"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={periodStartDate}
                        onSelect={handleStartDateChange}
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* End Date */}
                <div>
                  <Label className="text-xs text-muted-foreground">End Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal text-xs",
                          !periodEndDate && "text-muted-foreground"
                        )}
                        size="sm"
                      >
                        <CalendarIcon className="mr-1 h-3 w-3" />
                        {periodEndDate ? format(periodEndDate, "MMM dd, yyyy") : "Pick end"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={periodEndDate}
                        onSelect={handleEndDateChange}
                        disabled={(date) => periodStartDate ? date < periodStartDate : false}
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Auto-generated Period Label */}
              <div>
                <Label htmlFor="periodLabel" className="text-xs text-muted-foreground">Period Label (auto-generated from dates)</Label>
                <Input
                  id="periodLabel"
                  value={periodLabel}
                  onChange={(e) => setPeriodLabel(e.target.value)}
                  placeholder="e.g., FEB 11 - FEB 24"
                  className="text-sm"
                />
              </div>
              
              <p className="text-xs text-muted-foreground">
                When the end date passes, this KPI will auto-archive and start a new period.
              </p>
            </div>
          )}

          <div>
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          {/* Archive & Reset Period button for time-based KPIs */}
          {isTimeBased && onArchiveAndReset && (
            <div className="pt-2 border-t border-border">
              <Button
                type="button"
                variant="outline"
                className="w-full gap-2 hover:bg-primary/10 hover:border-primary"
                onClick={handleArchiveAndReset}
                disabled={resetLoading}
              >
                <RotateCcw className="h-4 w-4" />
                {resetLoading ? "Resetting..." : "Archive & Start New Period"}
              </Button>
              <p className="text-xs text-muted-foreground mt-2 text-center">
                Archives current value and resets to 0 with a new period label
              </p>
            </div>
          )}

          {/* Auto-update toggle for Total Vendors */}
          {isTotalVendors && (
            <div className="space-y-3 pt-2 border-t border-border">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="autoUpdate" 
                  checked={autoUpdateRelated} 
                  onCheckedChange={(checked) => setAutoUpdateRelated(checked as boolean)}
                />
                <Label htmlFor="autoUpdate" className="text-sm font-normal cursor-pointer">
                  Auto-update related KPIs (Last 2 Weeks, Last 2 Months, Last Quarter, Active Vendors)
                </Label>
              </div>

              {preview && preview.length > 0 && (
                <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                  <p className="text-xs font-medium text-muted-foreground">Preview of auto-updates:</p>
                  {preview.map(p => (
                    <div key={p.name} className="flex justify-between text-sm">
                      <span>{p.name}</span>
                      <span className="font-mono">
                        {p.oldValue} → <span className={p.newValue > p.oldValue ? "text-green-500" : p.newValue < p.oldValue ? "text-red-500" : ""}>
                          {p.newValue}
                        </span>
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="flex gap-2 justify-end pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="hover:bg-muted">
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="bg-gradient-to-r from-primary to-primary-accent hover:opacity-90 transition-opacity">
              {loading ? "Updating..." : "Update KPI"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};