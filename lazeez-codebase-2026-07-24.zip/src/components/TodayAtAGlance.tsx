import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Phone, MessageSquare, RefreshCw } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface TodayStats {
  queriesReceived: number;
  queriesResponded: number;
  callsMade: number;
  callsAnswered: number;
}

const REFRESH_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

export const TodayAtAGlance = () => {
  const [stats, setStats] = useState<TodayStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const today = new Date();
  const dayOfWeek = today.getDay();
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
  const todayDate = today.toISOString().split("T")[0];

  const fetchStats = useCallback(async (isManual = false) => {
    if (isManual) setIsRefreshing(true);

    const [vendorResult, callResult] = await Promise.all([
      supabase
        .from("vendor_responses")
        .select("inquiries_received, inquiries_responded, inquiries_received_weekend, inquiries_responded_weekend")
        .eq("date", todayDate)
        .maybeSingle(),
      supabase
        .from("call_logs")
        .select("calls_made, calls_answered")
        .eq("date", todayDate)
        .maybeSingle(),
    ]);

    const vendor = vendorResult.data;
    const calls = callResult.data;

    setStats({
      queriesReceived: vendor
        ? (isWeekend ? vendor.inquiries_received_weekend : vendor.inquiries_received)
        : 0,
      queriesResponded: vendor
        ? (isWeekend ? vendor.inquiries_responded_weekend : vendor.inquiries_responded)
        : 0,
      callsMade: calls?.calls_made ?? 0,
      callsAnswered: calls?.calls_answered ?? 0,
    });

    setLastRefreshed(new Date());
    setLoading(false);
    if (isManual) setIsRefreshing(false);
  }, [todayDate, isWeekend]);

  useEffect(() => {
    fetchStats();
    const interval = setInterval(() => fetchStats(), REFRESH_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [fetchStats]);

  const queryRate = stats && stats.queriesReceived > 0
    ? Math.round((stats.queriesResponded / stats.queriesReceived) * 100)
    : 0;

  const callRate = stats && stats.callsMade > 0
    ? Math.round((stats.callsAnswered / stats.callsMade) * 100)
    : 0;

  const formatRefreshTime = (date: Date) =>
    date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });

  return (
    <div className="border-b border-border/60 bg-muted/30 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 py-3">
        <div className="flex flex-wrap items-center gap-3 sm:gap-4">
          {/* Label */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
            </span>
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground whitespace-nowrap">
              Today {isWeekend ? "· Weekend" : ""}
            </span>
          </div>

          <div className="h-4 w-px bg-border hidden sm:block" />

          {/* Stats */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-6 flex-1">
            {/* Queries section */}
            <div className="flex items-center gap-2">
              <MessageSquare className="h-3.5 w-3.5 text-primary shrink-0" />
              <div className="flex items-center gap-2 text-xs">
                {loading ? (
                  <>
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-12" />
                  </>
                ) : (
                  <>
                    <span className="text-muted-foreground">Queries:</span>
                    <span className="font-semibold text-foreground">{stats?.queriesReceived ?? 0} received</span>
                    <span className="text-muted-foreground">·</span>
                    <span className="font-semibold text-foreground">{stats?.queriesResponded ?? 0} responded</span>
                    <span className="text-muted-foreground">·</span>
                    <span className={`font-bold ${queryRate >= 80 ? "text-green-500" : queryRate >= 50 ? "text-yellow-500" : "text-red-500"}`}>
                      {queryRate}%
                    </span>
                  </>
                )}
              </div>
            </div>

            <div className="h-4 w-px bg-border hidden sm:block" />

            {/* Calls section */}
            <div className="flex items-center gap-2">
              <Phone className="h-3.5 w-3.5 text-primary shrink-0" />
              <div className="flex items-center gap-2 text-xs">
                {loading ? (
                  <>
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-12" />
                  </>
                ) : (
                  <>
                    <span className="text-muted-foreground">Calls:</span>
                    <span className="font-semibold text-foreground">{stats?.callsMade ?? 0} made</span>
                    <span className="text-muted-foreground">·</span>
                    <span className="font-semibold text-foreground">{stats?.callsAnswered ?? 0} answered</span>
                    <span className="text-muted-foreground">·</span>
                    <span className={`font-bold ${callRate >= 80 ? "text-green-500" : callRate >= 50 ? "text-yellow-500" : "text-red-500"}`}>
                      {callRate}%
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Refresh info */}
          <div className="flex items-center gap-1.5 ml-auto shrink-0">
            {lastRefreshed && !loading && (
              <span className="text-xs text-muted-foreground hidden md:inline">
                Updated {formatRefreshTime(lastRefreshed)}
              </span>
            )}
            <button
              onClick={() => fetchStats(true)}
              disabled={isRefreshing || loading}
              className="p-1 rounded hover:bg-muted transition-colors disabled:opacity-40"
              title="Refresh now"
            >
              <RefreshCw className={`h-3.5 w-3.5 text-muted-foreground ${isRefreshing ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
