import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MessageSquare, CheckCircle, CalendarDays, Save, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface VendorResponse {
  id: string;
  date: string;
  inquiries_received: number;
  inquiries_responded: number;
  inquiries_received_weekend: number;
  inquiries_responded_weekend: number;
  is_weekend: boolean;
  is_archived: boolean;
}

interface EditVendorResponseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entry: VendorResponse | null;
  onSave: () => void;
}

export function EditVendorResponseDialog({ open, onOpenChange, entry, onSave }: EditVendorResponseDialogProps) {
  const [inquiriesReceived, setInquiriesReceived] = useState(0);
  const [inquiriesResponded, setInquiriesResponded] = useState(0);
  const [weekendReceived, setWeekendReceived] = useState(0);
  const [weekendResponded, setWeekendResponded] = useState(0);
  const [saving, setSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (entry) {
      setInquiriesReceived(entry.inquiries_received);
      setInquiriesResponded(entry.inquiries_responded);
      setWeekendReceived(entry.inquiries_received_weekend);
      setWeekendResponded(entry.inquiries_responded_weekend);
    }
  }, [entry]);

  const weekdayRate = inquiriesReceived > 0 
    ? ((inquiriesResponded / inquiriesReceived) * 100).toFixed(1) 
    : '0';
    
  const weekendRate = weekendReceived > 0 
    ? ((weekendResponded / weekendReceived) * 100).toFixed(1) 
    : '0';

  const handleSave = async () => {
    if (!entry) return;
    setSaving(true);

    const { error } = await supabase
      .from('vendor_responses')
      .update({
        inquiries_received: inquiriesReceived,
        inquiries_responded: inquiriesResponded,
        inquiries_received_weekend: weekendReceived,
        inquiries_responded_weekend: weekendResponded
      })
      .eq('id', entry.id);

    setSaving(false);

    if (error) {
      toast.error("Failed to update vendor response");
    } else {
      toast.success("Vendor response updated successfully");
      onSave();
      onOpenChange(false);
    }
  };

  const handleDelete = async () => {
    if (!entry) return;
    setSaving(true);

    const { error } = await supabase
      .from('vendor_responses')
      .delete()
      .eq('id', entry.id);

    setSaving(false);
    setShowDeleteConfirm(false);

    if (error) {
      toast.error("Failed to delete vendor response");
    } else {
      toast.success("Vendor response deleted successfully");
      onSave();
      onOpenChange(false);
    }
  };

  if (!entry) return null;

  const entryDate = new Date(entry.date);
  const entryDay = entryDate.getDay();
  const entryIsWeekend = entryDay === 0 || entryDay === 6;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Vendor Response</DialogTitle>
            <DialogDescription>
              {format(entryDate, 'EEEE, MMMM d, yyyy')}
              {entryIsWeekend && (
                <span className="ml-2 px-2 py-0.5 text-xs font-medium rounded-full bg-primary/20 text-primary">
                  Weekend
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            {/* Weekday Inquiries */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <CalendarDays className="h-4 w-4" />
                Weekday Inquiries
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-2 text-xs">
                    <MessageSquare className="h-3 w-3" />
                    Received
                  </Label>
                  <Input
                    type="number"
                    value={inquiriesReceived}
                    onChange={(e) => setInquiriesReceived(parseInt(e.target.value) || 0)}
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-2 text-xs">
                    <CheckCircle className="h-3 w-3" />
                    Responded
                  </Label>
                  <Input
                    type="number"
                    value={inquiriesResponded}
                    onChange={(e) => setInquiriesResponded(parseInt(e.target.value) || 0)}
                    min="0"
                  />
                </div>
              </div>
              <div className="text-sm text-muted-foreground">
                Weekday Rate: <span className="font-bold text-primary">{weekdayRate}%</span>
              </div>
            </div>
            
            {/* Weekend Inquiries */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-primary" />
                Weekend Inquiries
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-2 text-xs">
                    <MessageSquare className="h-3 w-3" />
                    Received
                  </Label>
                  <Input
                    type="number"
                    value={weekendReceived}
                    onChange={(e) => setWeekendReceived(parseInt(e.target.value) || 0)}
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-2 text-xs">
                    <CheckCircle className="h-3 w-3" />
                    Responded
                  </Label>
                  <Input
                    type="number"
                    value={weekendResponded}
                    onChange={(e) => setWeekendResponded(parseInt(e.target.value) || 0)}
                    min="0"
                  />
                </div>
              </div>
              <div className="text-sm text-muted-foreground">
                Weekend Rate: <span className="font-bold text-primary">{weekendRate}%</span>
              </div>
            </div>
          </div>
          
          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="destructive"
              onClick={() => setShowDeleteConfirm(true)}
              disabled={saving}
              className="w-full sm:w-auto"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
            <Button onClick={handleSave} disabled={saving} className="w-full sm:w-auto">
              <Save className="h-4 w-4 mr-2" />
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Vendor Response</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the vendor response for {format(entryDate, 'MMMM d, yyyy')}? 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
