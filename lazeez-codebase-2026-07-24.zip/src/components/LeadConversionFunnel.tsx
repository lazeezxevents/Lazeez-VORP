import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useMemo, useState } from "react";
import { Users, UserPlus, Handshake, CheckCircle2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface LeadConversionFunnelProps {
  totalOnboarded: number;
  activeVendors: number;
  leftVendors: number;
  terminatedVendors: number;
  totalInquiries: number;
  totalResponded: number;
}

export const LeadConversionFunnel = ({
  totalOnboarded,
  activeVendors,
  leftVendors,
  terminatedVendors,
  totalInquiries,
  totalResponded,
}: LeadConversionFunnelProps) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const stages = useMemo(() => {
    const contacted = totalInquiries;
    const engaged = totalResponded;
    const onboarded = totalOnboarded;
    const active = activeVendors;

    return [
      {
        label: "Contacted",
        sublabel: "Total inquiries received",
        value: contacted,
        icon: Users,
        pct: 100,
        widthPct: 100,
        gradient: "from-primary to-primary/80",
        bgColor: "bg-primary/10",
        textColor: "text-primary",
      },
      {
        label: "Engaged",
        sublabel: "Inquiries responded",
        value: engaged,
        icon: Handshake,
        pct: contacted > 0 ? Math.round((engaged / contacted) * 100) : 0,
        widthPct: contacted > 0 ? Math.max(30, (engaged / contacted) * 100) : 30,
        gradient: "from-chart-1 to-chart-1/80",
        bgColor: "bg-chart-1/10",
        textColor: "text-chart-1",
      },
      {
        label: "Onboarded",
        sublabel: "Vendors signed up",
        value: onboarded,
        icon: UserPlus,
        pct: contacted > 0 ? Math.round((onboarded / contacted) * 100) : 0,
        widthPct: contacted > 0 ? Math.max(20, (onboarded / contacted) * 100) : 20,
        gradient: "from-chart-4 to-chart-4/80",
        bgColor: "bg-chart-4/10",
        textColor: "text-chart-4",
      },
      {
        label: "Active",
        sublabel: "Currently active vendors",
        value: active,
        icon: CheckCircle2,
        pct: contacted > 0 ? Math.round((active / contacted) * 100) : 0,
        widthPct: contacted > 0 ? Math.max(15, (active / contacted) * 100) : 15,
        gradient: "from-chart-2 to-chart-2/80",
        bgColor: "bg-chart-2/10",
        textColor: "text-chart-2",
      },
    ];
  }, [totalInquiries, totalResponded, totalOnboarded, activeVendors]);

  const dropOffs = useMemo(() => {
    const result: { lost: number; rate: number }[] = [];
    for (let i = 0; i < stages.length - 1; i++) {
      const lost = stages[i].value - stages[i + 1].value;
      const rate = stages[i].value > 0 ? Math.round((lost / stages[i].value) * 100) : 0;
      result.push({ lost, rate });
    }
    return result;
  }, [stages]);

  const overallConversion = stages[0].value > 0
    ? Math.round((stages[stages.length - 1].value / stages[0].value) * 100)
    : 0;

  return (
    <Card className="glass-card glass-hover border-border/50">
      <CardHeader className="pb-2 sm:pb-3">
        <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
          <Users className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
          Lead Conversion Funnel
        </CardTitle>
        <CardDescription className="text-xs sm:text-sm">From initial contact to active vendor</CardDescription>
      </CardHeader>
      <CardContent className="pb-4">
        <TooltipProvider>
          {/* Visual funnel */}
          <div className="relative flex flex-col items-center gap-0 py-2">
            {stages.map((stage, i) => {
              const Icon = stage.icon;
              const isHovered = hoveredIndex === i;
              const dropOff = i < stages.length - 1 ? dropOffs[i] : null;

              return (
                <div key={stage.label} className="w-full flex flex-col items-center">
                  {/* Funnel bar */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div
                        className={`relative cursor-pointer transition-all duration-300 rounded-lg ${
                          isHovered ? "scale-[1.02] shadow-lg" : ""
                        }`}
                        style={{ width: `${stage.widthPct}%` }}
                        onMouseEnter={() => setHoveredIndex(i)}
                        onMouseLeave={() => setHoveredIndex(null)}
                      >
                        <div
                          className={`bg-gradient-to-r ${stage.gradient} rounded-lg py-2.5 sm:py-3 px-3 sm:px-4 flex items-center justify-between transition-all duration-300 ${
                            isHovered ? "brightness-110" : ""
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <Icon className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-primary-foreground flex-shrink-0" />
                            <span className="text-xs sm:text-sm font-semibold text-primary-foreground truncate">
                              {stage.label}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 flex-shrink-0">
                            <span className="text-sm sm:text-base font-bold text-primary-foreground">
                              {stage.value.toLocaleString()}
                            </span>
                            {i > 0 && (
                              <span className="text-[9px] sm:text-[10px] text-primary-foreground/70 font-medium">
                                ({stage.pct}%)
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="text-xs">
                      <p className="font-semibold">{stage.label}</p>
                      <p className="text-muted-foreground">{stage.sublabel}</p>
                      <p className="mt-1">{stage.value.toLocaleString()} ({stage.pct}% of total)</p>
                      {dropOff && dropOff.lost > 0 && (
                        <p className="text-destructive mt-0.5">
                          ↓ {dropOff.lost} lost before next stage ({dropOff.rate}%)
                        </p>
                      )}
                    </TooltipContent>
                  </Tooltip>

                  {/* Drop-off connector */}
                  {i < stages.length - 1 && (
                    <div className="flex items-center gap-2 py-1">
                      <div className="w-px h-4 bg-border" />
                      {dropOff && dropOff.lost > 0 && (
                        <span className="text-[9px] sm:text-[10px] text-destructive font-medium whitespace-nowrap">
                          ▼ {dropOff.rate}% drop
                        </span>
                      )}
                      <div className="w-px h-4 bg-border" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </TooltipProvider>

        {/* Overall conversion footer */}
        <div className="mt-3 pt-3 border-t border-border/50">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Overall Conversion Rate</span>
            <div className="flex items-center gap-2">
              <div className="w-20 sm:w-24 h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-chart-2 to-chart-2/70 transition-all duration-700"
                  style={{ width: `${Math.min(overallConversion, 100)}%` }}
                />
              </div>
              <span className="text-sm font-bold text-chart-2">
                {overallConversion}%
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
