import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, AreaChart, Area } from 'recharts';
import { Clock, Calendar } from 'lucide-react';
import { format, parseISO, getHours, getDay } from 'date-fns';

interface VisitorLog {
  id: string;
  visited_at: string;
}

interface VisitorPeakHoursChartProps {
  logs: VisitorLog[];
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const VisitorPeakHoursChart = ({ logs }: VisitorPeakHoursChartProps) => {
  const hourlyData = useMemo(() => {
    const hours: number[] = Array(24).fill(0);
    logs.forEach(log => {
      const hour = getHours(parseISO(log.visited_at));
      hours[hour]++;
    });
    return hours.map((count, hour) => ({
      hour: `${hour.toString().padStart(2, '0')}:00`,
      visits: count,
      label: hour === 0 ? '12 AM' : hour === 12 ? '12 PM' : hour < 12 ? `${hour} AM` : `${hour - 12} PM`,
    }));
  }, [logs]);

  const dailyData = useMemo(() => {
    const days: number[] = Array(7).fill(0);
    logs.forEach(log => {
      const day = getDay(parseISO(log.visited_at));
      days[day]++;
    });
    return days.map((count, index) => ({
      day: DAYS[index],
      visits: count,
    }));
  }, [logs]);

  const peakHour = useMemo(() => {
    let maxVisits = 0;
    let peak = 0;
    hourlyData.forEach((data, hour) => {
      if (data.visits > maxVisits) {
        maxVisits = data.visits;
        peak = hour;
      }
    });
    return hourlyData[peak];
  }, [hourlyData]);

  const peakDay = useMemo(() => {
    let maxVisits = 0;
    let peak = '';
    dailyData.forEach(data => {
      if (data.visits > maxVisits) {
        maxVisits = data.visits;
        peak = data.day;
      }
    });
    return { day: peak, visits: maxVisits };
  }, [dailyData]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-card p-3 border border-border/50 rounded-lg shadow-lg">
          <p className="text-sm font-medium">{label}</p>
          <p className="text-xs text-muted-foreground">
            Visits: <span className="font-bold text-primary">{payload[0].value}</span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-4">
      {/* Peak Stats */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="glass-card">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              <div>
                <div className="text-lg font-bold text-primary">{peakHour?.label || 'N/A'}</div>
                <p className="text-xs text-muted-foreground">Peak Hour ({peakHour?.visits || 0} visits)</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-chart-2" />
              <div>
                <div className="text-lg font-bold" style={{ color: 'hsl(var(--chart-2))' }}>
                  {peakDay.day || 'N/A'}
                </div>
                <p className="text-xs text-muted-foreground">Busiest Day ({peakDay.visits} visits)</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Hourly Distribution */}
      <Card className="glass-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4 text-primary" />
            Hourly Traffic Pattern
          </CardTitle>
          <CardDescription className="text-xs">Visitor distribution throughout the day</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyData}>
                <defs>
                  <linearGradient id="hourlyGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                <XAxis 
                  dataKey="hour" 
                  tick={{ fontSize: 8 }} 
                  className="text-muted-foreground" 
                  interval={2}
                />
                <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="visits" 
                  stroke="hsl(var(--primary))" 
                  fill="url(#hourlyGradient)" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Daily Distribution */}
      <Card className="glass-card">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Calendar className="h-4 w-4 text-primary" />
            Daily Traffic Pattern
          </CardTitle>
          <CardDescription className="text-xs">Visitor distribution by day of week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                <XAxis dataKey="day" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="visits" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
