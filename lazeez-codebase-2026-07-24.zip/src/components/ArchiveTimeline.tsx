import { CalendarRange, TrendingUp, Clock } from "lucide-react";
import { format } from "date-fns";

interface ArchivedKPIRecord {
  id: string;
  kpi_id: string;
  kpi_name: string;
  category: string | null;
  description: string | null;
  value_at_archive: number;
  archived_at: string;
  archived_by: string | null;
  period_label?: string | null;
  period_start_date?: string | null;
  period_end_date?: string | null;
}

interface ArchiveTimelineProps {
  records: ArchivedKPIRecord[];
  kpiName: string;
}

export const ArchiveTimeline = ({ records, kpiName }: ArchiveTimelineProps) => {
  const formatDate = (dateString?: string | null) => {
    if (!dateString) return "N/A";
    try {
      return format(new Date(dateString), "MMM dd, yyyy");
    } catch {
      return "N/A";
    }
  };

  // Sort by archived_at descending (newest first)
  const sortedRecords = [...records].sort(
    (a, b) => new Date(b.archived_at).getTime() - new Date(a.archived_at).getTime()
  );

  if (sortedRecords.length === 0) return null;

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
        <Clock className="h-4 w-4 text-primary" />
        {kpiName} Timeline
      </h4>
      <div className="relative pl-6">
        {/* Timeline line */}
        <div className="absolute left-2 top-2 bottom-2 w-0.5 bg-gradient-to-b from-primary via-primary/50 to-border rounded-full" />
        
        <div className="space-y-4">
          {sortedRecords.map((record, index) => (
            <div key={record.id} className="relative">
              {/* Timeline dot */}
              <div className={`absolute -left-4 top-1 w-3 h-3 rounded-full border-2 ${
                index === 0 
                  ? 'bg-primary border-primary shadow-lg shadow-primary/30' 
                  : 'bg-background border-primary/50'
              }`} />
              
              <div className="bg-muted/30 rounded-lg p-3 hover:bg-muted/50 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary-accent bg-clip-text text-transparent">
                    {record.value_at_archive}
                  </span>
                  {record.period_label && (
                    <div className="flex items-center gap-1.5 text-xs px-2 py-1 rounded-full bg-primary/10 text-primary font-medium">
                      <CalendarRange className="h-3 w-3" />
                      {record.period_label}
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <TrendingUp className="h-3 w-3" />
                  Archived: {formatDate(record.archived_at)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};