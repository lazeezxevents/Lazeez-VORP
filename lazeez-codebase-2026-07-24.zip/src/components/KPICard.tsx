import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LucideIcon, MoreVertical, Pencil, Trash2, Archive, CalendarRange, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { KPISparkline } from "@/components/KPISparkline";
import { TrendForecast } from "@/components/TrendForecast";
import { KPIAnnotations } from "@/components/KPIAnnotations";
import { format } from "date-fns";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface KPICardProps {
  id?: string;
  title: string;
  value: string | number;
  subtitle?: string;
  periodLabel?: string;
  icon?: LucideIcon;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  updatedAt?: string;
  isAdmin?: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
  onArchive?: () => void;
  delta?: number;
  deltaLabel?: string;
  sparklineData?: { value: number; label: string }[];
  targetValue?: number | null;
  warningThreshold?: number | null;
  criticalThreshold?: number | null;
}

export const KPICard = ({ 
  id,
  title, 
  value, 
  subtitle,
  periodLabel,
  icon: Icon, 
  trend, 
  trendValue,
  updatedAt,
  isAdmin,
  onEdit,
  onDelete,
  onArchive,
  delta,
  deltaLabel,
  sparklineData,
  targetValue,
  warningThreshold,
  criticalThreshold,
}: KPICardProps) => {
  const trendColors = {
    up: "text-green-600 dark:text-green-400",
    down: "text-red-600 dark:text-red-400",
    neutral: "text-muted-foreground",
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return null;
    try {
      return format(new Date(dateString), "MMM dd, yyyy HH:mm:ss");
    } catch {
      return null;
    }
  };

  const hasDelta = delta !== undefined && delta !== null;
  const deltaPositive = hasDelta && delta > 0;
  const deltaNeutral = hasDelta && delta === 0;
  const deltaNegative = hasDelta && delta < 0;

  // Threshold alert level
  const numValue = typeof value === 'string' ? parseFloat(value) || 0 : Number(value) || 0;
  const isCritical = criticalThreshold != null && numValue >= criticalThreshold;
  const isWarning = !isCritical && warningThreshold != null && numValue >= warningThreshold;

  const borderClass = isCritical
    ? "border-destructive/60 shadow-[0_0_15px_-3px_hsl(var(--destructive)/0.3)]"
    : isWarning
    ? "border-orange-400/60 shadow-[0_0_15px_-3px_rgba(251,146,60,0.3)]"
    : "border-border/50";

  return (
    <Card className={`glass-card glass-hover ${borderClass} relative overflow-hidden group animate-fade-in`}>
      <div className={`absolute inset-0 ${
        isCritical ? "bg-gradient-to-br from-destructive/10 via-transparent to-destructive/5" :
        isWarning ? "bg-gradient-to-br from-orange-500/10 via-transparent to-orange-400/5" :
        "bg-gradient-to-br from-primary/5 via-transparent to-primary-accent/5 opacity-0 group-hover:opacity-100"
      } transition-opacity duration-300`} />
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0 relative z-10">
        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
          {Icon && (
            <div className="p-1.5 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <Icon className="h-4 w-4 text-primary" />
            </div>
          )}
          {title}
        </CardTitle>
        <div className="flex items-center gap-2">
          {isAdmin && onEdit && onDelete && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-primary/10"
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="glass-card border-border z-50 animate-scale-in">
                <DropdownMenuItem onClick={onEdit} className="cursor-pointer hover:bg-primary/10">
                  <Pencil className="h-4 w-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                {onArchive && (
                  <DropdownMenuItem onClick={onArchive} className="cursor-pointer hover:bg-primary/10">
                    <Archive className="h-4 w-4 mr-2" />
                    Archive
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={onDelete} className="cursor-pointer text-destructive hover:bg-destructive/10">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </CardHeader>
      <CardContent className="relative z-10">
        <div className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-primary via-primary-accent to-primary bg-clip-text text-transparent break-words tracking-tight">
          {value}
        </div>
        {periodLabel && (
          <div className="inline-flex items-center gap-1.5 text-xs mt-2 px-2 py-1 rounded-full bg-primary/10 text-primary font-medium">
            <CalendarRange className="h-3 w-3" />
            {periodLabel}
          </div>
        )}
        {subtitle && <p className="text-xs text-muted-foreground mt-2">{subtitle}</p>}

        {/* Goal progress bar */}
        {targetValue != null && targetValue > 0 && (() => {
          const numValue = typeof value === 'string' ? parseFloat(value) || 0 : Number(value) || 0;
          const pct = Math.min(100, Math.round((numValue / targetValue) * 100));
          return (
            <div className="mt-3 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Goal: {targetValue}</span>
                <span className={`font-semibold ${pct >= 100 ? "text-green-600 dark:text-green-400" : "text-primary"}`}>
                  {pct}%
                </span>
              </div>
              <Progress value={pct} className="h-1.5" />
            </div>
          );
        })()}

        {/* Threshold alert badge */}
        {(isCritical || isWarning) && (
          <div className={`inline-flex items-center gap-1 text-xs mt-3 px-2 py-1 rounded-full font-semibold ${
            isCritical
              ? "bg-destructive/10 text-destructive"
              : "bg-orange-500/10 text-orange-600 dark:text-orange-400"
          }`}>
            <span>{isCritical ? "🚨" : "⚠️"}</span>
            <span>{isCritical ? "Critical threshold reached" : "Warning threshold reached"}</span>
          </div>
        )}

        {/* Delta badge vs last archive */}
        {hasDelta && (
          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className={`inline-flex items-center gap-1 text-xs mt-3 px-2 py-1 rounded-full cursor-default select-none ${
                  deltaPositive
                    ? "bg-green-500/10 text-green-600 dark:text-green-400"
                    : deltaNegative
                    ? "bg-red-500/10 text-red-600 dark:text-red-400"
                    : "bg-muted text-muted-foreground"
                }`}>
                  {deltaPositive && <TrendingUp className="h-3 w-3" />}
                  {deltaNegative && <TrendingDown className="h-3 w-3" />}
                  {deltaNeutral && <Minus className="h-3 w-3" />}
                  <span className="font-semibold">
                    {deltaPositive ? "+" : ""}{delta} vs last period
                  </span>
                </div>
              </TooltipTrigger>
              {deltaLabel && (
                <TooltipContent side="bottom" className="text-xs">
                  Last archived: <span className="font-semibold">{deltaLabel}</span>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        )}

        {trend && trendValue && (
          <div className={`inline-flex items-center gap-1 text-xs mt-3 px-2 py-1 rounded-full ${
            trend === "up" ? "bg-green-500/10 text-green-600 dark:text-green-400" : 
            trend === "down" ? "bg-red-500/10 text-red-600 dark:text-red-400" : 
            "bg-muted text-muted-foreground"
          }`}>
            <span className="font-semibold">{trend === "up" ? "↑" : trend === "down" ? "↓" : "→"}</span>
            <span>{trendValue}</span>
          </div>
        )}
        {sparklineData && sparklineData.length >= 2 && (
          <KPISparkline data={sparklineData} />
        )}

        {/* Trend Forecast */}
        {targetValue != null && targetValue > 0 && sparklineData && sparklineData.length >= 2 && (
          <TrendForecast
            currentValue={typeof value === 'string' ? parseFloat(value) || 0 : Number(value) || 0}
            targetValue={targetValue}
            sparklineData={sparklineData}
          />
        )}

        {/* Team Annotations */}
        {id && (
          <div className="flex items-center gap-2 mt-2">
            <KPIAnnotations kpiId={id} isAdmin={isAdmin} />
          </div>
        )}

        {updatedAt && (
          <p className="text-xs text-muted-foreground/70 mt-3 flex items-center gap-1">
            <span className="w-1 h-1 rounded-full bg-primary animate-pulse" />
            Updated: {formatDate(updatedAt)}
          </p>
        )}
      </CardContent>
    </Card>
  );
};
