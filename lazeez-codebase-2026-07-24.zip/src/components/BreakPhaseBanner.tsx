import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PauseCircle, Play, AlertTriangle, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface BreakPhaseBannerProps {
  isAdmin?: boolean;
}

export const BreakPhaseBanner = ({ isAdmin }: BreakPhaseBannerProps) => {
  const [breakData, setBreakData] = useState<{
    id: string;
    is_active: boolean;
    reason: string | null;
    activated_at: string | null;
  } | null>(null);
  const [editing, setEditing] = useState(false);
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchBreakPhase = async () => {
    const { data } = await supabase
      .from("break_phase" as any)
      .select("*")
      .limit(1)
      .maybeSingle();
    if (data) setBreakData(data as any);
  };

  useEffect(() => {
    fetchBreakPhase();
  }, []);

  const toggleBreak = async (activate: boolean) => {
    if (!breakData) return;
    if (activate && !reason.trim()) {
      toast.error("Please provide a reason for the break");
      return;
    }
    setLoading(true);
    try {
      const updates: any = {
        is_active: activate,
        reason: activate ? reason.trim() : breakData.reason,
        activated_at: activate ? new Date().toISOString() : breakData.activated_at,
        deactivated_at: activate ? null : new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      const { error } = await supabase
        .from("break_phase" as any)
        .update(updates)
        .eq("id", breakData.id);
      if (error) throw error;
      toast.success(activate ? "Break phase activated" : "Break phase ended — vendoring resumed!");
      setEditing(false);
      fetchBreakPhase();
    } catch (e: any) {
      toast.error(e.message || "Failed to update break phase");
    } finally {
      setLoading(false);
    }
  };

  if (!breakData) return null;

  // Active break banner — visible to everyone
  if (breakData.is_active) {
    return (
      <div className="bg-amber-500/15 border border-amber-500/30 backdrop-blur-sm">
        <div className="container mx-auto px-4 sm:px-6 py-3">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-amber-500/20">
                <PauseCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-amber-700 dark:text-amber-300 text-sm">
                    Vendoring on Break
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-amber-500/20 text-amber-700 dark:text-amber-300 animate-pulse">
                    <AlertTriangle className="h-3 w-3" />
                    PAUSED
                  </span>
                </div>
                <p className="text-xs text-amber-600/80 dark:text-amber-400/80 mt-0.5">
                  {breakData.reason || "No reason provided"}
                </p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  Other duties remain operational
                </p>
              </div>
            </div>
            {isAdmin && (
              <Button
                size="sm"
                variant="outline"
                className="h-8 gap-1.5 text-xs border-amber-500/30 text-amber-700 dark:text-amber-300 hover:bg-amber-500/10"
                onClick={() => toggleBreak(false)}
                disabled={loading}
              >
                <Play className="h-3.5 w-3.5" />
                Resume Vendoring
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Admin-only: toggle to activate break
  if (!isAdmin) return null;

  if (editing) {
    return (
      <div className="bg-muted/50 border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 py-3">
          <div className="flex items-center gap-3 flex-wrap">
            <PauseCircle className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            <Input
              placeholder="Reason for break (e.g., Ramadan break, Annual leave...)"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="h-8 text-xs max-w-md"
            />
            <Button
              size="sm"
              variant="destructive"
              className="h-8 gap-1.5 text-xs"
              onClick={() => toggleBreak(true)}
              disabled={loading}
            >
              <PauseCircle className="h-3.5 w-3.5" />
              Activate Break
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-8 text-xs"
              onClick={() => { setEditing(false); setReason(""); }}
            >
              Cancel
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-muted/30 border-b border-border/50">
      <div className="container mx-auto px-4 sm:px-6 py-1.5 flex justify-end">
        <Button
          size="sm"
          variant="ghost"
          className="h-7 gap-1.5 text-[11px] text-muted-foreground hover:text-foreground"
          onClick={() => setEditing(true)}
        >
          <PauseCircle className="h-3.5 w-3.5" />
          Set Break Phase
        </Button>
      </div>
    </div>
  );
};
