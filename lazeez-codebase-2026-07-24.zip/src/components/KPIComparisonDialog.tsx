import { useState, useMemo, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  ResponsiveContainer, Tooltip, XAxis, YAxis, Legend,
  CartesianGrid, Area, ComposedChart, ReferenceLine,
} from "recharts";
import { ArrowLeftRight, TrendingUp, TrendingDown, Target, AlertTriangle, BarChart3, Minus } from "lucide-react";

interface KPIComparisonDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  allKPIs: any[];
  getSparklineData: (kpiId: string, currentValue: number) => { value: number; label: string }[];
}

const COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--chart-5))",
  "hsl(var(--chart-3))",
];

const FILL_COLORS = [
  "hsl(var(--primary) / 0.1)",
  "hsl(var(--chart-5) / 0.1)",
  "hsl(var(--chart-3) / 0.1)",
];

const SESSION_KEY = "kpi-comparison-selections";

function computeStats(data: { value: number; label: string }[], kpi: any) {
  if (!data.length) return null;
  const first = data[0].value;
  const last = data[data.length - 1].value;
  const pctChange = first !== 0 ? ((last - first) / first) * 100 : 0;
  const avg = data.reduce((s, d) => s + d.value, 0) / data.length;
  const min = Math.min(...data.map(d => d.value));
  const max = Math.max(...data.map(d => d.value));
  const targetProgress = kpi?.target_value ? (last / kpi.target_value) * 100 : null;
  return { first, last, pctChange, avg, min, max, targetProgress, delta: last - first };
}

function correlationDirection(
  dataA: { value: number }[],
  dataB: { value: number }[]
): "same" | "diverging" | "neutral" {
  const len = Math.min(dataA.length, dataB.length);
  if (len < 2) return "neutral";
  const trendA = dataA[len - 1].value - dataA[0].value;
  const trendB = dataB[len - 1].value - dataB[0].value;
  if ((trendA > 0 && trendB > 0) || (trendA < 0 && trendB < 0)) return "same";
  if ((trendA > 0 && trendB < 0) || (trendA < 0 && trendB > 0)) return "diverging";
  return "neutral";
}

export const KPIComparisonDialog = ({
  open,
  onOpenChange,
  allKPIs,
  getSparklineData,
}: KPIComparisonDialogProps) => {
  const [selections, setSelections] = useState<string[]>(["", ""]);

  useEffect(() => {
    try {
      const saved = sessionStorage.getItem(SESSION_KEY);
      if (saved) setSelections(JSON.parse(saved));
    } catch {}
  }, []);

  useEffect(() => {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(selections));
  }, [selections]);

  const setKpi = (index: number, value: string) => {
    setSelections((prev) => {
      const next = [...prev];
      next[index] = value;
      return next;
    });
  };

  const addThird = () => setSelections((prev) => [...prev.slice(0, 2), ""]);
  const removeThird = () => setSelections((prev) => prev.slice(0, 2));
  const swap = () => setSelections((prev) => [prev[1], prev[0], ...prev.slice(2)]);

  const kpiObjects = selections.map((id) => allKPIs.find((k) => k.id === id));
  const datasets = selections.map((id, i) =>
    id ? getSparklineData(id, kpiObjects[i]?.value || 0) : []
  );
  const stats = datasets.map((d, i) => computeStats(d, kpiObjects[i]));

  const activeCount = selections.filter(Boolean).length;

  const needsDualAxis = useMemo(() => {
    const avgs = stats.filter(Boolean).map((s) => s!.avg);
    if (avgs.length < 2) return false;
    const maxAvg = Math.max(...avgs);
    const minAvg = Math.min(...avgs.filter((a) => a > 0));
    return minAvg > 0 && maxAvg / minAvg > 5;
  }, [stats]);

  const maxLen = Math.max(...datasets.map((d) => d.length), 0);
  const merged = useMemo(
    () =>
      Array.from({ length: maxLen }, (_, i) => ({
        label: datasets.find((d) => d[i]?.label)?.[i]?.label || `${i + 1}`,
        a: datasets[0]?.[i]?.value ?? null,
        b: datasets[1]?.[i]?.value ?? null,
        c: datasets[2]?.[i]?.value ?? null,
      })),
    [datasets, maxLen]
  );

  const names = selections.map(
    (id, i) => allKPIs.find((k) => k.id === id)?.name || `KPI ${String.fromCharCode(65 + i)}`
  );

  const correlation =
    activeCount >= 2 ? correlationDirection(datasets[0], datasets[1]) : "neutral";

  const thresholdLines: { value: number; color: string; label: string; yAxisId: string }[] = [];
  selections.forEach((id, i) => {
    const kpi = kpiObjects[i];
    if (!kpi) return;
    const yId = needsDualAxis && i === 1 ? "right" : "left";
    if (kpi.warning_threshold != null) {
      thresholdLines.push({ value: kpi.warning_threshold, color: "hsl(var(--chart-4))", label: `${names[i]} warn`, yAxisId: yId });
    }
    if (kpi.critical_threshold != null) {
      thresholdLines.push({ value: kpi.critical_threshold, color: "hsl(var(--destructive))", label: `${names[i]} crit`, yAxisId: yId });
    }
  });

  const selectedIds = new Set(selections.filter(Boolean));

  // Find winner (highest target progress or highest % change)
  const winner = useMemo(() => {
    const activeStats = stats.map((s, i) => ({ s, i })).filter(x => x.s);
    if (activeStats.length < 2) return null;
    const byTarget = activeStats.filter(x => x.s!.targetProgress !== null);
    if (byTarget.length >= 2) {
      const best = byTarget.reduce((a, b) => (a.s!.targetProgress! > b.s!.targetProgress! ? a : b));
      return { index: best.i, reason: "target progress" };
    }
    const best = activeStats.reduce((a, b) => (a.s!.pctChange > b.s!.pctChange ? a : b));
    return { index: best.i, reason: "growth rate" };
  }, [stats]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card border-border/50 sm:max-w-[780px] max-w-[95vw] max-h-[90vh] overflow-y-auto animate-scale-in p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-lg sm:text-xl font-bold bg-gradient-to-r from-primary to-primary-accent bg-clip-text text-transparent flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Compare KPIs
          </DialogTitle>
        </DialogHeader>

        {/* Selectors — stack on mobile */}
        <div className="flex flex-col sm:flex-row sm:items-end gap-2 sm:gap-3">
          {selections.map((sel, i) => (
            <div key={i} className="flex-1 min-w-0">
              <Label className="text-xs text-muted-foreground">
                {i === 2 ? "KPI C (optional)" : `KPI ${String.fromCharCode(65 + i)}`}
              </Label>
              <Select value={sel} onValueChange={(v) => setKpi(i, v)}>
                <SelectTrigger className="h-9 text-sm">
                  <SelectValue placeholder="Select KPI" />
                </SelectTrigger>
                <SelectContent>
                  {allKPIs
                    .filter((k) => k.id === sel || !selectedIds.has(k.id))
                    .map((k) => (
                      <SelectItem key={k.id} value={k.id}>
                        {k.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          ))}

          <div className="flex gap-1 pb-0.5 self-end">
            <Button variant="ghost" size="icon" onClick={swap} title="Swap A & B" className="h-9 w-9">
              <ArrowLeftRight className="h-4 w-4" />
            </Button>
            {selections.length < 3 ? (
              <Button variant="ghost" size="sm" onClick={addThird} className="h-9 text-xs">
                +3rd
              </Button>
            ) : (
              <Button variant="ghost" size="sm" onClick={removeThird} className="h-9 text-xs text-destructive">
                ✕
              </Button>
            )}
          </div>
        </div>

        {activeCount >= 2 && merged.length >= 2 ? (
          <>
            {/* Chart */}
            <div className="h-48 sm:h-64 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={merged}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                  <XAxis dataKey="label" tick={{ fontSize: 9 }} stroke="hsl(var(--muted-foreground))" />
                  <YAxis yAxisId="left" tick={{ fontSize: 9 }} stroke="hsl(var(--muted-foreground))" width={35} />
                  {needsDualAxis && (
                    <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 9 }} stroke="hsl(var(--muted-foreground))" width={35} />
                  )}
                  <Tooltip
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      fontSize: "11px",
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: "11px" }} />

                  {thresholdLines.map((tl, i) => (
                    <ReferenceLine
                      key={i}
                      y={tl.value}
                      yAxisId={tl.yAxisId}
                      stroke={tl.color}
                      strokeDasharray="4 4"
                      strokeWidth={1}
                      label={{ value: tl.label, fontSize: 8, fill: tl.color }}
                    />
                  ))}

                  {(["a", "b", "c"] as const).slice(0, selections.length).map((key, i) =>
                    selections[i] ? (
                      <Area
                        key={`area-${key}`}
                        type="monotone"
                        dataKey={key}
                        name={names[i]}
                        yAxisId={needsDualAxis && i === 1 ? "right" : "left"}
                        stroke={COLORS[i]}
                        fill={FILL_COLORS[i]}
                        strokeWidth={2}
                        dot={{ r: 2 }}
                        connectNulls
                        activeDot={{ r: 4 }}
                      />
                    ) : null
                  )}
                </ComposedChart>
              </ResponsiveContainer>
            </div>

            {/* Stats cards — responsive grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3 mt-3">
              {selections.slice(0, activeCount).map((id, i) => {
                const s = stats[i];
                const kpi = kpiObjects[i];
                if (!s || !id) return null;
                const isWinner = winner?.index === i;
                return (
                  <div
                    key={id}
                    className={`rounded-lg border p-3 space-y-2 transition-all ${
                      isWinner ? "border-primary/50 bg-primary/5 ring-1 ring-primary/20" : "border-border/50 bg-muted/30"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold truncate" style={{ color: COLORS[i] }}>
                        {names[i]}
                      </p>
                      {isWinner && (
                        <Badge variant="default" className="text-[9px] px-1.5 py-0 h-4">
                          🏆 Best
                        </Badge>
                      )}
                    </div>

                    {/* Trend */}
                    <div className="flex items-center gap-2">
                      {s.pctChange >= 0 ? (
                        <TrendingUp className="h-3.5 w-3.5 text-chart-2" />
                      ) : (
                        <TrendingDown className="h-3.5 w-3.5 text-destructive" />
                      )}
                      <span className="text-sm font-bold text-foreground">
                        {s.pctChange >= 0 ? "+" : ""}{s.pctChange.toFixed(1)}%
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        ({s.first} → {s.last})
                      </span>
                    </div>

                    {/* Mini stats row */}
                    <div className="grid grid-cols-3 gap-1 text-center">
                      <div>
                        <p className="text-[9px] text-muted-foreground">Min</p>
                        <p className="text-xs font-medium text-foreground">{s.min}</p>
                      </div>
                      <div>
                        <p className="text-[9px] text-muted-foreground">Avg</p>
                        <p className="text-xs font-medium text-foreground">{s.avg.toFixed(1)}</p>
                      </div>
                      <div>
                        <p className="text-[9px] text-muted-foreground">Max</p>
                        <p className="text-xs font-medium text-foreground">{s.max}</p>
                      </div>
                    </div>

                    {/* Target progress bar */}
                    {s.targetProgress !== null && (
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="text-muted-foreground flex items-center gap-1">
                            <Target className="h-3 w-3" /> Target
                          </span>
                          <span className="font-medium text-foreground">
                            {s.targetProgress.toFixed(0)}% of {kpi?.target_value}
                          </span>
                        </div>
                        <Progress value={Math.min(s.targetProgress, 100)} className="h-1.5" />
                      </div>
                    )}

                    {/* Threshold warnings */}
                    {kpi?.warning_threshold != null && s.last >= kpi.warning_threshold && (
                      <Badge variant="outline" className="text-[9px] border-chart-4 text-chart-4">
                        <AlertTriangle className="h-2.5 w-2.5 mr-1" />
                        Above warning ({kpi.warning_threshold})
                      </Badge>
                    )}
                    {kpi?.critical_threshold != null && s.last >= kpi.critical_threshold && (
                      <Badge variant="outline" className="text-[9px] border-destructive text-destructive">
                        <AlertTriangle className="h-2.5 w-2.5 mr-1" />
                        Critical ({kpi.critical_threshold})
                      </Badge>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Correlation + Delta summary */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 mt-2">
              <Badge variant="secondary" className="text-xs">
                {correlation === "same"
                  ? "📈 Trending in same direction"
                  : correlation === "diverging"
                  ? "↔️ Diverging trends"
                  : "➖ Neutral correlation"}
              </Badge>
              {activeCount >= 2 && stats[0] && stats[1] && (
                <Badge variant="outline" className="text-xs">
                  <Minus className="h-3 w-3 mr-1" />
                  Delta: {Math.abs(stats[0].last - stats[1].last).toFixed(1)}
                </Badge>
              )}
            </div>
          </>
        ) : (
          <div className="text-center py-12 text-muted-foreground text-sm">
            <BarChart3 className="h-8 w-8 mx-auto mb-2 opacity-40" />
            Select at least two KPIs to compare their trends
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
