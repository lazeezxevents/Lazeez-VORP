import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageSquareText, Pin, X, Send } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface Annotation {
  id: string;
  kpi_id: string;
  note: string;
  created_by: string | null;
  created_at: string;
  is_pinned: boolean;
}

interface KPIAnnotationsProps {
  kpiId: string;
  isAdmin?: boolean;
}

export const KPIAnnotations = ({ kpiId, isAdmin }: KPIAnnotationsProps) => {
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [newNote, setNewNote] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchAnnotations = async () => {
    const { data } = await supabase
      .from("kpi_annotations")
      .select("*")
      .eq("kpi_id", kpiId)
      .eq("is_pinned", true)
      .order("created_at", { ascending: false })
      .limit(5);
    if (data) setAnnotations(data as Annotation[]);
  };

  useEffect(() => {
    fetchAnnotations();
  }, [kpiId]);

  const handleAdd = async () => {
    if (!newNote.trim()) return;
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase.from("kpi_annotations").insert({
        kpi_id: kpiId,
        note: newNote.trim(),
        created_by: user?.id || null,
      });
      if (error) throw error;
      setNewNote("");
      fetchAnnotations();
      toast.success("Note pinned");
    } catch (e: any) {
      toast.error(e.message || "Failed to add note");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await supabase.from("kpi_annotations").delete().eq("id", id);
      fetchAnnotations();
    } catch {
      toast.error("Failed to remove note");
    }
  };

  const pinnedCount = annotations.length;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          className="inline-flex items-center gap-1 text-xs mt-2 px-2 py-1 rounded-full bg-muted hover:bg-primary/10 transition-colors cursor-pointer"
          title="View pinned notes"
        >
          <MessageSquareText className="h-3 w-3 text-muted-foreground" />
          {pinnedCount > 0 && (
            <span className="font-semibold text-muted-foreground">{pinnedCount}</span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-3 space-y-2" align="start">
        <div className="flex items-center gap-2 mb-2">
          <Pin className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold">Pinned Notes</span>
        </div>

        {annotations.length === 0 && (
          <p className="text-xs text-muted-foreground">No notes yet.</p>
        )}

        <div className="space-y-2 max-h-40 overflow-y-auto">
          {annotations.map((a) => (
            <div key={a.id} className="flex items-start gap-2 text-xs bg-muted/50 rounded-md p-2">
              <div className="flex-1">
                <p className="text-foreground">{a.note}</p>
                <p className="text-muted-foreground mt-0.5">
                  {format(new Date(a.created_at), "MMM dd, HH:mm")}
                </p>
              </div>
              {isAdmin && (
                <button onClick={() => handleDelete(a.id)} className="text-muted-foreground hover:text-destructive mt-0.5">
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>
          ))}
        </div>

        {isAdmin && (
          <div className="flex gap-1.5 pt-1">
            <Input
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              placeholder="Add a note..."
              className="h-8 text-xs"
              onKeyDown={(e) => e.key === "Enter" && handleAdd()}
            />
            <Button size="icon" className="h-8 w-8 shrink-0" onClick={handleAdd} disabled={loading}>
              <Send className="h-3 w-3" />
            </Button>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
};
