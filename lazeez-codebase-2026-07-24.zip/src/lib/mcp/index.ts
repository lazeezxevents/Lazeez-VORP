import { auth, defineMcp } from "@lovable.dev/mcp-js";
import listKpis from "./tools/list-kpis";
import listVendorResponses from "./tools/list-vendor-responses";
import listCallLogs from "./tools/list-call-logs";
import dashboardSummary from "./tools/dashboard-summary";
import updateKpiValue from "./tools/update-kpi-value";

const projectRef = import.meta.env.VITE_SUPABASE_PROJECT_ID ?? "project-ref-unset";

export default defineMcp({
  name: "lazeez-sales-mcp",
  title: "Lazeez Events Sales MCP",
  version: "0.1.0",
  instructions:
    "Tools for the Lazeez Events sales KPI dashboard. Use `dashboard_summary` for a quick snapshot, `list_kpis` / `list_vendor_responses` / `list_call_logs` for detailed data, and `update_kpi_value` (admin) to change a KPI's current value.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [dashboardSummary, listKpis, listVendorResponses, listCallLogs, updateKpiValue],
});
