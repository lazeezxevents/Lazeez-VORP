// Ambient declaration so tool files (bundled into a Deno function at build time)
// type-check under the app's TS config without pulling in @types/node.
declare const process: { env: Record<string, string | undefined> };
