declare const process: { env: Record<string, string | undefined> };
import { createClient } from "@supabase/supabase-js";
import { defineTool, type ToolContext } from "@lovable.dev/mcp-js";
import { z } from "zod";

function supabaseForUser(ctx: ToolContext) {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    global: { headers: { Authorization: `Bearer ${ctx.getToken()}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export default defineTool({
  name: "list_kpis",
  title: "List KPIs",
  description: "List all Lazeez Events sales KPIs with current values, targets, thresholds, and period info. Optionally filter by category or archived state.",
  inputSchema: {
    category: z.string().optional().describe("Optional category filter (e.g. Vendors, Sales)."),
    include_archived: z.boolean().optional().describe("Include archived KPIs. Defaults to false."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ category, include_archived }, ctx) => {
    if (!ctx.isAuthenticated()) return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    let q = supabaseForUser(ctx).from("custom_kpis").select("*").order("sort_order", { ascending: true });
    if (!include_archived) q = q.eq("is_archived", false);
    if (category) q = q.eq("category", category);
    const { data, error } = await q;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { kpis: data ?? [] },
    };
  },
});
