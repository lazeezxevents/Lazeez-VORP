declare const process: { env: Record<string, string | undefined> };
import { createClient } from "@supabase/supabase-js";
import { defineTool, type ToolContext } from "@lovable.dev/mcp-js";
import { z } from "zod";

function supabaseForUser(ctx: ToolContext) {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    global: { headers: { Authorization: `Bearer ${ctx.getToken()}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export default defineTool({
  name: "list_vendor_responses",
  title: "List vendor responses",
  description: "List vendor inquiry response records, optionally within a date range. Dates are ISO YYYY-MM-DD.",
  inputSchema: {
    from: z.string().optional().describe("Start date (YYYY-MM-DD) inclusive."),
    to: z.string().optional().describe("End date (YYYY-MM-DD) inclusive."),
    limit: z.number().int().min(1).max(500).optional().describe("Row limit (default 100)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ from, to, limit }, ctx) => {
    if (!ctx.isAuthenticated()) return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    let q = supabaseForUser(ctx)
      .from("vendor_responses")
      .select("*")
      .order("date", { ascending: false })
      .limit(limit ?? 100);
    if (from) q = q.gte("date", from);
    if (to) q = q.lte("date", to);
    const { data, error } = await q;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { responses: data ?? [] },
    };
  },
});
