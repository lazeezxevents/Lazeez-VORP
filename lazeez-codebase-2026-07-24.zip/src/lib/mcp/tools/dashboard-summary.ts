declare const process: { env: Record<string, string | undefined> };
import { createClient } from "@supabase/supabase-js";
import { defineTool, type ToolContext } from "@lovable.dev/mcp-js";

function supabaseForUser(ctx: ToolContext) {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    global: { headers: { Authorization: `Bearer ${ctx.getToken()}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export default defineTool({
  name: "dashboard_summary",
  title: "Dashboard summary",
  description: "Return a high-level snapshot of the Lazeez sales dashboard: KPI counts, totals for the last 7 days of calls and inquiries, and today's activity.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async (_input, ctx) => {
    if (!ctx.isAuthenticated()) return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    const sb = supabaseForUser(ctx);
    const today = new Date().toISOString().slice(0, 10);
    const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);

    const [kpis, calls, resp] = await Promise.all([
      sb.from("custom_kpis").select("name,value,target_value,category,is_archived"),
      sb.from("call_logs").select("*").gte("date", weekAgo),
      sb.from("vendor_responses").select("*").gte("date", weekAgo),
    ]);

    const sum = (arr: any[] | null, k: string) => (arr ?? []).reduce((s, r) => s + (r[k] || 0), 0);
    const summary = {
      generated_at: new Date().toISOString(),
      kpis: {
        total: kpis.data?.length ?? 0,
        active: kpis.data?.filter((k) => !k.is_archived).length ?? 0,
        list: kpis.data ?? [],
      },
      last_7_days: {
        calls_made: sum(calls.data, "calls_made"),
        calls_answered: sum(calls.data, "calls_answered"),
        inquiries_received: sum(resp.data, "inquiries_received") + sum(resp.data, "inquiries_received_weekend"),
        inquiries_responded: sum(resp.data, "inquiries_responded") + sum(resp.data, "inquiries_responded_weekend"),
      },
      today: {
        calls: calls.data?.filter((c) => c.date === today) ?? [],
        responses: resp.data?.filter((r) => r.date === today) ?? [],
      },
    };
    return {
      content: [{ type: "text", text: JSON.stringify(summary) }],
      structuredContent: summary,
    };
  },
});
