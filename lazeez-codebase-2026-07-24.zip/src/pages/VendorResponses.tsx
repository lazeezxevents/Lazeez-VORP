import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Save, Archive, Calendar, TrendingUp, MessageSquare, CheckCircle, CalendarDays, Pencil, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useVisitorTracking } from "@/hooks/useVisitorTracking";
import { useAdvancedTracking } from "@/hooks/useAdvancedTracking";
import { ThemeToggle } from "@/components/ThemeToggle";
import { EditVendorResponseDialog } from "@/components/EditVendorResponseDialog";

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Legend, CartesianGrid, BarChart, Bar } from "recharts";

interface VendorResponse {
  id: string;
  date: string;
  inquiries_received: number;
  inquiries_responded: number;
  inquiries_received_weekend: number;
  inquiries_responded_weekend: number;
  is_weekend: boolean;
  is_archived: boolean;
}

export default function VendorResponses() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [todayEntry, setTodayEntry] = useState<VendorResponse | null>(null);
  const [archivedEntries, setArchivedEntries] = useState<VendorResponse[]>([]);
  const [inquiriesReceived, setInquiriesReceived] = useState(0);
  const [inquiriesResponded, setInquiriesResponded] = useState(0);
  const [weekendReceived, setWeekendReceived] = useState(0);
  const [weekendResponded, setWeekendResponded] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Edit dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<VendorResponse | null>(null);
  

  // Track visitor
  useVisitorTracking('Vendor Responses');
  useAdvancedTracking('Vendor Responses');

  // Detect if today is a weekend
  const today = new Date();
  const dayOfWeek = today.getDay();
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;


  useEffect(() => {
    fetchData();
    checkAdminStatus();
  }, [user]);

  const checkAdminStatus = async () => {
    if (!user) {
      setIsAdmin(false);
      return;
    }
    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .maybeSingle();
    setIsAdmin(data?.role === 'admin');
  };

  const fetchData = async () => {
    setLoading(true);
    const todayDate = new Date().toISOString().split('T')[0];

    const { data: todayData } = await supabase
      .from('vendor_responses')
      .select('*')
      .eq('date', todayDate)
      .maybeSingle();

    if (todayData) {
      setTodayEntry(todayData as VendorResponse);
      setInquiriesReceived(todayData.inquiries_received);
      setInquiriesResponded(todayData.inquiries_responded);
      setWeekendReceived(todayData.inquiries_received_weekend);
      setWeekendResponded(todayData.inquiries_responded_weekend);
    } else {
      const { data: newEntry, error } = await supabase
        .from('vendor_responses')
        .insert({ 
          date: todayDate, 
          inquiries_received: 0, 
          inquiries_responded: 0,
          inquiries_received_weekend: 0,
          inquiries_responded_weekend: 0,
          is_weekend: isWeekend
        })
        .select()
        .single();
      
      if (!error && newEntry) {
        setTodayEntry(newEntry as VendorResponse);
        setInquiriesReceived(0);
        setInquiriesResponded(0);
        setWeekendReceived(0);
        setWeekendResponded(0);
      }
    }

    // Fetch all past entries (excluding today) for history
    const { data: archived } = await supabase
      .from('vendor_responses')
      .select('*')
      .neq('date', todayDate)
      .order('date', { ascending: false });

    setArchivedEntries((archived || []) as VendorResponse[]);
    setLoading(false);
  };

  const handleSave = async () => {
    if (!todayEntry) return;

    const { error } = await supabase
      .from('vendor_responses')
      .update({
        inquiries_received: inquiriesReceived,
        inquiries_responded: inquiriesResponded,
        inquiries_received_weekend: weekendReceived,
        inquiries_responded_weekend: weekendResponded,
        is_weekend: isWeekend
      })
      .eq('id', todayEntry.id);

    if (error) {
      toast.error("Failed to save");
    } else {
      toast.success("Saved successfully");
      fetchData();
    }
  };

  // Calculate weekday aggregates
  const calculateWeekdayAggregates = (entries: VendorResponse[], months: number) => {
    const cutoffDate = new Date();
    cutoffDate.setMonth(cutoffDate.getMonth() - months);
    
    const filtered = entries.filter(e => new Date(e.date) >= cutoffDate);
    const received = filtered.reduce((sum, e) => sum + e.inquiries_received, 0);
    const responded = filtered.reduce((sum, e) => sum + e.inquiries_responded, 0);
    return { received, responded, rate: received > 0 ? ((responded / received) * 100).toFixed(1) : '0' };
  };

  // Calculate weekend aggregates
  const calculateWeekendAggregates = (entries: VendorResponse[], months: number) => {
    const cutoffDate = new Date();
    cutoffDate.setMonth(cutoffDate.getMonth() - months);
    
    const filtered = entries.filter(e => new Date(e.date) >= cutoffDate);
    const received = filtered.reduce((sum, e) => sum + e.inquiries_received_weekend, 0);
    const responded = filtered.reduce((sum, e) => sum + e.inquiries_responded_weekend, 0);
    return { received, responded, rate: received > 0 ? ((responded / received) * 100).toFixed(1) : '0' };
  };

  // Create a current entry that reflects the live input values, not just saved DB values
  const currentTodayEntry = todayEntry ? {
    ...todayEntry,
    inquiries_received: inquiriesReceived,
    inquiries_responded: inquiriesResponded,
    inquiries_received_weekend: weekendReceived,
    inquiries_responded_weekend: weekendResponded,
  } : null;
  
  const allEntries = [...archivedEntries, ...(currentTodayEntry ? [currentTodayEntry] : [])];
  
  // Weekday stats
  const monthlyStats = calculateWeekdayAggregates(allEntries, 1);
  const quarterlyStats = calculateWeekdayAggregates(allEntries, 3);
  const yearlyStats = calculateWeekdayAggregates(allEntries, 12);

  // Weekend stats
  const monthlyWeekendStats = calculateWeekendAggregates(allEntries, 1);
  const quarterlyWeekendStats = calculateWeekendAggregates(allEntries, 3);
  const yearlyWeekendStats = calculateWeekendAggregates(allEntries, 12);

  // Current day response rates
  const weekdayRate = inquiriesReceived > 0 
    ? ((inquiriesResponded / inquiriesReceived) * 100).toFixed(1) 
    : '0';
  const weekendRate = weekendReceived > 0 
    ? ((weekendResponded / weekendReceived) * 100).toFixed(1) 
    : '0';

  // Prepare chart data - group by week for trend visualization
  const getChartData = () => {
    const sortedEntries = [...allEntries].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    // Group entries by week
    const weeklyData: Record<string, { 
      weekdayReceived: number, 
      weekdayResponded: number, 
      weekendReceived: number, 
      weekendResponded: number 
    }> = {};
    
    sortedEntries.forEach(entry => {
      const date = new Date(entry.date);
      const weekStart = new Date(date);
      weekStart.setDate(date.getDate() - date.getDay());
      const weekKey = weekStart.toISOString().split('T')[0];
      
      if (!weeklyData[weekKey]) {
        weeklyData[weekKey] = { weekdayReceived: 0, weekdayResponded: 0, weekendReceived: 0, weekendResponded: 0 };
      }
      
      weeklyData[weekKey].weekdayReceived += entry.inquiries_received;
      weeklyData[weekKey].weekdayResponded += entry.inquiries_responded;
      weeklyData[weekKey].weekendReceived += entry.inquiries_received_weekend;
      weeklyData[weekKey].weekendResponded += entry.inquiries_responded_weekend;
    });

    return Object.entries(weeklyData)
      .map(([week, data]) => ({
        week: new Date(week).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        weekdayReceived: data.weekdayReceived,
        weekdayResponded: data.weekdayResponded,
        weekendReceived: data.weekendReceived,
        weekendResponded: data.weekendResponded,
      }))
      .slice(-12); // Last 12 weeks
  };

  const chartData = getChartData();

  // Monthly bar chart data
  const getMonthlyBarData = () => {
    const monthlyData: Record<string, { 
      weekdayReceived: number, 
      weekdayResponded: number, 
      weekendReceived: number, 
      weekendResponded: number 
    }> = {};
    
    allEntries.forEach(entry => {
      const date = new Date(entry.date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = { weekdayReceived: 0, weekdayResponded: 0, weekendReceived: 0, weekendResponded: 0 };
      }
      
      monthlyData[monthKey].weekdayReceived += entry.inquiries_received;
      monthlyData[monthKey].weekdayResponded += entry.inquiries_responded;
      monthlyData[monthKey].weekendReceived += entry.inquiries_received_weekend;
      monthlyData[monthKey].weekendResponded += entry.inquiries_responded_weekend;
    });

    return Object.entries(monthlyData)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, data]) => ({
        month: new Date(month + '-01').toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        ...data
      }))
      .slice(-6); // Last 6 months
  };

  const monthlyBarData = getMonthlyBarData();

  const chartConfig = {
    weekdayReceived: {
      label: "Weekday Received",
      color: "hsl(var(--primary))",
    },
    weekdayResponded: {
      label: "Weekday Responded",
      color: "hsl(var(--chart-2))",
    },
    weekendReceived: {
      label: "Weekend Received",
      color: "hsl(var(--primary-accent))",
    },
    weekendResponded: {
      label: "Weekend Responded",
      color: "hsl(var(--chart-4))",
    },
  };

  // CSV Export function
  const exportToCSV = () => {
    const allData = [...archivedEntries, ...(todayEntry ? [todayEntry] : [])];
    
    if (allData.length === 0) {
      toast.error("No data to export");
      return;
    }

    const headers = ["Date", "Weekday Received", "Weekday Responded", "Weekday Rate (%)", "Weekend Received", "Weekend Responded", "Weekend Rate (%)", "Is Weekend"];
    const rows = allData
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .map(entry => {
        const weekdayRate = entry.inquiries_received > 0 
          ? ((entry.inquiries_responded / entry.inquiries_received) * 100).toFixed(1) 
          : "0";
        const weekendRate = entry.inquiries_received_weekend > 0 
          ? ((entry.inquiries_responded_weekend / entry.inquiries_received_weekend) * 100).toFixed(1) 
          : "0";
        
        return [
          entry.date,
          entry.inquiries_received,
          entry.inquiries_responded,
          weekdayRate,
          entry.inquiries_received_weekend,
          entry.inquiries_responded_weekend,
          weekendRate,
          entry.is_weekend ? "Yes" : "No"
        ].join(",");
      });

    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vendor-responses-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV exported successfully");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary-accent bg-clip-text text-transparent">
                Vendor Response Analytics
              </h1>
              <p className="text-muted-foreground">Track daily inquiries and response rates</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={exportToCSV} className="gap-2">
              <Download className="h-4 w-4" />
              Export CSV
            </Button>
            <ThemeToggle />
          </div>
        </div>

        {/* Today's Entry */}
        <Card className="glass-card glass-hover border-border/50 mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                <CardTitle>Today's Entry</CardTitle>
                {isWeekend && (
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-primary/20 text-primary">
                    Weekend
                  </span>
                )}
              </div>
            </div>
            <CardDescription>
              {today.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Weekday Input */}
            {!isWeekend && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-2">
                  <CalendarDays className="h-4 w-4" /> Weekday Inquiries
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label>Inquiries Received</Label>
                    <Input
                      type="number"
                      value={inquiriesReceived}
                      onChange={(e) => setInquiriesReceived(parseInt(e.target.value) || 0)}
                      disabled={!isAdmin}
                      className="text-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Inquiries Responded</Label>
                    <Input
                      type="number"
                      value={inquiriesResponded}
                      onChange={(e) => setInquiriesResponded(parseInt(e.target.value) || 0)}
                      disabled={!isAdmin}
                      className="text-lg"
                    />
                  </div>
                  <div className="flex flex-col justify-end">
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <div className="text-3xl font-bold text-primary">{weekdayRate}%</div>
                      <div className="text-xs text-muted-foreground">Response Rate</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Weekend Input */}
            {isWeekend && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-2">
                  <CalendarDays className="h-4 w-4" /> Weekend Inquiries (Saturday & Sunday)
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label>Inquiries Received</Label>
                    <Input
                      type="number"
                      value={weekendReceived}
                      onChange={(e) => setWeekendReceived(parseInt(e.target.value) || 0)}
                      disabled={!isAdmin}
                      className="text-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Inquiries Responded</Label>
                    <Input
                      type="number"
                      value={weekendResponded}
                      onChange={(e) => setWeekendResponded(parseInt(e.target.value) || 0)}
                      disabled={!isAdmin}
                      className="text-lg"
                    />
                  </div>
                  <div className="flex flex-col justify-end">
                    <div className="text-center p-4 bg-primary/10 rounded-lg border border-primary/20">
                      <div className="text-3xl font-bold text-primary">{weekendRate}%</div>
                      <div className="text-xs text-muted-foreground">Weekend Rate</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {isAdmin && (
              <Button onClick={handleSave} className="mt-2 w-full md:w-auto">
                <Save className="h-4 w-4 mr-2" />
                Save Today's Data
              </Button>
            )}
            <p className="text-xs text-muted-foreground mt-4">
              Auto-resets daily at 11:59 PM
            </p>
          </CardContent>
        </Card>

        {/* Comparison Chart */}
        <Card className="glass-card glass-hover border-border/50 mb-8">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <CardTitle>Weekday vs Weekend Inquiries</CardTitle>
            </div>
            <CardDescription>Weekly comparison of received and responded inquiries</CardDescription>
          </CardHeader>
          <CardContent>
            {chartData.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No data available yet</p>
            ) : (
              <ChartContainer config={chartConfig} className="h-[350px] w-full">
                <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis 
                    dataKey="week" 
                    className="text-xs fill-muted-foreground"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    className="text-xs fill-muted-foreground"
                    tick={{ fontSize: 12 }}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="weekdayReceived" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--primary))", strokeWidth: 2 }}
                    name="Weekday Received"
                    connectNulls
                  />
                  <Line 
                    type="monotone" 
                    dataKey="weekdayResponded" 
                    stroke="hsl(var(--chart-2))" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 2 }}
                    name="Weekday Responded"
                    connectNulls
                  />
                  <Line 
                    type="monotone" 
                    dataKey="weekendReceived" 
                    stroke="hsl(var(--primary-accent))" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: "hsl(var(--primary-accent))", strokeWidth: 2 }}
                    name="Weekend Received"
                    connectNulls
                  />
                  <Line 
                    type="monotone" 
                    dataKey="weekendResponded" 
                    stroke="hsl(var(--chart-4))" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: "hsl(var(--chart-4))", strokeWidth: 2 }}
                    name="Weekend Responded"
                    connectNulls
                  />
                </LineChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        {/* Monthly Bar Chart */}
        <Card className="glass-card glass-hover border-border/50 mb-8">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <CardTitle>Monthly Totals: Weekday vs Weekend</CardTitle>
            </div>
            <CardDescription>Comparison of monthly inquiry totals</CardDescription>
          </CardHeader>
          <CardContent>
            {monthlyBarData.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No data available yet</p>
            ) : (
              <ChartContainer config={chartConfig} className="h-[350px] w-full">
                <BarChart data={monthlyBarData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis 
                    dataKey="month" 
                    className="text-xs fill-muted-foreground"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    className="text-xs fill-muted-foreground"
                    tick={{ fontSize: 12 }}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Bar dataKey="weekdayReceived" fill="hsl(var(--primary))" name="Weekday Received" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="weekdayResponded" fill="hsl(var(--chart-2))" name="Weekday Responded" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="weekendReceived" fill="hsl(var(--primary-accent))" name="Weekend Received" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="weekendResponded" fill="hsl(var(--chart-4))" name="Weekend Responded" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <CalendarDays className="h-5 w-5 text-muted-foreground" />
          Weekday Statistics (Mon-Fri)
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Monthly */}
          <Card className="glass-card glass-hover border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Monthly
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" /> Received
                  </span>
                  <span className="text-2xl font-bold">{monthlyStats.received}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" /> Responded
                  </span>
                  <span className="text-2xl font-bold">{monthlyStats.responded}</span>
                </div>
                <div className="pt-2 border-t border-border">
                  <div className="text-center">
                    <span className="text-3xl font-bold text-primary">{monthlyStats.rate}%</span>
                    <p className="text-xs text-muted-foreground">Response Rate</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quarterly */}
          <Card className="glass-card glass-hover border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Quarterly
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" /> Received
                  </span>
                  <span className="text-2xl font-bold">{quarterlyStats.received}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" /> Responded
                  </span>
                  <span className="text-2xl font-bold">{quarterlyStats.responded}</span>
                </div>
                <div className="pt-2 border-t border-border">
                  <div className="text-center">
                    <span className="text-3xl font-bold text-primary">{quarterlyStats.rate}%</span>
                    <p className="text-xs text-muted-foreground">Response Rate</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Yearly */}
          <Card className="glass-card glass-hover border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Yearly
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" /> Received
                  </span>
                  <span className="text-2xl font-bold">{yearlyStats.received}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" /> Responded
                  </span>
                  <span className="text-2xl font-bold">{yearlyStats.responded}</span>
                </div>
                <div className="pt-2 border-t border-border">
                  <div className="text-center">
                    <span className="text-3xl font-bold text-primary">{yearlyStats.rate}%</span>
                    <p className="text-xs text-muted-foreground">Response Rate</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Weekend KPI Summary Cards */}
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <CalendarDays className="h-5 w-5 text-primary" />
          Weekend Statistics (Sat-Sun)
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Monthly Weekend */}
          <Card className="glass-card glass-hover border-primary/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Monthly Weekends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" /> Received
                  </span>
                  <span className="text-2xl font-bold">{monthlyWeekendStats.received}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" /> Responded
                  </span>
                  <span className="text-2xl font-bold">{monthlyWeekendStats.responded}</span>
                </div>
                <div className="pt-2 border-t border-primary/20">
                  <div className="text-center">
                    <span className="text-3xl font-bold text-primary">{monthlyWeekendStats.rate}%</span>
                    <p className="text-xs text-muted-foreground">Response Rate</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quarterly Weekend */}
          <Card className="glass-card glass-hover border-primary/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Quarterly Weekends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" /> Received
                  </span>
                  <span className="text-2xl font-bold">{quarterlyWeekendStats.received}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" /> Responded
                  </span>
                  <span className="text-2xl font-bold">{quarterlyWeekendStats.responded}</span>
                </div>
                <div className="pt-2 border-t border-primary/20">
                  <div className="text-center">
                    <span className="text-3xl font-bold text-primary">{quarterlyWeekendStats.rate}%</span>
                    <p className="text-xs text-muted-foreground">Response Rate</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Yearly Weekend */}
          <Card className="glass-card glass-hover border-primary/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Yearly Weekends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" /> Received
                  </span>
                  <span className="text-2xl font-bold">{yearlyWeekendStats.received}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" /> Responded
                  </span>
                  <span className="text-2xl font-bold">{yearlyWeekendStats.responded}</span>
                </div>
                <div className="pt-2 border-t border-primary/20">
                  <div className="text-center">
                    <span className="text-3xl font-bold text-primary">{yearlyWeekendStats.rate}%</span>
                    <p className="text-xs text-muted-foreground">Response Rate</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Archived History */}
        <Card className="glass-card glass-hover border-border/50">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Archive className="h-5 w-5 text-primary" />
              <CardTitle>Archived History</CardTitle>
            </div>
            <CardDescription>Past daily records</CardDescription>
          </CardHeader>
          <CardContent>
            {archivedEntries.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No archived entries yet</p>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {archivedEntries.map((entry) => {
                  const entryDate = new Date(entry.date);
                  const entryDay = entryDate.getDay();
                  const entryIsWeekend = entryDay === 0 || entryDay === 6;
                  
                  return (
                    <div 
                      key={entry.id} 
                      className="flex flex-col md:flex-row md:items-center justify-between p-3 bg-muted/50 rounded-lg gap-2"
                    >
                      <div className="flex items-center gap-4">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">
                          {entryDate.toLocaleDateString('en-US', { 
                            weekday: 'short', 
                            month: 'short', 
                            day: 'numeric',
                            year: 'numeric'
                          })}
                        </span>
                        {entryIsWeekend && (
                          <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-primary/20 text-primary">
                            Weekend
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-4 text-sm">
                        {!entryIsWeekend && (
                          <>
                            <span>
                              <span className="text-muted-foreground">Received:</span>{' '}
                              <span className="font-bold">{entry.inquiries_received}</span>
                            </span>
                            <span>
                              <span className="text-muted-foreground">Responded:</span>{' '}
                              <span className="font-bold">{entry.inquiries_responded}</span>
                            </span>
                            <span className="text-primary font-bold">
                              {entry.inquiries_received > 0 
                                ? ((entry.inquiries_responded / entry.inquiries_received) * 100).toFixed(0)
                                : 0}%
                            </span>
                          </>
                        )}
                        {entryIsWeekend && (
                          <>
                            <span>
                              <span className="text-muted-foreground">Weekend Received:</span>{' '}
                              <span className="font-bold">{entry.inquiries_received_weekend}</span>
                            </span>
                            <span>
                              <span className="text-muted-foreground">Weekend Responded:</span>{' '}
                              <span className="font-bold">{entry.inquiries_responded_weekend}</span>
                            </span>
                            <span className="text-primary font-bold">
                              {entry.inquiries_received_weekend > 0 
                                ? ((entry.inquiries_responded_weekend / entry.inquiries_received_weekend) * 100).toFixed(0)
                                : 0}%
                            </span>
                          </>
                        )}
                        {isAdmin && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setEditingEntry(entry);
                              setEditDialogOpen(true);
                            }}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Edit Dialog */}
      <EditVendorResponseDialog
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        entry={editingEntry}
        onSave={fetchData}
      />
    </div>
  );
}
