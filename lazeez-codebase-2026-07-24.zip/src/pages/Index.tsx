import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardHeader } from "@/components/DashboardHeader";
import { TodayAtAGlance } from "@/components/TodayAtAGlance";
import { KPICard } from "@/components/KPICard";
import { SortableKPIGrid } from "@/components/SortableKPIGrid";
import { SalesCycleChart } from "@/components/SalesCycleChart";
import { PDFExportButton } from "@/components/PDFExportButton";
import { VendorResponseCard } from "@/components/VendorResponseCard";
import { VendorCallsCard } from "@/components/VendorCallsCard";
import { CallQualityScorecard } from "@/components/CallQualityScorecard";
import { LeadConversionFunnel } from "@/components/LeadConversionFunnel";
import { BreakPhaseBanner } from "@/components/BreakPhaseBanner";
import { AuthDialog } from "@/components/AuthDialog";
import { CreateKPIDialog } from "@/components/CreateKPIDialog";
import { EditKPIDialog } from "@/components/EditKPIDialog";
import { SplashScreen } from "@/components/SplashScreen";
import { ArchiveDialog } from "@/components/ArchiveDialog";
import { KPIComparisonDialog } from "@/components/KPIComparisonDialog";
import { DashboardBookmarks } from "@/components/DashboardBookmarks";
import { useAuth } from "@/hooks/useAuth";
import { useVisitorTracking } from "@/hooks/useVisitorTracking";
import { useAdvancedTracking } from "@/hooks/useAdvancedTracking";
import { supabase } from "@/integrations/supabase/client";
import { addDays, addMonths, format, isAfter, startOfDay } from "date-fns";
import { Users, UserPlus, UserMinus, Activity, TrendingUp, Calendar, Plus, Phone, PhoneCall, Clock, MessageSquare, Percent, BarChart3 } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface CallLog {
  id: string;
  date: string;
  calls_made: number;
  calls_answered: number;
  total_duration_minutes: number;
  is_weekend: boolean;
}

interface VendorResponse {
  id: string;
  date: string;
  inquiries_received: number;
  inquiries_responded: number;
  inquiries_received_weekend: number;
  inquiries_responded_weekend: number;
  is_weekend: boolean;
}

const Index = () => {
  const [showSplash, setShowSplash] = useState(() => {
    const seen = sessionStorage.getItem("splashShown");
    return !seen;
  });
  const { user, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();
  const [authOpen, setAuthOpen] = useState(false);
  const [createKPIOpen, setCreateKPIOpen] = useState(false);
  const [editKPIOpen, setEditKPIOpen] = useState(false);
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [comparisonOpen, setComparisonOpen] = useState(false);
  const [selectedKPI, setSelectedKPI] = useState<any>(null);
  const [deleteKPIId, setDeleteKPIId] = useState<string | null>(null);
  const [allKPIs, setAllKPIs] = useState<any[]>([]);
  const [archivedKPIs, setArchivedKPIs] = useState<any[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | undefined>(undefined);
  const [newKPICategory, setNewKPICategory] = useState<string | null>(null);
  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [vendorResponses, setVendorResponses] = useState<VendorResponse[]>([]);
  const [bookmarkFilters, setBookmarkFilters] = useState<{ category?: string; dateFrom?: string; dateTo?: string }>({});

  // Track visitor
  useVisitorTracking('Main Dashboard');
  useAdvancedTracking('Main Dashboard');


  useEffect(() => {
    const init = async () => {
      await fetchCustomKPIs();
      await fetchArchivedKPIs();
      fetchCallLogs();
      fetchVendorResponses();
    };
    init().then(() => {
      // Run auto-sync after data is loaded
      checkAndAutoArchiveExpiredPeriods();
    });
  }, []);

  const fetchCallLogs = async () => {
    const { data } = await supabase
      .from('call_logs')
      .select('*')
      .order('date', { ascending: true });
    if (data) setCallLogs(data);
  };

  const fetchVendorResponses = async () => {
    const { data } = await supabase
      .from('vendor_responses')
      .select('*')
      .order('date', { ascending: true });
    if (data) setVendorResponses(data);
  };

  const fetchCustomKPIs = async () => {
    const { data } = await supabase
      .from('custom_kpis')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) {
      // All KPIs show on dashboard (archived ones have value 0)
      setAllKPIs(data);
      // Update the last updated timestamp
      if (data.length > 0) {
        const latest = data.reduce((prev: any, current: any) => 
          new Date(current.updated_at) > new Date(prev.updated_at) ? current : prev
        );
        setLastUpdated(new Date(latest.updated_at));
      } else {
        setLastUpdated(undefined);
      }
    }
  };

  const fetchArchivedKPIs = async () => {
    const { data } = await supabase
      .from('kpi_archive_history')
      .select('*')
      .order('archived_at', { ascending: false });
    if (data) {
      setArchivedKPIs(data);
    }
  };

  const handleArchive = async (kpi: any) => {
    try {
      // First, add to archive history (stacked - old archives remain)
      const { error: historyError } = await supabase
        .from('kpi_archive_history')
        .insert({
          kpi_id: kpi.id,
          kpi_name: kpi.name,
          category: kpi.category,
          description: kpi.description,
          value_at_archive: kpi.value || 0,
          period_label: kpi.period_label,
          period_start_date: kpi.period_start_date,
          period_end_date: kpi.period_end_date
        });

      if (historyError) throw historyError;

      // Then update the KPI to reset its value
      const { error } = await supabase
        .from('custom_kpis')
        .update({
          is_archived: true,
          archived_at: new Date().toISOString(),
          value_before_archive: kpi.value,
          value: 0
        })
        .eq('id', kpi.id);

      if (error) throw error;
      toast.success("KPI archived successfully");
      fetchCustomKPIs();
      fetchArchivedKPIs();
    } catch (error: any) {
      toast.error(error.message || "Failed to archive KPI");
    }
  };

  const handleDeleteArchiveRecord = async (archiveId: string) => {
    try {
      const { error } = await supabase
        .from('kpi_archive_history')
        .delete()
        .eq('id', archiveId);

      if (error) throw error;
      toast.success("Archive record deleted");
      fetchArchivedKPIs();
    } catch (error: any) {
      toast.error(error.message || "Failed to delete archive record");
    }
  };

  const handleRestore = async (archiveRecord: any) => {
    try {
      // Find the original KPI and restore its value
      const kpi = allKPIs.find(k => k.id === archiveRecord.kpi_id);
      if (kpi) {
        const { error } = await supabase
          .from('custom_kpis')
          .update({
            is_archived: false,
            archived_at: null,
            value: archiveRecord.value_at_archive || 0,
            value_before_archive: null,
            updated_at: new Date().toISOString()
          })
          .eq('id', archiveRecord.kpi_id);

        if (error) throw error;
      }
      
      // Delete the archive history record
      await supabase
        .from('kpi_archive_history')
        .delete()
        .eq('id', archiveRecord.id);

      toast.success("KPI restored successfully");
      fetchCustomKPIs();
      fetchArchivedKPIs();
    } catch (error: any) {
      toast.error(error.message || "Failed to restore KPI");
    }
  };

  // Handle archive and reset for time-based KPIs
  const handleArchiveAndReset = async (kpi: any, newPeriodLabel: string) => {
    try {
      // First, add to archive history
      const { error: historyError } = await supabase
        .from('kpi_archive_history')
        .insert({
          kpi_id: kpi.id,
          kpi_name: kpi.name,
          category: kpi.category,
          description: kpi.description,
          value_at_archive: kpi.value || 0,
          
          period_label: kpi.period_label,
          period_start_date: kpi.period_start_date,
          period_end_date: kpi.period_end_date
        });

      if (historyError) throw historyError;

      // Reset the KPI with new period
      const { error } = await supabase
        .from('custom_kpis')
        .update({
          value: 0,
          period_label: newPeriodLabel,
          is_archived: false,
          archived_at: null,
          value_before_archive: kpi.value,
          updated_at: new Date().toISOString()
        })
        .eq('id', kpi.id);

      if (error) throw error;

      toast.success(`Period reset! Old value (${kpi.value}) archived, starting fresh with "${newPeriodLabel}"`);
      fetchCustomKPIs();
      fetchArchivedKPIs();
    } catch (error: any) {
      throw error;
    }
  };

  // Auto-check and archive expired time-based KPIs
  const checkAndAutoArchiveExpiredPeriods = async () => {
    try {
      const { data: kpis } = await supabase
        .from('custom_kpis')
        .select('*')
        .in('name', ['Last 2 Weeks', 'Last 2 Months', 'Last Quarter']);

      if (!kpis || kpis.length === 0) return;

      const today = startOfDay(new Date());

      for (const kpi of kpis) {
        if (!kpi.period_end_date) continue;

        const endDate = startOfDay(new Date(kpi.period_end_date));

        // If today is after the period end date, auto-archive and renew
        if (isAfter(today, endDate)) {
          // Calculate new period dates based on KPI type
          const oldStart = kpi.period_start_date ? new Date(kpi.period_start_date) : new Date();
          let newStart: Date;
          let newEnd: Date;

          if (kpi.name === 'Last 2 Weeks') {
            newStart = addDays(endDate, 1);
            newEnd = addDays(newStart, 13);
          } else if (kpi.name === 'Last 2 Months') {
            newStart = addDays(endDate, 1);
            newEnd = addDays(addMonths(newStart, 2), -1);
          } else if (kpi.name === 'Last Quarter') {
            newStart = addDays(endDate, 1);
            newEnd = addDays(addMonths(newStart, 3), -1);
          } else {
            continue;
          }

          const newPeriodLabel = `${format(newStart, "MMM dd").toUpperCase()} - ${format(newEnd, "MMM dd").toUpperCase()}`;

          // Archive current value to history
          await supabase
            .from('kpi_archive_history')
            .insert({
              kpi_id: kpi.id,
              kpi_name: kpi.name,
              category: kpi.category,
              description: kpi.description,
              value_at_archive: kpi.value || 0,
              period_label: kpi.period_label,
              period_start_date: kpi.period_start_date,
              period_end_date: kpi.period_end_date,
            });

          // Reset KPI with new period
          await supabase
            .from('custom_kpis')
            .update({
              value: 0,
              period_label: newPeriodLabel,
              period_start_date: format(newStart, 'yyyy-MM-dd'),
              period_end_date: format(newEnd, 'yyyy-MM-dd'),
              value_before_archive: kpi.value,
              is_archived: false,
              archived_at: null,
              updated_at: new Date().toISOString(),
            })
            .eq('id', kpi.id);

          console.log(`Auto-archived "${kpi.name}" (${kpi.period_label}), new period: ${newPeriodLabel}`);
        }
      }

      // Refresh data after auto-archive
      fetchCustomKPIs();
      fetchArchivedKPIs();
    } catch (error) {
      console.error('Auto-archive check failed:', error);
    }
  };

  // Get icon for KPI based on name
  const getKPIIcon = (name: string) => {
    const iconMap: Record<string, any> = {
      'Total Vendors Onboarded': Users,
      'Last 2 Weeks': UserPlus,
      'Last 2 Months': Calendar,
      'Last Quarter': TrendingUp,
      'Active Vendors': Activity,
      'Left Vendors': UserMinus,
      'Terminated Vendors': UserMinus,
    };
    return iconMap[name] || Activity;
  };

  // Group KPIs by category
  const sortByOrder = (kpis: any[]) => [...kpis].sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
  const vendorOnboardingKPIs = sortByOrder(allKPIs.filter(kpi => kpi.category === 'Vendor Onboarding'));
  const vendorStatusKPIs = sortByOrder(allKPIs.filter(kpi => kpi.category === 'Vendor Status'));
  const performanceKPIs = sortByOrder(allKPIs.filter(kpi => kpi.category === 'Performance Insights'));
  const customKPIs = sortByOrder(allKPIs.filter(kpi => !kpi.category || kpi.category === 'Custom'));

  // Helper: compute delta vs the most-recently archived period for a given KPI
  const getKpiDelta = (kpi: any): { delta: number; deltaLabel: string } | undefined => {
    const mostRecent = archivedKPIs.find(r => r.kpi_id === kpi.id);
    if (!mostRecent) return undefined;
    return {
      delta: (kpi.value || 0) - (mostRecent.value_at_archive || 0),
      deltaLabel: mostRecent.period_label
        ? `${mostRecent.period_label} · value: ${mostRecent.value_at_archive}`
        : `Last archived value: ${mostRecent.value_at_archive}`,
    };
  };

  // Helper: build sparkline data from archive history for a given KPI (chronological)
  const getSparklineData = (kpiId: string, currentValue: number): { value: number; label: string }[] => {
    const history = archivedKPIs
      .filter(r => r.kpi_id === kpiId)
      .sort((a, b) => new Date(a.archived_at).getTime() - new Date(b.archived_at).getTime())
      .map(r => ({
        value: Number(r.value_at_archive) || 0,
        label: r.period_label || format(new Date(r.archived_at), "MMM dd"),
      }));
    // Append the current live value as the latest point
    history.push({ value: currentValue || 0, label: "Current" });
    return history;
  };

  // Call KPI summaries
  const callKPIs = useMemo(() => {
    const totalMade = callLogs.reduce((sum, c) => sum + c.calls_made, 0);
    const totalAnswered = callLogs.reduce((sum, c) => sum + c.calls_answered, 0);
    const totalDuration = callLogs.reduce((sum, c) => sum + c.total_duration_minutes, 0);
    const answerRate = totalMade > 0 ? Math.round((totalAnswered / totalMade) * 100) : 0;
    
    return { totalMade, totalAnswered, totalDuration, answerRate };
  }, [callLogs]);

  // Query KPI summaries
  const queryKPIs = useMemo(() => {
    const totalReceived = vendorResponses.reduce((sum, r) => 
      sum + r.inquiries_received + r.inquiries_received_weekend, 0);
    const totalResponded = vendorResponses.reduce((sum, r) => 
      sum + r.inquiries_responded + r.inquiries_responded_weekend, 0);
    const responseRate = totalReceived > 0 ? Math.round((totalResponded / totalReceived) * 100) : 0;
    
    return { totalReceived, totalResponded, responseRate };
  }, [vendorResponses]);

  const handleReorder = (reorderedKpis: any[]) => {
    setAllKPIs(prev => {
      const reorderedIds = new Set(reorderedKpis.map(k => k.id));
      const others = prev.filter(k => !reorderedIds.has(k.id));
      return [...others, ...reorderedKpis];
    });
  };

  const handleEdit = (kpi: any) => {
    setSelectedKPI(kpi);
    setEditKPIOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!deleteKPIId) return;

    try {
      const { error } = await supabase
        .from('custom_kpis')
        .delete()
        .eq('id', deleteKPIId);

      if (error) throw error;

      toast.success("KPI deleted successfully");
      fetchCustomKPIs();
    } catch (error: any) {
      toast.error(error.message || "Failed to delete KPI");
    } finally {
      setDeleteKPIId(null);
    }
  };

  if (showSplash) {
    return <SplashScreen onComplete={() => { sessionStorage.setItem("splashShown", "1"); setShowSplash(false); }} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/80">
      <DashboardHeader
        lastUpdated={lastUpdated}
        user={user}
        isAdmin={isAdmin}
        onSignOut={signOut}
        onSignIn={() => setAuthOpen(true)}
        onCreateKPI={() => setCreateKPIOpen(true)}
        onArchiveOpen={() => setArchiveOpen(true)}
        onComparisonOpen={() => setComparisonOpen(true)}
        archivedCount={archivedKPIs.length}
      />
      <BreakPhaseBanner isAdmin={isAdmin} />
      <TodayAtAGlance />

      {/* Secondary toolbar: Bookmarks + PDF Export */}
      <div className="container mx-auto px-4 sm:px-6 py-2 flex flex-wrap justify-end gap-2">
        <DashboardBookmarks
          currentFilters={bookmarkFilters}
          onApplyBookmark={(filters) => setBookmarkFilters(filters)}
          userId={user?.id}
        />
        <PDFExportButton
          allKPIs={allKPIs}
          archivedKPIs={archivedKPIs}
          callKPIs={callKPIs}
          queryKPIs={queryKPIs}
          getKpiDelta={getKpiDelta}
        />
      </div>
      
      <main className="container mx-auto px-4 sm:px-6 py-8">
        {/* Vendor Onboarding Section */}
        <section className="mb-8 animate-fade-in">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-primary via-primary-accent to-primary bg-clip-text text-transparent flex items-center gap-3">
              <div className="w-1 h-8 bg-gradient-to-b from-primary to-primary-accent rounded-full" />
              Vendor Onboarding
            </h2>
            <div className="flex items-center gap-2">
              <NavLink to="/analytics?tab=vendors">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9 rounded-full hover:bg-primary/10 hover:scale-110 transition-all"
                  title="View Vendor Analytics"
                >
                  <BarChart3 className="h-5 w-5 text-primary" />
                </Button>
              </NavLink>
              {isAdmin && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9 rounded-full hover:bg-primary/10 hover:scale-110 transition-all"
                  onClick={() => {
                    setNewKPICategory("Vendor Onboarding");
                    setCreateKPIOpen(true);
                  }}
                >
                  <Plus className="h-5 w-5 text-primary" />
                </Button>
              )}
            </div>
          </div>
          <SortableKPIGrid kpis={vendorOnboardingKPIs} isAdmin={isAdmin} onReorder={handleReorder}>
            {(kpi) => {
              const d = getKpiDelta(kpi);
              return (
                <KPICard
                  key={kpi.id}
                  id={kpi.id}
                  title={kpi.name}
                  value={kpi.value || 0}
                  subtitle={kpi.description}
                  periodLabel={kpi.period_label}
                  icon={getKPIIcon(kpi.name)}
                  updatedAt={kpi.updated_at}
                  isAdmin={isAdmin}
                  onEdit={() => handleEdit(kpi)}
                  onDelete={() => setDeleteKPIId(kpi.id)}
                  onArchive={isAdmin ? () => handleArchive(kpi) : undefined}
                  delta={d?.delta}
                  deltaLabel={d?.deltaLabel}
                  sparklineData={getSparklineData(kpi.id, kpi.value || 0)}
                  targetValue={kpi.target_value}
                  warningThreshold={kpi.warning_threshold}
                  criticalThreshold={kpi.critical_threshold}
                />
              );
            }}
          </SortableKPIGrid>
        </section>
        {/* Vendor Status Section */}
        <section className="mb-8 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-primary via-primary-accent to-primary bg-clip-text text-transparent flex items-center gap-3">
              <div className="w-1 h-8 bg-gradient-to-b from-primary to-primary-accent rounded-full" />
              Vendor Status
            </h2>
            {isAdmin && (
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 rounded-full hover:bg-primary/10 hover:scale-110 transition-all"
                onClick={() => {
                  setNewKPICategory("Vendor Status");
                  setCreateKPIOpen(true);
                }}
              >
                <Plus className="h-5 w-5 text-primary" />
              </Button>
            )}
          </div>
          <SortableKPIGrid kpis={vendorStatusKPIs} isAdmin={isAdmin} onReorder={handleReorder} columns="grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
            {(kpi) => {
              const d = getKpiDelta(kpi);
              return (
                <KPICard
                  key={kpi.id}
                  id={kpi.id}
                  title={kpi.name}
                  value={kpi.value || 0}
                  subtitle={kpi.description}
                  icon={getKPIIcon(kpi.name)}
                  updatedAt={kpi.updated_at}
                  isAdmin={isAdmin}
                  onEdit={() => handleEdit(kpi)}
                  onDelete={() => setDeleteKPIId(kpi.id)}
                  onArchive={isAdmin ? () => handleArchive(kpi) : undefined}
                  delta={d?.delta}
                  deltaLabel={d?.deltaLabel}
                  sparklineData={getSparklineData(kpi.id, kpi.value || 0)}
                  targetValue={kpi.target_value}
                  warningThreshold={kpi.warning_threshold}
                  criticalThreshold={kpi.critical_threshold}
                />
              );
            }}
          </SortableKPIGrid>
        </section>

        {/* Charts Section */}
        <section className="mb-8 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-primary via-primary-accent to-primary bg-clip-text text-transparent flex items-center gap-3">
              <div className="w-1 h-8 bg-gradient-to-b from-primary to-primary-accent rounded-full" />
              Performance Insights
            </h2>
            {isAdmin && (
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 rounded-full hover:bg-primary/10 hover:scale-110 transition-all"
                onClick={() => {
                  setNewKPICategory("Performance Insights");
                  setCreateKPIOpen(true);
                }}
              >
                <Plus className="h-5 w-5 text-primary" />
              </Button>
            )}
          </div>
          
          {/* Performance KPI Cards */}
          {performanceKPIs.length > 0 && (
            <SortableKPIGrid kpis={performanceKPIs} isAdmin={isAdmin} onReorder={handleReorder}>
              {(kpi) => {
                const d = getKpiDelta(kpi);
                return (
                  <KPICard
                    key={kpi.id}
                    id={kpi.id}
                    title={kpi.name}
                    value={kpi.value || 0}
                    subtitle={kpi.description}
                    icon={getKPIIcon(kpi.name)}
                    updatedAt={kpi.updated_at}
                    isAdmin={isAdmin}
                    onEdit={() => handleEdit(kpi)}
                    onDelete={() => setDeleteKPIId(kpi.id)}
                    onArchive={isAdmin ? () => handleArchive(kpi) : undefined}
                    delta={d?.delta}
                    deltaLabel={d?.deltaLabel}
                    sparklineData={getSparklineData(kpi.id, kpi.value || 0)}
                    targetValue={kpi.target_value}
                    warningThreshold={kpi.warning_threshold}
                    criticalThreshold={kpi.critical_threshold}
                  />
                );
              }}
            </SortableKPIGrid>
          )}

          {/* Query & Call KPI Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-6">
            {/* Query KPIs */}
            <Card className="glass-card">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-primary" />
                  <div>
                    <div className="text-xl font-bold text-primary">{queryKPIs.totalReceived.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">Queries Received</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-green-500" />
                  <div>
                    <div className="text-xl font-bold text-green-500">{queryKPIs.totalResponded.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">Queries Responded</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <Percent className="h-5 w-5 text-blue-500" />
                  <div>
                    <div className="text-xl font-bold text-blue-500">{queryKPIs.responseRate}%</div>
                    <p className="text-xs text-muted-foreground">Response Rate</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Call KPIs */}
            <Card className="glass-card">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <Phone className="h-5 w-5 text-primary" />
                  <div>
                    <div className="text-xl font-bold text-primary">{callKPIs.totalMade.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">Total Calls</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <PhoneCall className="h-5 w-5 text-green-500" />
                  <div>
                    <div className="text-xl font-bold text-green-500">{callKPIs.totalAnswered.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">Answered</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-orange-500" />
                  <div>
                    <div className="text-xl font-bold text-orange-500">
                      {Math.floor(callKPIs.totalDuration / 60)}h {callKPIs.totalDuration % 60}m
                    </div>
                    <p className="text-xs text-muted-foreground">Call Duration</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <Percent className="h-5 w-5 text-purple-500" />
                  <div>
                    <div className="text-xl font-bold text-purple-500">{callKPIs.answerRate}%</div>
                    <p className="text-xs text-muted-foreground">Answer Rate</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Performance Charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-6">
            <SalesCycleChart />
            <VendorResponseCard />
            <VendorCallsCard />
          </div>

          {/* Call Quality Scorecard & Lead Conversion Funnel */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            <CallQualityScorecard callLogs={callLogs} />
            <LeadConversionFunnel
              totalOnboarded={vendorOnboardingKPIs.find(k => k.name === 'Total Vendors Onboarded')?.value || 0}
              activeVendors={vendorStatusKPIs.find(k => k.name === 'Active Vendors')?.value || 0}
              leftVendors={vendorStatusKPIs.find(k => k.name === 'Left Vendors')?.value || 0}
              terminatedVendors={vendorStatusKPIs.find(k => k.name === 'Terminated Vendors')?.value || 0}
              totalInquiries={queryKPIs.totalReceived}
              totalResponded={queryKPIs.totalResponded}
            />
          </div>
        </section>

        {/* Custom KPIs Section */}
        {customKPIs.length > 0 && (
          <section className="mb-8 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-primary via-primary-accent to-primary bg-clip-text text-transparent flex items-center gap-3">
                <div className="w-1 h-8 bg-gradient-to-b from-primary to-primary-accent rounded-full" />
                Custom KPIs
              </h2>
              {isAdmin && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9 rounded-full hover:bg-primary/10 hover:scale-110 transition-all"
                  onClick={() => {
                    setNewKPICategory("Custom");
                    setCreateKPIOpen(true);
                  }}
                >
                  <Plus className="h-5 w-5 text-primary" />
                </Button>
              )}
            </div>
            <SortableKPIGrid kpis={customKPIs} isAdmin={isAdmin} onReorder={handleReorder}>
              {(kpi) => {
                const d = getKpiDelta(kpi);
                return (
                  <KPICard
                    key={kpi.id}
                    id={kpi.id}
                    title={kpi.name}
                    value={kpi.value || 0}
                    subtitle={kpi.description || kpi.category}
                    updatedAt={kpi.updated_at}
                    isAdmin={isAdmin}
                    onEdit={() => handleEdit(kpi)}
                    onDelete={() => setDeleteKPIId(kpi.id)}
                    onArchive={isAdmin ? () => handleArchive(kpi) : undefined}
                    delta={d?.delta}
                    deltaLabel={d?.deltaLabel}
                    sparklineData={getSparklineData(kpi.id, kpi.value || 0)}
                    targetValue={kpi.target_value}
                    warningThreshold={kpi.warning_threshold}
                    criticalThreshold={kpi.critical_threshold}
                  />
                );
              }}
            </SortableKPIGrid>
          </section>
        )}
      </main>

      {/* Dialogs */}
      <AuthDialog open={authOpen} onOpenChange={setAuthOpen} />
      <KPIComparisonDialog
        open={comparisonOpen}
        onOpenChange={setComparisonOpen}
        allKPIs={allKPIs}
        getSparklineData={getSparklineData}
      />
      <CreateKPIDialog 
        open={createKPIOpen} 
        onOpenChange={(open) => {
          setCreateKPIOpen(open);
          if (!open) setNewKPICategory(null);
        }}
        onSuccess={fetchCustomKPIs}
        initialCategory={newKPICategory}
      />
      <EditKPIDialog
        open={editKPIOpen}
        onOpenChange={setEditKPIOpen}
        onSuccess={fetchCustomKPIs}
        kpi={selectedKPI}
        allKPIs={allKPIs}
        onArchiveAndReset={handleArchiveAndReset}
      />
      <ArchiveDialog
        open={archiveOpen}
        onOpenChange={setArchiveOpen}
        archivedKPIs={archivedKPIs}
        onRestore={handleRestore}
        onDelete={handleDeleteArchiveRecord}
        isAdmin={isAdmin}
      />
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteKPIId} onOpenChange={() => setDeleteKPIId(null)}>
        <AlertDialogContent className="glass-card border-border/50 animate-scale-in">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-bold bg-gradient-to-r from-destructive to-red-600 bg-clip-text text-transparent">
              Are you sure?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              This action cannot be undone. This will permanently delete the KPI.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="hover:bg-muted">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Index;
