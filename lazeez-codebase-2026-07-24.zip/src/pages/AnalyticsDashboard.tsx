import { useState, useEffect, useMemo } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { ThemeToggle } from "@/components/ThemeToggle";
import { NavLink } from "@/components/NavLink";
import { toast } from "@/hooks/use-toast";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  Legend,
  PieChart,
  Pie,
  Cell,
  ComposedChart,
} from "recharts";
import {
  TrendingUp,
  Users,
  Phone,
  Clock,
  MessageSquare,
  Calendar,
  BarChart3,
  Home,
  PhoneCall,
  PhoneOff,
  Timer,
  Save,
  Activity,
  Target,
  Percent,
  ArrowUpRight,
  ArrowDownRight,
  UserPlus,
  CheckCircle2,
  XCircle,
  CalendarDays,
  Download,
  FileText,
  ExternalLink,
} from "lucide-react";
import { format, startOfWeek, startOfMonth, startOfQuarter, startOfYear, subDays, parseISO, eachWeekOfInterval, eachMonthOfInterval, eachQuarterOfInterval, eachYearOfInterval, differenceInDays } from "date-fns";

interface VendorResponse {
  id: string;
  date: string;
  inquiries_received: number;
  inquiries_responded: number;
  inquiries_received_weekend: number;
  inquiries_responded_weekend: number;
  is_weekend: boolean;
}

interface KPIArchive {
  id: string;
  kpi_id: string;
  kpi_name: string;
  value_at_archive: number;
  archived_at: string;
  period_label: string | null;
  period_start_date: string | null;
  period_end_date: string | null;
}

interface CustomKPI {
  id: string;
  name: string;
  value: number | null;
  type: string;
  category: string | null;
  period_label: string | null;
  description: string | null;
}

interface CallLog {
  id: string;
  date: string;
  calls_made: number;
  calls_answered: number;
  total_duration_minutes: number;
  is_weekend: boolean;
}

const COLORS = [
  'hsl(var(--primary))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

export default function AnalyticsDashboard() {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const defaultTab = searchParams.get('tab') || 'vendors';
  
  const [vendorResponses, setVendorResponses] = useState<VendorResponse[]>([]);
  const [kpiArchives, setKpiArchives] = useState<KPIArchive[]>([]);
  const [customKPIs, setCustomKPIs] = useState<CustomKPI[]>([]);
  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(defaultTab);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    
    const [vendorRes, archiveRes, kpiRes, callRes] = await Promise.all([
      supabase.from('vendor_responses').select('*').order('date', { ascending: true }),
      supabase.from('kpi_archive_history').select('*').order('archived_at', { ascending: true }),
      supabase.from('custom_kpis').select('*'),
      supabase.from('call_logs').select('*').order('date', { ascending: true }),
    ]);

    if (vendorRes.data) setVendorResponses(vendorRes.data);
    if (archiveRes.data) setKpiArchives(archiveRes.data);
    if (kpiRes.data) setCustomKPIs(kpiRes.data);
    if (callRes.data) setCallLogs(callRes.data);

    setLoading(false);
  };

  // Vendor Onboarding KPIs
  const vendorOnboardingKPIs = useMemo(() => {
    return customKPIs.filter(kpi => kpi.category === 'Vendor Onboarding');
  }, [customKPIs]);

  // Vendor Status KPIs
  const vendorStatusKPIs = useMemo(() => {
    return customKPIs.filter(kpi => kpi.category === 'Vendor Status');
  }, [customKPIs]);

  // Vendor Growth by Time Period (from archives)
  const vendorGrowthData = useMemo(() => {
    const vendorArchives = kpiArchives.filter(a => 
      ['Last 2 Weeks', 'Last 2 Months', 'Last Quarter', 'Total Vendors Onboarded'].includes(a.kpi_name)
    );
    
    // Group by period
    const periodData: { [key: string]: { [kpiName: string]: number } } = {};
    vendorArchives.forEach(a => {
      const period = a.period_label || format(parseISO(a.archived_at), 'MMM yyyy');
      if (!periodData[period]) periodData[period] = {};
      periodData[period][a.kpi_name] = a.value_at_archive;
    });

    return Object.entries(periodData).map(([period, values]) => ({
      period,
      'Last 2 Weeks': values['Last 2 Weeks'] || 0,
      'Last 2 Months': values['Last 2 Months'] || 0,
      'Last Quarter': values['Last Quarter'] || 0,
    })).slice(-8);
  }, [kpiArchives]);

  // Current vendor onboarding comparison
  const vendorOnboardingComparison = useMemo(() => {
    const twoWeeks = vendorOnboardingKPIs.find(k => k.name === 'Last 2 Weeks');
    const twoMonths = vendorOnboardingKPIs.find(k => k.name === 'Last 2 Months');
    const quarter = vendorOnboardingKPIs.find(k => k.name === 'Last Quarter');
    const total = vendorOnboardingKPIs.find(k => k.name === 'Total Vendors Onboarded');

    return [
      { name: 'Last 2 Weeks', value: twoWeeks?.value || 0, fill: COLORS[0] },
      { name: 'Last 2 Months', value: twoMonths?.value || 0, fill: COLORS[1] },
      { name: 'Last Quarter', value: quarter?.value || 0, fill: COLORS[2] },
    ];
  }, [vendorOnboardingKPIs]);

  // Weekly Queries Data
  const weeklyQueriesData = useMemo(() => {
    if (vendorResponses.length === 0) return [];

    const weeks = eachWeekOfInterval({
      start: subDays(new Date(), 84),
      end: new Date(),
    });

    return weeks.map(weekStart => {
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);

      const weekData = vendorResponses.filter(r => {
        const date = parseISO(r.date);
        return date >= weekStart && date <= weekEnd;
      });

      const weekdayReceived = weekData.reduce((sum, r) => sum + r.inquiries_received, 0);
      const weekdayResponded = weekData.reduce((sum, r) => sum + r.inquiries_responded, 0);
      const weekendReceived = weekData.reduce((sum, r) => sum + r.inquiries_received_weekend, 0);
      const weekendResponded = weekData.reduce((sum, r) => sum + r.inquiries_responded_weekend, 0);

      return {
        week: format(weekStart, 'MMM dd'),
        weekdayReceived,
        weekdayResponded,
        weekendReceived,
        weekendResponded,
        totalReceived: weekdayReceived + weekendReceived,
        totalResponded: weekdayResponded + weekendResponded,
      };
    }).slice(-12);
  }, [vendorResponses]);

  // Monthly Queries Data
  const monthlyQueriesData = useMemo(() => {
    if (vendorResponses.length === 0) return [];

    const months = eachMonthOfInterval({
      start: subDays(new Date(), 365),
      end: new Date(),
    });

    return months.map(monthStart => {
      const monthEnd = new Date(monthStart);
      monthEnd.setMonth(monthEnd.getMonth() + 1);
      monthEnd.setDate(0);

      const monthData = vendorResponses.filter(r => {
        const date = parseISO(r.date);
        return date >= monthStart && date <= monthEnd;
      });

      const weekdayReceived = monthData.reduce((sum, r) => sum + r.inquiries_received, 0);
      const weekendReceived = monthData.reduce((sum, r) => sum + r.inquiries_received_weekend, 0);
      const weekdayResponded = monthData.reduce((sum, r) => sum + r.inquiries_responded, 0);
      const weekendResponded = monthData.reduce((sum, r) => sum + r.inquiries_responded_weekend, 0);

      return {
        month: format(monthStart, 'MMM yyyy'),
        weekday: weekdayReceived,
        weekend: weekendReceived,
        total: weekdayReceived + weekendReceived,
        responded: weekdayResponded + weekendResponded,
      };
    }).slice(-12);
  }, [vendorResponses]);

  // Quarterly Query Summary
  const quarterlyQueryData = useMemo(() => {
    const quarters: { [key: string]: { received: number; responded: number } } = {};

    vendorResponses.forEach(r => {
      const date = parseISO(r.date);
      const q = Math.floor(date.getMonth() / 3) + 1;
      const year = date.getFullYear();
      const key = `Q${q} ${year}`;

      if (!quarters[key]) quarters[key] = { received: 0, responded: 0 };
      quarters[key].received += r.inquiries_received + r.inquiries_received_weekend;
      quarters[key].responded += r.inquiries_responded + r.inquiries_responded_weekend;
    });

    return Object.entries(quarters).map(([quarter, data]) => ({
      quarter,
      received: data.received,
      responded: data.responded,
      responseRate: data.received > 0 ? Math.round((data.responded / data.received) * 100) : 0,
    })).slice(-8);
  }, [vendorResponses]);

  // Yearly Query Summary
  const yearlyQueryData = useMemo(() => {
    const years: { [key: string]: { received: number; responded: number } } = {};

    vendorResponses.forEach(r => {
      const date = parseISO(r.date);
      const year = date.getFullYear().toString();

      if (!years[year]) years[year] = { received: 0, responded: 0 };
      years[year].received += r.inquiries_received + r.inquiries_received_weekend;
      years[year].responded += r.inquiries_responded + r.inquiries_responded_weekend;
    });

    return Object.entries(years).map(([year, data]) => ({
      year,
      received: data.received,
      responded: data.responded,
      responseRate: data.received > 0 ? Math.round((data.responded / data.received) * 100) : 0,
    }));
  }, [vendorResponses]);

  // Query Trail (daily tracking)
  const queryTrail = useMemo(() => {
    return vendorResponses.slice(-30).map(r => ({
      date: format(parseISO(r.date), 'MMM dd'),
      fullDate: r.date,
      received: r.inquiries_received + r.inquiries_received_weekend,
      responded: r.inquiries_responded + r.inquiries_responded_weekend,
      isWeekend: r.is_weekend,
    }));
  }, [vendorResponses]);

  // Call Analytics
  const callAnalyticsData = useMemo(() => {
    if (callLogs.length === 0) return { 
      weekly: [], 
      monthly: [], 
      quarterly: [],
      yearly: [],
      totals: { made: 0, answered: 0, duration: 0 },
      trail: []
    };

    const weeks = eachWeekOfInterval({
      start: subDays(new Date(), 84),
      end: new Date(),
    });

    const weekly = weeks.map(weekStart => {
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);

      const weekData = callLogs.filter(c => {
        const date = parseISO(c.date);
        return date >= weekStart && date <= weekEnd;
      });

      return {
        week: format(weekStart, 'MMM dd'),
        callsMade: weekData.reduce((sum, c) => sum + c.calls_made, 0),
        callsAnswered: weekData.reduce((sum, c) => sum + c.calls_answered, 0),
        duration: weekData.reduce((sum, c) => sum + c.total_duration_minutes, 0),
      };
    }).slice(-12);

    const months = eachMonthOfInterval({
      start: subDays(new Date(), 365),
      end: new Date(),
    });

    const monthly = months.map(monthStart => {
      const monthEnd = new Date(monthStart);
      monthEnd.setMonth(monthEnd.getMonth() + 1);
      monthEnd.setDate(0);

      const monthData = callLogs.filter(c => {
        const date = parseISO(c.date);
        return date >= monthStart && date <= monthEnd;
      });

      return {
        month: format(monthStart, 'MMM yyyy'),
        callsMade: monthData.reduce((sum, c) => sum + c.calls_made, 0),
        callsAnswered: monthData.reduce((sum, c) => sum + c.calls_answered, 0),
        duration: monthData.reduce((sum, c) => sum + c.total_duration_minutes, 0),
      };
    }).slice(-12);

    // Quarterly
    const quarters: { [key: string]: { made: number; answered: number; duration: number } } = {};
    callLogs.forEach(c => {
      const date = parseISO(c.date);
      const q = Math.floor(date.getMonth() / 3) + 1;
      const year = date.getFullYear();
      const key = `Q${q} ${year}`;

      if (!quarters[key]) quarters[key] = { made: 0, answered: 0, duration: 0 };
      quarters[key].made += c.calls_made;
      quarters[key].answered += c.calls_answered;
      quarters[key].duration += c.total_duration_minutes;
    });

    const quarterly = Object.entries(quarters).map(([quarter, data]) => ({
      quarter,
      callsMade: data.made,
      callsAnswered: data.answered,
      duration: data.duration,
      answerRate: data.made > 0 ? Math.round((data.answered / data.made) * 100) : 0,
    })).slice(-8);

    // Yearly
    const years: { [key: string]: { made: number; answered: number; duration: number } } = {};
    callLogs.forEach(c => {
      const date = parseISO(c.date);
      const year = date.getFullYear().toString();

      if (!years[year]) years[year] = { made: 0, answered: 0, duration: 0 };
      years[year].made += c.calls_made;
      years[year].answered += c.calls_answered;
      years[year].duration += c.total_duration_minutes;
    });

    const yearly = Object.entries(years).map(([year, data]) => ({
      year,
      callsMade: data.made,
      callsAnswered: data.answered,
      duration: data.duration,
      answerRate: data.made > 0 ? Math.round((data.answered / data.made) * 100) : 0,
    }));

    const totals = {
      made: callLogs.reduce((sum, c) => sum + c.calls_made, 0),
      answered: callLogs.reduce((sum, c) => sum + c.calls_answered, 0),
      duration: callLogs.reduce((sum, c) => sum + c.total_duration_minutes, 0),
    };

    // Call Trail
    const trail = callLogs.slice(-30).map(c => ({
      date: format(parseISO(c.date), 'MMM dd'),
      fullDate: c.date,
      made: c.calls_made,
      answered: c.calls_answered,
      duration: c.total_duration_minutes,
      isWeekend: c.is_weekend,
    }));

    return { weekly, monthly, quarterly, yearly, totals, trail };
  }, [callLogs]);

  // Daily/Weekend Split for Queries
  const dailyWeekendSplit = useMemo(() => {
    const totalWeekday = vendorResponses.reduce((sum, r) => sum + r.inquiries_received, 0);
    const totalWeekend = vendorResponses.reduce((sum, r) => sum + r.inquiries_received_weekend, 0);

    return [
      { name: 'Weekday', value: totalWeekday },
      { name: 'Weekend', value: totalWeekend },
    ];
  }, [vendorResponses]);

  // Query totals
  const queryTotals = useMemo(() => {
    const totalReceived = vendorResponses.reduce((sum, r) => 
      sum + r.inquiries_received + r.inquiries_received_weekend, 0);
    const totalResponded = vendorResponses.reduce((sum, r) => 
      sum + r.inquiries_responded + r.inquiries_responded_weekend, 0);
    const weekdayReceived = vendorResponses.reduce((sum, r) => sum + r.inquiries_received, 0);
    const weekendReceived = vendorResponses.reduce((sum, r) => sum + r.inquiries_received_weekend, 0);
    const responseRate = totalReceived > 0 ? Math.round((totalResponded / totalReceived) * 100) : 0;

    return { totalReceived, totalResponded, weekdayReceived, weekendReceived, responseRate };
  }, [vendorResponses]);

  // Export to CSV
  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) {
      toast({ title: "No data", description: "No data available to export", variant: "destructive" });
      return;
    }
    
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => headers.map(h => `"${row[h] ?? ''}"`).join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}_${format(new Date(), 'yyyy-MM-dd')}.csv`;
    link.click();
    toast({ title: "Exported", description: `${filename}.csv downloaded successfully` });
  };

  // Export to PDF
  const exportToPDF = (data: any[], title: string, filename: string) => {
    if (data.length === 0) {
      toast({ title: "No data", description: "No data available to export", variant: "destructive" });
      return;
    }

    try {
      const doc = new jsPDF();
      const headers = Object.keys(data[0]);
      
      // Sanitize data to avoid Unicode issues - convert to safe strings
      const sanitizedBody = data.map(row => 
        headers.map(h => {
          const value = row[h];
          if (value === null || value === undefined) return '';
          // Convert to string and replace problematic characters
          return String(value).replace(/[^\x00-\x7F]/g, '');
        })
      );
      
      const sanitizedHeaders = headers.map(h => 
        String(h).replace(/[^\x00-\x7F]/g, '')
      );
      
      doc.setFontSize(18);
      doc.text(title.replace(/[^\x00-\x7F]/g, ''), 14, 22);
      doc.setFontSize(11);
      doc.text(`Generated on: ${format(new Date(), 'PPpp')}`, 14, 32);
      
      // Use autoTable function directly
      autoTable(doc, {
        head: [sanitizedHeaders],
        body: sanitizedBody,
        startY: 40,
        styles: { fontSize: 8 },
        headStyles: { fillColor: [59, 130, 246] },
      });
      
      doc.save(`${filename}_${format(new Date(), 'yyyy-MM-dd')}.pdf`);
      toast({ title: "Exported", description: `${filename}.pdf downloaded successfully` });
    } catch (error) {
      console.error('PDF export error:', error);
      toast({ title: "Export Error", description: "Failed to generate PDF. Try CSV export instead.", variant: "destructive" });
    }
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-card p-3 border border-border/50 rounded-lg shadow-lg">
          <p className="text-sm font-medium text-foreground mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-xs" style={{ color: entry.color }}>
              {entry.name}: <span className="font-bold">{entry.value.toLocaleString()}</span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-primary">Loading analytics...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-lg">
        <div className="container mx-auto px-2 sm:px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 sm:gap-4 min-w-0">
              <NavLink to="/" className="p-2 rounded-lg hover:bg-muted/50 transition-colors flex-shrink-0">
                <Home className="h-5 w-5" />
              </NavLink>
              <h1 className="text-base sm:text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent truncate">
                Analytics
              </h1>
            </div>
            <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
              {/* Export Buttons */}
              <div className="flex items-center gap-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (activeTab === 'vendors') {
                      exportToCSV(vendorGrowthData, 'vendor_analytics');
                    } else if (activeTab === 'queries') {
                      exportToCSV(queryTrail, 'query_analytics');
                    } else {
                      exportToCSV(callAnalyticsData.trail, 'call_analytics');
                    }
                  }}
                  className="gap-1 px-2 sm:px-3"
                >
                  <Download className="h-4 w-4" />
                  <span className="hidden sm:inline">CSV</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (activeTab === 'vendors') {
                      exportToPDF(vendorGrowthData, 'Vendor Analytics Report', 'vendor_analytics');
                    } else if (activeTab === 'queries') {
                      exportToPDF(queryTrail, 'Query Analytics Report', 'query_analytics');
                    } else {
                      exportToPDF(callAnalyticsData.trail, 'Call Analytics Report', 'call_analytics');
                    }
                  }}
                  className="gap-1 px-2 sm:px-3"
                >
                  <FileText className="h-4 w-4" />
                  <span className="hidden sm:inline">PDF</span>
                </Button>
              </div>
              <NavLink to="/vendor-responses" className="hidden md:block text-sm text-muted-foreground hover:text-foreground transition-colors">
                Responses
              </NavLink>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-2 sm:px-4 py-4 sm:py-6 space-y-4 sm:space-y-6">
        {/* Tab Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 max-w-full sm:max-w-lg h-auto">
            <TabsTrigger value="vendors" className="gap-1 text-xs sm:text-sm px-1 sm:px-3 py-2">
              <Users className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden xs:inline">Vendors</span>
            </TabsTrigger>
            <TabsTrigger value="queries" className="gap-1 text-xs sm:text-sm px-1 sm:px-3 py-2">
              <MessageSquare className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden xs:inline">Queries</span>
            </TabsTrigger>
            <TabsTrigger value="calls" className="gap-1 text-xs sm:text-sm px-1 sm:px-3 py-2">
              <Phone className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden xs:inline">Calls</span>
            </TabsTrigger>
            <TabsTrigger value="combined" className="gap-1 text-xs sm:text-sm px-1 sm:px-3 py-2">
              <BarChart3 className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden xs:inline">All</span>
            </TabsTrigger>
          </TabsList>

          {/* Vendors Tab */}
          <TabsContent value="vendors" className="space-y-4 sm:space-y-6 mt-4 sm:mt-6">
            {/* Vendor Onboarding KPIs */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4">
              {vendorOnboardingKPIs.map((kpi) => (
                <Card key={kpi.id} className="glass-card">
                  <CardContent className="p-3 sm:pt-4">
                    <div className="flex items-center gap-2">
                      <UserPlus className="h-4 w-4 sm:h-5 sm:w-5 text-primary flex-shrink-0" />
                      <div className="min-w-0">
                        <div className="text-lg sm:text-2xl font-bold text-primary">{kpi.value?.toLocaleString() || 0}</div>
                        <p className="text-xs text-muted-foreground truncate">{kpi.name}</p>
                        {kpi.period_label && (
                          <p className="text-xs text-primary/70 mt-1 truncate">{kpi.period_label}</p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Vendor Status KPIs */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4">
              {vendorStatusKPIs.map((kpi) => (
                <Card key={kpi.id} className="glass-card">
                  <CardContent className="p-3 sm:pt-4">
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4 sm:h-5 sm:w-5 text-chart-2 flex-shrink-0" />
                      <div className="min-w-0">
                        <div className="text-lg sm:text-2xl font-bold" style={{ color: 'hsl(var(--chart-2))' }}>
                          {kpi.value?.toLocaleString() || 0}
                        </div>
                        <p className="text-xs text-muted-foreground truncate">{kpi.name}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Vendor Growth Over Time */}
            <Card className="glass-card">
              <CardHeader className="pb-2 sm:pb-4">
                <CardTitle className="flex items-center gap-2 text-sm sm:text-base">
                  <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                  Vendor Onboarding Trends
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">Historical onboarding by period</CardDescription>
              </CardHeader>
              <CardContent className="p-2 sm:p-6">
                <div className="h-[250px] sm:h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={vendorGrowthData} margin={{ top: 5, right: 5, left: -15, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                      <XAxis dataKey="period" tick={{ fontSize: 9 }} className="text-muted-foreground" />
                      <YAxis tick={{ fontSize: 9 }} className="text-muted-foreground" width={35} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: '10px' }} />
                      <Bar dataKey="Last 2 Weeks" fill={COLORS[0]} radius={[4, 4, 0, 0]} />
                      <Bar dataKey="Last 2 Months" fill={COLORS[1]} radius={[4, 4, 0, 0]} />
                      <Bar dataKey="Last Quarter" fill={COLORS[2]} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Current Period Comparison */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    Current Period Comparison
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={vendorOnboardingComparison}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={5}
                          dataKey="value"
                          label={({ name, value }) => `${name}: ${value}`}
                        >
                          {vendorOnboardingComparison.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* KPI Archive Timeline */}
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarDays className="h-5 w-5 text-primary" />
                    Archive History
                  </CardTitle>
                  <CardDescription>Historical archived values</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={kpiArchives.slice(-10).map(a => ({
                        period: a.period_label || format(parseISO(a.archived_at), 'MMM dd'),
                        value: a.value_at_archive,
                        kpi: a.kpi_name,
                      }))}>
                        <defs>
                          <linearGradient id="archiveGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--chart-3))" stopOpacity={0.4} />
                            <stop offset="95%" stopColor="hsl(var(--chart-3))" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                        <XAxis dataKey="period" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                        <YAxis tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <Tooltip content={<CustomTooltip />} />
                        <Area type="monotone" dataKey="value" name="Archived Value" stroke="hsl(var(--chart-3))" fill="url(#archiveGradient)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Queries Tab */}
          <TabsContent value="queries" className="space-y-6 mt-6">
            {/* Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-primary" />
                    <div>
                      <div className="text-2xl font-bold text-primary">
                        {queryTotals.totalReceived.toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">Total Received</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <div>
                      <div className="text-2xl font-bold text-green-500">
                        {queryTotals.totalResponded.toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">Total Responded</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <Percent className="h-5 w-5 text-blue-500" />
                    <div>
                      <div className="text-2xl font-bold text-blue-500">
                        {queryTotals.responseRate}%
                      </div>
                      <p className="text-xs text-muted-foreground">Response Rate</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-orange-500" />
                    <div>
                      <div className="text-2xl font-bold text-orange-500">
                        {queryTotals.weekdayReceived.toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">Weekday Queries</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <CalendarDays className="h-5 w-5 text-purple-500" />
                    <div>
                      <div className="text-2xl font-bold text-purple-500">
                        {queryTotals.weekendReceived.toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">Weekend Queries</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Query Trail */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Query Trail (Last 30 Days)
                </CardTitle>
                <CardDescription>Daily query received vs responded</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={queryTrail}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                      <XAxis dataKey="date" tick={{ fontSize: 9 }} className="text-muted-foreground" />
                      <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="received" name="Received" fill="hsl(var(--primary))" opacity={0.8} />
                      <Line type="monotone" dataKey="responded" name="Responded" stroke="hsl(var(--chart-2))" strokeWidth={2} dot={{ r: 3 }} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Daily vs Weekend Pie Chart & Weekly Trend */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-primary" />
                    Weekday vs Weekend Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={dailyWeekendSplit}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={5}
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {dailyWeekendSplit.map((_, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    Weekly Query Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={weeklyQueriesData}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                        <XAxis dataKey="week" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                        <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Line type="monotone" dataKey="totalReceived" name="Received" stroke="hsl(var(--primary))" strokeWidth={2} />
                        <Line type="monotone" dataKey="totalResponded" name="Responded" stroke="hsl(var(--chart-2))" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Monthly Breakdown */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  Monthly Query Breakdown
                </CardTitle>
                <CardDescription>Weekday vs Weekend queries per month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyQueriesData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                      <XAxis dataKey="month" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                      <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="weekday" name="Weekday" stackId="a" fill="hsl(var(--primary))" />
                      <Bar dataKey="weekend" name="Weekend" stackId="a" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Quarterly & Yearly Summary */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-primary" />
                    Quarterly Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={quarterlyQueryData}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                        <XAxis dataKey="quarter" tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <YAxis yAxisId="left" tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} className="text-muted-foreground" domain={[0, 100]} />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Bar yAxisId="left" dataKey="received" name="Received" fill="hsl(var(--primary))" />
                        <Bar yAxisId="left" dataKey="responded" name="Responded" fill="hsl(var(--chart-2))" />
                        <Line yAxisId="right" type="monotone" dataKey="responseRate" name="Response %" stroke="hsl(var(--chart-3))" strokeWidth={2} dot={{ r: 4 }} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarDays className="h-5 w-5 text-primary" />
                    Yearly Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={yearlyQueryData}>
                        <defs>
                          <linearGradient id="yearlyGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                            <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                        <XAxis dataKey="year" tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <YAxis tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Area type="monotone" dataKey="received" name="Received" stroke="hsl(var(--primary))" fill="url(#yearlyGradient)" strokeWidth={2} />
                        <Area type="monotone" dataKey="responded" name="Responded" stroke="hsl(var(--chart-2))" fill="url(#yearlyGradient)" strokeWidth={2} fillOpacity={0.3} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Calls Tab */}
          <TabsContent value="calls" className="space-y-6 mt-6">
            {/* Link to Dedicated Call Tracking Page (Admin Only) */}
            {isAdmin && (
              <Card className="glass-card border-primary/30">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PhoneCall className="h-5 w-5 text-primary" />
                    Call Data Entry
                  </CardTitle>
                  <CardDescription>Enter and manage daily call tracking data</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={() => navigate('/vendor-calls')} 
                    className="w-full gap-2"
                  >
                    <ExternalLink className="h-4 w-4" />
                    Open Call Tracking Page
                  </Button>
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    Track daily calls, answer rates, and view historical data
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Call Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-primary" />
                    <div>
                      <div className="text-2xl font-bold text-primary">{callAnalyticsData.totals.made.toLocaleString()}</div>
                      <p className="text-xs text-muted-foreground">Total Calls Made</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <PhoneCall className="h-5 w-5 text-green-500" />
                    <div>
                      <div className="text-2xl font-bold text-green-500">{callAnalyticsData.totals.answered.toLocaleString()}</div>
                      <p className="text-xs text-muted-foreground">Calls Answered</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <PhoneOff className="h-5 w-5 text-red-500" />
                    <div>
                      <div className="text-2xl font-bold text-red-500">
                        {(callAnalyticsData.totals.made - callAnalyticsData.totals.answered).toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">Unanswered</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-blue-500" />
                    <div>
                      <div className="text-2xl font-bold text-blue-500">
                        {Math.floor(callAnalyticsData.totals.duration / 60)}h {callAnalyticsData.totals.duration % 60}m
                      </div>
                      <p className="text-xs text-muted-foreground">Total Duration</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="glass-card">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-2">
                    <Percent className="h-5 w-5 text-purple-500" />
                    <div>
                      <div className="text-2xl font-bold text-purple-500">
                        {callAnalyticsData.totals.made > 0 
                          ? Math.round((callAnalyticsData.totals.answered / callAnalyticsData.totals.made) * 100) 
                          : 0}%
                      </div>
                      <p className="text-xs text-muted-foreground">Answer Rate</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Call Trail */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Call Trail (Last 30 Days)
                </CardTitle>
                <CardDescription>Daily calls made vs answered with duration</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={callAnalyticsData.trail}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                      <XAxis dataKey="date" tick={{ fontSize: 9 }} className="text-muted-foreground" />
                      <YAxis yAxisId="left" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                      <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar yAxisId="left" dataKey="made" name="Made" fill="hsl(var(--primary))" opacity={0.8} />
                      <Bar yAxisId="left" dataKey="answered" name="Answered" fill="hsl(var(--chart-2))" opacity={0.8} />
                      <Line yAxisId="right" type="monotone" dataKey="duration" name="Duration (min)" stroke="hsl(var(--chart-3))" strokeWidth={2} dot={{ r: 3 }} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Weekly Call Trends */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Weekly Call Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={callAnalyticsData.weekly}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                      <XAxis dataKey="week" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                      <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="callsMade" name="Calls Made" fill="hsl(var(--primary))" />
                      <Bar dataKey="callsAnswered" name="Answered" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Monthly Call Stats & Duration */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    Monthly Call Volume
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={callAnalyticsData.monthly}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                        <XAxis dataKey="month" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                        <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Line type="monotone" dataKey="callsMade" name="Made" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 4 }} />
                        <Line type="monotone" dataKey="callsAnswered" name="Answered" stroke="hsl(var(--chart-2))" strokeWidth={2} dot={{ r: 4 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-primary" />
                    Monthly Call Duration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={callAnalyticsData.monthly}>
                        <defs>
                          <linearGradient id="durationGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--chart-3))" stopOpacity={0.4} />
                            <stop offset="95%" stopColor="hsl(var(--chart-3))" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                        <XAxis dataKey="month" tick={{ fontSize: 10 }} className="text-muted-foreground" />
                        <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                        <Tooltip content={<CustomTooltip />} />
                        <Area type="monotone" dataKey="duration" name="Duration (min)" stroke="hsl(var(--chart-3))" fill="url(#durationGradient)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quarterly & Yearly Call Stats */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-primary" />
                    Quarterly Call Volume
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={callAnalyticsData.quarterly}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                        <XAxis dataKey="quarter" tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <YAxis yAxisId="left" tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} className="text-muted-foreground" domain={[0, 100]} />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Bar yAxisId="left" dataKey="callsMade" name="Made" fill="hsl(var(--primary))" />
                        <Bar yAxisId="left" dataKey="callsAnswered" name="Answered" fill="hsl(var(--chart-2))" />
                        <Line yAxisId="right" type="monotone" dataKey="answerRate" name="Answer %" stroke="hsl(var(--chart-3))" strokeWidth={2} dot={{ r: 4 }} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarDays className="h-5 w-5 text-primary" />
                    Yearly Call Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={callAnalyticsData.yearly}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                        <XAxis dataKey="year" tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <YAxis tick={{ fontSize: 11 }} className="text-muted-foreground" />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Bar dataKey="callsMade" name="Made" fill="hsl(var(--primary))" />
                        <Bar dataKey="callsAnswered" name="Answered" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Yearly Duration Trend */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Timer className="h-5 w-5 text-primary" />
                  Yearly Call Duration Trend
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={callAnalyticsData.yearly}>
                      <defs>
                        <linearGradient id="yearlyDurationGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--chart-4))" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="hsl(var(--chart-4))" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                      <XAxis dataKey="year" tick={{ fontSize: 11 }} className="text-muted-foreground" />
                      <YAxis tick={{ fontSize: 11 }} className="text-muted-foreground" />
                      <Tooltip content={<CustomTooltip />} />
                      <Area type="monotone" dataKey="duration" name="Total Duration (min)" stroke="hsl(var(--chart-4))" fill="url(#yearlyDurationGradient)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Combined Tab */}
          <TabsContent value="combined" className="space-y-6 mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Query Summary */}
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-primary" />
                    Query Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Total Received</span>
                    <span className="font-bold text-primary">{queryTotals.totalReceived.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Total Responded</span>
                    <span className="font-bold text-green-500">{queryTotals.totalResponded.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Response Rate</span>
                    <span className="font-bold text-blue-500">{queryTotals.responseRate}%</span>
                  </div>
                </CardContent>
              </Card>

              {/* Call Summary */}
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-chart-2" />
                    Call Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Total Made</span>
                    <span className="font-bold" style={{ color: 'hsl(var(--chart-2))' }}>{callAnalyticsData.totals.made.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Total Answered</span>
                    <span className="font-bold text-green-500">{callAnalyticsData.totals.answered.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Answer Rate</span>
                    <span className="font-bold text-purple-500">
                      {callAnalyticsData.totals.made > 0 ? Math.round((callAnalyticsData.totals.answered / callAnalyticsData.totals.made) * 100) : 0}%
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Combined Trail Chart */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Queries vs Calls (Last 30 Days)
                </CardTitle>
                <CardDescription>Side-by-side comparison of daily activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={queryTrail.map((q, i) => ({
                      ...q,
                      callsMade: callAnalyticsData.trail[i]?.made || 0,
                      callsAnswered: callAnalyticsData.trail[i]?.answered || 0,
                    }))}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                      <XAxis dataKey="date" tick={{ fontSize: 9 }} className="text-muted-foreground" />
                      <YAxis tick={{ fontSize: 10 }} className="text-muted-foreground" />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="received" name="Queries Received" fill="hsl(var(--primary))" opacity={0.8} />
                      <Bar dataKey="callsMade" name="Calls Made" fill="hsl(var(--chart-2))" opacity={0.8} />
                      <Line type="monotone" dataKey="responded" name="Queries Responded" stroke="hsl(var(--chart-3))" strokeWidth={2} />
                      <Line type="monotone" dataKey="callsAnswered" name="Calls Answered" stroke="hsl(var(--chart-4))" strokeWidth={2} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
