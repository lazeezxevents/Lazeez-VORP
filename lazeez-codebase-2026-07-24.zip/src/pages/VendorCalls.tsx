import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Save, Calendar, TrendingUp, Phone, PhoneCall, Clock, Percent, Download, Pencil } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useVisitorTracking } from "@/hooks/useVisitorTracking";
import { useAdvancedTracking } from "@/hooks/useAdvancedTracking";
import { ThemeToggle } from "@/components/ThemeToggle";
import { format, parseISO, subDays, subMonths } from "date-fns";
import { EditCallLogDialog } from "@/components/EditCallLogDialog";

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Legend, CartesianGrid, BarChart, Bar, AreaChart, Area } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface CallLog {
  id: string;
  date: string;
  calls_made: number;
  calls_answered: number;
  total_duration_minutes: number;
  is_weekend: boolean;
}

export default function VendorCalls() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [allCallLogs, setAllCallLogs] = useState<CallLog[]>([]);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [currentEntry, setCurrentEntry] = useState<CallLog | null>(null);
  
  // Form state
  const [callsMade, setCallsMade] = useState(0);
  const [callsAnswered, setCallsAnswered] = useState(0);
  const [durationMinutes, setDurationMinutes] = useState(0);
  
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Edit dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<CallLog | null>(null);

  // Track visitor
  useVisitorTracking('Vendor Calls');
  useAdvancedTracking('Vendor Calls');

  // Detect if selected date is a weekend
  const selectedDayOfWeek = new Date(selectedDate).getDay();
  const isWeekend = selectedDayOfWeek === 0 || selectedDayOfWeek === 6;

  useEffect(() => {
    fetchData();
    checkAdminStatus();
  }, [user]);

  useEffect(() => {
    fetchEntryForDate(selectedDate);
  }, [selectedDate, allCallLogs]);

  const checkAdminStatus = async () => {
    if (!user) {
      setIsAdmin(false);
      return;
    }
    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .maybeSingle();
    setIsAdmin(data?.role === 'admin');
  };

  const fetchData = async () => {
    setLoading(true);
    
    const { data: callData } = await supabase
      .from('call_logs')
      .select('*')
      .order('date', { ascending: false });

    if (callData) {
      setAllCallLogs(callData as CallLog[]);
    }

    setLoading(false);
  };

  const fetchEntryForDate = async (date: string) => {
    const existingEntry = allCallLogs.find(log => log.date === date);
    
    if (existingEntry) {
      setCurrentEntry(existingEntry);
      setCallsMade(existingEntry.calls_made);
      setCallsAnswered(existingEntry.calls_answered);
      setDurationMinutes(existingEntry.total_duration_minutes);
    } else {
      // No entry exists for this date
      setCurrentEntry(null);
      setCallsMade(0);
      setCallsAnswered(0);
      setDurationMinutes(0);
    }
  };

  const handleSave = async () => {
    const isSelectedWeekend = [0, 6].includes(new Date(selectedDate).getDay());
    
    if (currentEntry) {
      // Update existing entry
      const { error } = await supabase
        .from('call_logs')
        .update({
          calls_made: callsMade,
          calls_answered: callsAnswered,
          total_duration_minutes: durationMinutes,
          is_weekend: isSelectedWeekend
        })
        .eq('id', currentEntry.id);

      if (error) {
        toast.error("Failed to save");
      } else {
        toast.success("Saved successfully");
        fetchData();
      }
    } else {
      // Create new entry
      const { data: newEntry, error } = await supabase
        .from('call_logs')
        .insert({
          date: selectedDate,
          calls_made: callsMade,
          calls_answered: callsAnswered,
          total_duration_minutes: durationMinutes,
          is_weekend: isSelectedWeekend
        })
        .select()
        .single();

      if (error) {
        toast.error("Failed to create entry");
      } else if (newEntry) {
        toast.success("Entry created successfully");
        setAllCallLogs(prev => [...prev, newEntry as CallLog]);
        setCurrentEntry(newEntry as CallLog);
      }
    }
  };

  // Calculate answer rate
  const answerRate = callsMade > 0 
    ? ((callsAnswered / callsMade) * 100).toFixed(1) 
    : '0';

  // Calculate aggregates for different periods
  const calculateAggregates = (entries: CallLog[], days: number) => {
    const cutoffDate = subDays(new Date(), days);
    const filtered = entries.filter(e => new Date(e.date) >= cutoffDate);
    const made = filtered.reduce((sum, e) => sum + e.calls_made, 0);
    const answered = filtered.reduce((sum, e) => sum + e.calls_answered, 0);
    const duration = filtered.reduce((sum, e) => sum + e.total_duration_minutes, 0);
    return { 
      made, 
      answered, 
      duration,
      rate: made > 0 ? ((answered / made) * 100).toFixed(1) : '0',
      count: filtered.length
    };
  };

  // Use live input values for today's stats
  const getLiveEntries = () => {
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    if (selectedDate === todayStr) {
      // Replace today's entry with current input values
      const otherEntries = allCallLogs.filter(e => e.date !== todayStr);
      const liveToday: CallLog = {
        id: currentEntry?.id || 'temp',
        date: todayStr,
        calls_made: callsMade,
        calls_answered: callsAnswered,
        total_duration_minutes: durationMinutes,
        is_weekend: isWeekend
      };
      return [...otherEntries, liveToday];
    }
    return allCallLogs;
  };

  const liveEntries = getLiveEntries();

  // Stats calculations
  const twoWeeksStats = calculateAggregates(liveEntries, 14);
  const monthlyStats = calculateAggregates(liveEntries, 30);
  const quarterlyStats = calculateAggregates(liveEntries, 90);
  const yearlyStats = calculateAggregates(liveEntries, 365);

  // Chart data - weekly trends
  const getWeeklyChartData = () => {
    const sortedEntries = [...liveEntries].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    const weeklyData: Record<string, { made: number, answered: number, duration: number }> = {};
    
    sortedEntries.forEach(entry => {
      const date = new Date(entry.date);
      const weekStart = new Date(date);
      weekStart.setDate(date.getDate() - date.getDay());
      const weekKey = weekStart.toISOString().split('T')[0];
      
      if (!weeklyData[weekKey]) {
        weeklyData[weekKey] = { made: 0, answered: 0, duration: 0 };
      }
      
      weeklyData[weekKey].made += entry.calls_made;
      weeklyData[weekKey].answered += entry.calls_answered;
      weeklyData[weekKey].duration += entry.total_duration_minutes;
    });

    return Object.entries(weeklyData)
      .map(([week, data]) => ({
        week: new Date(week).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        ...data,
        rate: data.made > 0 ? Math.round((data.answered / data.made) * 100) : 0
      }))
      .slice(-12);
  };

  const weeklyChartData = getWeeklyChartData();

  // Monthly bar chart data
  const getMonthlyBarData = () => {
    const monthlyData: Record<string, { made: number, answered: number, duration: number }> = {};
    
    liveEntries.forEach(entry => {
      const date = new Date(entry.date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = { made: 0, answered: 0, duration: 0 };
      }
      
      monthlyData[monthKey].made += entry.calls_made;
      monthlyData[monthKey].answered += entry.calls_answered;
      monthlyData[monthKey].duration += entry.total_duration_minutes;
    });

    return Object.entries(monthlyData)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, data]) => ({
        month: new Date(month + '-01').toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        ...data,
        rate: data.made > 0 ? Math.round((data.answered / data.made) * 100) : 0
      }))
      .slice(-6);
  };

  const monthlyBarData = getMonthlyBarData();

  // Recent entries for table
  const recentEntries = [...liveEntries]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 30);

  const chartConfig = {
    made: {
      label: "Calls Made",
      color: "hsl(var(--primary))",
    },
    answered: {
      label: "Calls Answered",
      color: "hsl(var(--chart-2))",
    },
    duration: {
      label: "Duration (min)",
      color: "hsl(var(--chart-3))",
    },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  // CSV Export function
  const exportToCSV = () => {
    if (allCallLogs.length === 0) {
      toast.error("No data to export");
      return;
    }

    const headers = ["Date", "Calls Made", "Calls Answered", "Duration (min)", "Answer Rate (%)", "Is Weekend"];
    const rows = allCallLogs.map(log => {
      const rate = log.calls_made > 0 ? ((log.calls_answered / log.calls_made) * 100).toFixed(1) : "0";
      return [
        log.date,
        log.calls_made,
        log.calls_answered,
        log.total_duration_minutes,
        rate,
        log.is_weekend ? "Yes" : "No"
      ].join(",");
    });

    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `call-tracking-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV exported successfully");
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary-accent bg-clip-text text-transparent">
                Call Tracking Analytics
              </h1>
              <p className="text-muted-foreground">Track daily calls and response rates</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={exportToCSV} className="gap-2">
              <Download className="h-4 w-4" />
              Export CSV
            </Button>
            <ThemeToggle />
          </div>
        </div>

        {/* Date Entry Card */}
        <Card className="glass-card glass-hover border-border/50 mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                <CardTitle>Call Data Entry</CardTitle>
                {isWeekend && (
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-primary/20 text-primary">
                    Weekend
                  </span>
                )}
              </div>
            </div>
            <CardDescription>
              Select a date and enter call data. Historical data can be added for any past date.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Date Selector */}
            <div className="mb-6">
              <Label htmlFor="dateSelect" className="flex items-center gap-2 mb-2">
                <Calendar className="h-4 w-4" />
                Select Date
              </Label>
              <Input
                id="dateSelect"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                max={format(new Date(), 'yyyy-MM-dd')}
                disabled={!isAdmin}
                className="max-w-xs"
              />
              <p className="text-xs text-muted-foreground mt-1">
                {format(new Date(selectedDate), 'EEEE, MMMM d, yyyy')}
              </p>
            </div>

            {/* Call Input */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  Calls Made
                </Label>
                <Input
                  type="number"
                  value={callsMade}
                  onChange={(e) => setCallsMade(parseInt(e.target.value) || 0)}
                  disabled={!isAdmin}
                  className="text-lg"
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <PhoneCall className="h-4 w-4" />
                  Calls Answered
                </Label>
                <Input
                  type="number"
                  value={callsAnswered}
                  onChange={(e) => setCallsAnswered(parseInt(e.target.value) || 0)}
                  disabled={!isAdmin}
                  className="text-lg"
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Duration (minutes)
                </Label>
                <Input
                  type="number"
                  value={durationMinutes}
                  onChange={(e) => setDurationMinutes(parseInt(e.target.value) || 0)}
                  disabled={!isAdmin}
                  className="text-lg"
                  min="0"
                />
              </div>
              <div className="flex flex-col justify-end">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-3xl font-bold text-primary">{answerRate}%</div>
                  <div className="text-xs text-muted-foreground">Answer Rate</div>
                </div>
              </div>
            </div>

            {isAdmin && (
              <Button onClick={handleSave} className="mt-6 w-full md:w-auto">
                <Save className="h-4 w-4 mr-2" />
                {currentEntry ? 'Update' : 'Create'} Entry for {format(new Date(selectedDate), 'MMM d, yyyy')}
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Summary Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardDescription>Last 2 Weeks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{twoWeeksStats.made}</div>
              <p className="text-sm text-muted-foreground">
                {twoWeeksStats.answered} answered • {twoWeeksStats.rate}%
              </p>
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardDescription>Monthly (30 days)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{monthlyStats.made}</div>
              <p className="text-sm text-muted-foreground">
                {monthlyStats.answered} answered • {monthlyStats.rate}%
              </p>
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardDescription>Quarterly (90 days)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{quarterlyStats.made}</div>
              <p className="text-sm text-muted-foreground">
                {quarterlyStats.answered} answered • {quarterlyStats.rate}%
              </p>
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardDescription>Yearly (365 days)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{yearlyStats.made}</div>
              <p className="text-sm text-muted-foreground">
                {yearlyStats.answered} answered • {yearlyStats.rate}%
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Weekly Trend Chart */}
        <Card className="glass-card glass-hover border-border/50 mb-8">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <CardTitle>Weekly Call Trends</CardTitle>
            </div>
            <CardDescription>Calls made and answered per week</CardDescription>
          </CardHeader>
          <CardContent>
            {weeklyChartData.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No data available yet</p>
            ) : (
              <ChartContainer config={chartConfig} className="h-[350px] w-full">
                <LineChart data={weeklyChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis 
                    dataKey="week" 
                    tick={{ fontSize: 12 }}
                    className="text-muted-foreground"
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }}
                    className="text-muted-foreground"
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="made" 
                    name="Calls Made"
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--primary))" }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="answered" 
                    name="Calls Answered"
                    stroke="hsl(var(--chart-2))" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--chart-2))" }}
                  />
                </LineChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        {/* Monthly Bar Chart */}
        <Card className="glass-card glass-hover border-border/50 mb-8">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <CardTitle>Monthly Call Summary</CardTitle>
            </div>
            <CardDescription>Total calls made and answered per month</CardDescription>
          </CardHeader>
          <CardContent>
            {monthlyBarData.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No data available yet</p>
            ) : (
              <ChartContainer config={chartConfig} className="h-[300px] w-full">
                <BarChart data={monthlyBarData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis 
                    dataKey="month" 
                    tick={{ fontSize: 11 }}
                    className="text-muted-foreground"
                  />
                  <YAxis 
                    tick={{ fontSize: 11 }}
                    className="text-muted-foreground"
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Bar 
                    dataKey="made" 
                    name="Calls Made"
                    fill="hsl(var(--primary))" 
                    radius={[4, 4, 0, 0]}
                  />
                  <Bar 
                    dataKey="answered" 
                    name="Calls Answered"
                    fill="hsl(var(--chart-2))" 
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        {/* Daily Tracking Table */}
        <Card className="glass-card glass-hover border-border/50">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              <CardTitle>Daily Call Log</CardTitle>
            </div>
            <CardDescription>Last 30 days of call tracking data</CardDescription>
          </CardHeader>
          <CardContent>
            {recentEntries.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No entries yet. Start by adding call data above.</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-center">Calls Made</TableHead>
                      <TableHead className="text-center">Calls Answered</TableHead>
                      <TableHead className="text-center">Duration</TableHead>
                      <TableHead className="text-center">Answer Rate</TableHead>
                      <TableHead className="text-center">Day Type</TableHead>
                      {isAdmin && <TableHead className="text-center">Actions</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentEntries.map((entry) => {
                      const rate = entry.calls_made > 0 
                        ? ((entry.calls_answered / entry.calls_made) * 100).toFixed(1)
                        : '0';
                      const hours = Math.floor(entry.total_duration_minutes / 60);
                      const mins = entry.total_duration_minutes % 60;
                      
                      return (
                        <TableRow key={entry.id}>
                          <TableCell className="font-medium">
                            {format(new Date(entry.date), 'MMM d, yyyy')}
                          </TableCell>
                          <TableCell className="text-center">{entry.calls_made}</TableCell>
                          <TableCell className="text-center">{entry.calls_answered}</TableCell>
                          <TableCell className="text-center">
                            {hours > 0 ? `${hours}h ` : ''}{mins}m
                          </TableCell>
                          <TableCell className="text-center">
                            <span className={`font-medium ${parseFloat(rate) >= 70 ? 'text-green-500' : parseFloat(rate) >= 50 ? 'text-yellow-500' : 'text-red-500'}`}>
                              {rate}%
                            </span>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className={`px-2 py-1 text-xs rounded-full ${entry.is_weekend ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'}`}>
                              {entry.is_weekend ? 'Weekend' : 'Weekday'}
                            </span>
                          </TableCell>
                          {isAdmin && (
                            <TableCell className="text-center">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setEditingEntry(entry);
                                  setEditDialogOpen(true);
                                }}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          )}
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Edit Dialog */}
      <EditCallLogDialog
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        entry={editingEntry}
        onSave={fetchData}
      />
    </div>
  );
}
