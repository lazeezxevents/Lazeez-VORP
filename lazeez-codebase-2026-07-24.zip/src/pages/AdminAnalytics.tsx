import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { AdminAnalyticsDashboard } from "@/components/AdminAnalyticsDashboard";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";

const AdminAnalytics = () => {
  const { isAdmin, user, loading, isAdminLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Wait for both auth and admin status to be fully loaded
    if (loading || isAdminLoading) return;

    // Now check access
    if (!user) {
      toast.error("Please sign in as admin");
      navigate("/");
    } else if (!isAdmin) {
      toast.error("Admin access required");
      navigate("/");
    }
  }, [loading, isAdminLoading, isAdmin, user, navigate]);

  const handleBack = () => {
    navigate("/");
  };

  // Show loading until both auth and admin status are verified
  if (loading || isAdminLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/80 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-pulse text-primary text-lg mb-2">Verifying access...</div>
          <p className="text-muted-foreground text-sm">Please wait</p>
        </div>
      </div>
    );
  }

  // Check access after verification
  if (!user || !isAdmin) {
    return null; // Will redirect
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/80">
      <div className="container mx-auto px-4 sm:px-6 py-6">
        <Button
          variant="ghost"
          onClick={handleBack}
          className="mb-4 gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Button>
        
        <AdminAnalyticsDashboard open={true} onOpenChange={() => {}} fullPage />
      </div>
    </div>
  );
};

export default AdminAnalytics;
