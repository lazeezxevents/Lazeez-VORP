# Lazeez Sales KPI — Standalone Setup

## 1. Install
```
bun install   # or npm install
```

## 2. Database
Create a new PostgreSQL / Supabase project, then run the accompanying
`lazeez-db-schema-*.sql` file against it. This creates tables, policies,
functions, and seeds all data.

## 3. Environment
Create a `.env` file with:
```
VITE_SUPABASE_URL="https://YOUR-PROJECT.supabase.co"
VITE_SUPABASE_PUBLISHABLE_KEY="YOUR_ANON_KEY"
VITE_SUPABASE_PROJECT_ID="YOUR_PROJECT_REF"
```

## 4. Deploy edge functions
```
supabase functions deploy export-database
supabase functions deploy export-schema
supabase functions deploy log-visitor
supabase functions deploy reset-daily-responses
supabase functions deploy weekly-digest
supabase functions deploy mcp
supabase functions deploy track-visitor-events
```

## 5. Run
```
bun run dev
```
