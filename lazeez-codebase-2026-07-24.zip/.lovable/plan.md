Reset the admin account credentials so the only working login is:

- Username / email: `lazeezxevents@gmail.com`
- Password: `alialiali110`

## Steps

1. Run a SQL migration against `auth.users` to:
   - Update the existing admin user's email to `lazeezxevents@gmail.com`
   - Update the password hash to `alialiali110` (using `crypt()` with bcrypt)
   - Mark email as confirmed
2. Ensure the corresponding `user_roles` row still has the `admin` role for that user.
3. Leave `AuthDialog` behavior unchanged — it already accepts a full email in the username field, so signing in with `lazeezxevents@gmail.com` + `alialiali110` will work.

No frontend changes required.